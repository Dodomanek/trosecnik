# Trosečník 3D 2.1 · experimentální Three.js renderer

Tento projekt je samostatná experimentální větev. Originální `src/game.js` zůstává jako záloha; nová hra se spouští přes `src/main.js`, logiku obsahuje `src/game_logic.js` a renderer `src/renderer.js`.

## Spuštění a nasazení na Vercel

1. Nahraj obsah **této složky** do kořene NOVÉHO projektu na Vercelu (soubor `index.html` musí ležet v kořeni projektu).
2. Framework = Other; Build Command = prázdný; Output Directory = prázdný. `vercel.json` nastavuje statické nasazení.
3. Lokálně lze spustit `python -m http.server 8000` a otevřít `http://localhost:8000/`. `file://` nestačí pro moduly a načítání GLB.
4. Three.js verze 0.170.0 se načítá z jsDelivr. **K běhu je vyžadován přístup k internetu**; toto není samostatná offline HTML verze.
5. Volitelné PBR modely umísti do `assets/models/palm.glb` a `assets/models/crate.glb`.

## Zachování původní hry

Herní pravidla, mapa, inventář, recepty, XP, příběh, NPC, interakce, kolize, klávesové i dotykové ovládání a formát uložení zůstávají v původním game.js / game_logic.js. `game_logic.js` je adaptér původního skriptu: původní skript byl těsně spojen s vykreslováním, a proto ještě **není** čistě separovanou doménovou logikou, ale vlastní GLSL a volání WebGL už neobsahuje.

**Staré uložené pozice:** Klíče `localStorage` se neměnily. Zachovají se jen na stejné doméně a v témže prohlížeči. Před nasazením doporučujeme exportovat uložený postup. Toto je experimentální varianta: ověř hráčsky v prohlížeči zejména obraz, výkon a přechod úkolů. Původní produkční projekt do té doby nepřepisuj.

## Výkon a omezení

Renderer přebírá existující geometrii jako sdílené BufferGeometry, používá MeshStandardMaterial a podporuje materiály a textury GLB prostřednictvím GLTFLoader. Dynamické objekty znovu používají existující instance místo nové alokace v každém snímku. Na telefonech jsou stíny vypnuté ve prospěch výkonu, na větších obrazovkách zapnuté. Původní statické palmy nejsou duplikované, pokud se načte palm.glb.

Bez externích GLB budou objekty stále low-poly, ačkoli s novým světlem a materiály. Skutečné vykreslení na GPU nebylo v tomto prostředí možné otestovat kvůli blokovanému přístupu k testovací stránce a CDN. Ukládání a herní logika se testovaly s náhradním rendererem.
