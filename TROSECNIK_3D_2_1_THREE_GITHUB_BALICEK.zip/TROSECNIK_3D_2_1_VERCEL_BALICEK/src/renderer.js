import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

// GPU-only layer. Never mutates inventory, quests, collisions, save data or NPC logic.
// Geometry is the ORIGINAL triangle data, converted to reusable Three.js BufferGeometry.
export class Renderer {
  constructor() {
    this.models = new Map();
    this.geometryPool = [];
    this.modelPool = [];
    this.materials = new Map();
    this.geometryIndex = 0;
    this.modelIndex = 0;
    this.lastWidth = 0;
    this.lastHeight = 0;
    this.lastRatio = 0;
    this.clock = 0;
    this.engine = null;
  }

  init(canvas) {
    if (!canvas) throw new Error('Chybí původní herní canvas #world.');
    this.canvas = canvas;
    this.engine = new THREE.WebGLRenderer({canvas,alpha:false,antialias:true,powerPreference:'high-performance'});
    this.engine.outputColorSpace = THREE.SRGBColorSpace;
    this.engine.toneMapping = THREE.ACESFilmicToneMapping;
    this.engine.toneMappingExposure = 1.35;
    this.engine.shadowMap.enabled = true;
    this.engine.shadowMap.type = THREE.PCFSoftShadowMap;
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(68,1,.09,190);
    this.scene.fog = new THREE.Fog(0x89ab9f,22,110);
    this.ambient = new THREE.HemisphereLight(0xaedaf0,0x5d633e,1.15);
    this.scene.add(this.ambient);
    this.fill = new THREE.AmbientLight(0x7383a7,.24);
    this.scene.add(this.fill);
    this.sun = new THREE.DirectionalLight(0xffdfab,2.2);
    this.sun.position.set(40,80,-28);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(1024,1024);
    this.sun.shadow.camera.left=-28;
    this.sun.shadow.camera.right=28;
    this.sun.shadow.camera.top=28;
    this.sun.shadow.camera.bottom=-28;
    this.sun.shadow.camera.near=.5;
    this.sun.shadow.camera.far=140;
    this.sun.shadow.bias=-.00018;
    this.scene.add(this.sun,this.sun.target);
    this.fire = new THREE.PointLight(0xff9237,0,13,2);
    this.fire.position.set(-4,1,-2);
    this.scene.add(this.fire);
    this.loader = new GLTFLoader();
    return this;
  }

  upload(data) {
    if (!data || !Array.isArray(data.p) || !data.p.length) {
      return {geometry:null,count:0};
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position',new THREE.Float32BufferAttribute(data.p,3));
    if(data.n?.length===data.p.length) geometry.setAttribute('normal',new THREE.Float32BufferAttribute(data.n,3));
    else geometry.computeVertexNormals();
    if(data.c?.length===data.p.length) geometry.setAttribute('color',new THREE.Float32BufferAttribute(data.c,3));
    else {
      const colors=new Float32Array(data.p.length).fill(1);
      geometry.setAttribute('color',new THREE.BufferAttribute(colors,3));
    }
    geometry.computeBoundingSphere();
    return {geometry,count:data.p.length/3};
  }

  material(tint=[1,1,1],kind=0,water=0) {
    const key=[...tint].map(v=>Math.round(v*255)).join(',')+`:${kind}:${water}`;
    if(!this.materials.has(key)){
      const ocean=water>0;
      const rgb=new THREE.Color().setRGB(...tint);
      const material=new THREE.MeshStandardMaterial({
        color:rgb, vertexColors:true,
        roughness:ocean?.24:kind===1?.96:.84,
        metalness:ocean?.12:kind===0?.035:0,
        transparent:ocean,opacity:ocean?.82:1,depthWrite:!ocean,
        side:THREE.DoubleSide,
      });
      this.materials.set(key,material);
    }
    return this.materials.get(key);
  }

  applyMatrix(node, matrix) {
    node.matrixAutoUpdate=false;
    node.matrix.fromArray(matrix);
    node.matrixWorldNeedsUpdate=true;
  }

  draw(mesh, matrix, tint,kind=0,water=0) {
    if(!mesh?.geometry || !mesh.count) return;
    const i=this.geometryIndex++;
    let node=this.geometryPool[i];
    if(!node){node=new THREE.Mesh(mesh.geometry,this.material(tint,kind,water));
      node.frustumCulled = true;
      this.geometryPool.push(node);
      this.scene.add(node);
    }
    if(node.geometry!==mesh.geometry)node.geometry=mesh.geometry;
    node.material=this.material(tint,kind,water);
    node.visible=true;
    node.castShadow=kind===0&&water===0&&mesh.count<9000;
    node.receiveShadow=water===0;
    node.userData.water=water>0;
    this.applyMatrix(node,matrix);
  }

  hasModel(name) {return this.models.has(name);}
  drawModel(name,matrix,tint=[1,1,1]) {
    const model=this.models.get(name);
    if(!model)return false;
    const i=this.modelIndex++;
    let entry=this.modelPool[i];
    if(!entry || entry.name!==name) {
      if(entry)this.scene.remove(entry.group);
      const group=new THREE.Group();
      const clone=model.scene.clone(true);
      clone.scale.multiplyScalar(model.scale);
      clone.position.y+=model.yOffset;
      clone.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});
      group.add(clone);
      entry={name,group};this.modelPool[i]=entry;this.scene.add(group);
    }
    entry.group.visible=true;
    this.applyMatrix(entry.group,matrix);
    return true;
  }

  async loadModels(list) {
    let count=0;
    await Promise.all(list.map(async entry=>{
      try{
        const gltf=await this.loader.loadAsync(entry.url);
        if(!gltf?.scene)throw new Error('Soubor neobsahuje scénu');
        let meshes=0;
        gltf.scene.traverse(n=>{if(n.isMesh)meshes++;});
        if(!meshes)throw new Error('Scéna neobsahuje geometrii');
        this.models.set(entry.name,{scene:gltf.scene,scale:entry.scale??1,yOffset:entry.yOffset??0});
        count++;
      }catch(error){
        // Missing models are normal: the original trees/crate remain visible.
        console.info('Volitelný GLB model není dostupný:',entry.name,error.message||error);
      }
    }));
    return count;
  }

  beginFrame({width,height,dpr,daylight=1,clock=12,weather='clear',time=0,
    eye=[0,3,7],focus=[0,1,0],fov=68,fireOn=0,fireY=1}) {
    const w=Math.max(1,Math.floor(width||1)),h=Math.max(1,Math.floor(height||1));
    const ratio=Math.min(1.6,Math.max(.65,dpr||1));
    if(w!==this.lastWidth||h!==this.lastHeight||Math.abs(ratio-this.lastRatio)>.01) {
      this.engine.setPixelRatio(ratio);
      this.engine.setSize(w,h,false);
      this.lastWidth=w;this.lastHeight=h;this.lastRatio=ratio;
      this.camera.aspect=w/h;
      this.camera.updateProjectionMatrix();
    }
    this.camera.fov=fov;
    this.camera.position.set(...eye);
    this.camera.lookAt(...focus);
    this.camera.updateProjectionMatrix();
    this.camera.updateMatrixWorld(true);
    const day=Math.max(0,Math.min(1,daylight));
    const badWeather=weather==='storm'?.53:weather==='rain'?.25:0;
    const skyNight=new THREE.Color(0x071423);
    const skyDay=new THREE.Color(0x8cb6bd);
    const sky=skyNight.lerp(skyDay,day*(1-badWeather));
    const sunset=Math.max(0,1-Math.abs(clock-18)/2.0)*day*(1-badWeather);
    sky.lerp(new THREE.Color(0xa77a64),sunset*.42);
    this.scene.background=sky;
    this.scene.fog.color.copy(sky);
    this.scene.fog.near=16+day*10;
    this.scene.fog.far=(weather==='storm'?54:weather==='rain'?72:115);
    this.ambient.intensity=.24+day*.91;
    this.fill.intensity=.11+(1-day)*.31;
    this.sun.intensity=.10+day*2.05*(1-badWeather*.6);
    this.sun.target.position.set(focus[0],0,focus[2]);
    this.sun.position.set(focus[0]+35,Math.max(18,42+day*35),focus[2]-28);
    this.sun.target.updateMatrixWorld();
    this.sun.castShadow=this.lastWidth>700&&this.lastHeight>540&&weather!=='storm';
    this.fire.intensity=fireOn*2.5;
    this.fire.position.y=fireY;
    this.clock=time;
    this.geometryIndex=0;
    this.modelIndex=0;
  }

  endFrame() {
    for(let i=this.geometryIndex;i<this.geometryPool.length;i++)this.geometryPool[i].visible=false;
    for(let i=this.modelIndex;i<this.modelPool.length;i++)if(this.modelPool[i])this.modelPool[i].group.visible=false;
    for(let i=0;i<this.geometryIndex;i++){
      const node=this.geometryPool[i];
      if(node.userData.water){
        // Preserve the original sea plane's mean height; only add a small surface wave.
        node.matrix.elements[13]+=.026*Math.sin(this.clock*.9);
        node.matrixWorldNeedsUpdate=true;
      }
    }
    this.engine.render(this.scene,this.camera);
  }
  render(){this.endFrame();}
  getCanvas(){return this.canvas;}
}
