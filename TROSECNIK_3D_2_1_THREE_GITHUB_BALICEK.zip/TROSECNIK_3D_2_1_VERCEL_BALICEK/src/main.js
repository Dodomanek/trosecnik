import { Renderer } from './renderer.js';
import { GameLogic } from './game_logic.js';

const canvas = document.getElementById('world'); // Original ID; all pointer controls remain attached to it.
const fatal = document.getElementById('fatal');
try {
  const renderer = new Renderer();
  renderer.init(canvas);
  const game = new GameLogic();
  game.init(renderer);
  window.__trosecnikBooted=true;
  let lastTime = 0;
  function frame(time) {
    const dt = lastTime ? Math.min(Math.max((time-lastTime)/1000,0),.055) : 0;
    lastTime = time;
    game.update(dt);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
} catch (error) {
  console.error('Trosečník: spuštění Three.js selhalo',error);
  fatal.hidden = false;
  fatal.querySelector('h2').textContent='Grafické prostředí se nepodařilo spustit';
  fatal.querySelector('p').textContent=error?.message || 'Ověř připojení k internetu a podporu WebGL.';
  document.getElementById('intro').hidden=true;
}
