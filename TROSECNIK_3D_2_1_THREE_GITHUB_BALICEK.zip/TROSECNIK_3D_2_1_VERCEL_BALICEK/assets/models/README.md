# Externí 3D modely (volitelné)

Do této složky vlož vlastní soubory `palm.glb` a `crate.glb`. Pokud nejsou k dispozici nebo selžou při načítání, hra zobrazí původní procedurální palmy a bednu. Import probíhá asynchronně a neblokuje spuštění hry.

Doporučení pro iPhone: do 5 000 trojúhelníků na jednotlivý model, textury ideálně 512 × 512 nebo 1024 × 1024, modely bez Draco, Meshopt a KTX2 komprese, protože tato verze nepřibaluje jejich dekodéry. PBR materiály Metallic-Roughness a běžné PNG/JPEG textury z GLB Three.js podporuje. Není potřeba dodávat samostatné obrázky textur, pokud jsou zabalené uvnitř GLB.

Původní generované prostředí zůstává zachované. Samotná výměna rendereru nezmění jeho low-poly geometrii na realistické modely.
