import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInNewContext} from 'node:vm';
import {fileURLToPath} from 'node:url';
import {dirname,resolve} from 'node:path';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const source=readFileSync(resolve(root,'src/game_logic.js'),'utf8');
const base=readFileSync(resolve(root,'tools/fixtures/survival20_game_logic.js'),'utf8');
function list(src,start,end){let a=src.indexOf(start),b=src.indexOf(end,a);assert.ok(a>=0&&b>a,`missing ${start}`);return runInNewContext('('+src.slice(a+start.length,b).trim().replace(/;$/,'')+')');}
const quests=list(source,'const QUESTS=',';\nconst BUILD='), objects=list(source,'const OBJ=',';\nconst TUTORIAL_IDS=');
const baseQ=list(base,'const QUESTS=',';\nconst BUILD='),baseO=list(base,'const OBJ=',';\nconst TUTORIAL_IDS=');
const cacheIds=['coastCache','westCache','ridgeCache'];
const newResourceIds=['reedsWest','reedsSouth','clayWest','clayNorth','flintNorth','flintEast','berriesWest','berriesNorth','saltSouth','saltCoast'];
const expected={coastCache:{wood:2,stone:2},westCache:{fiber:3,coconut:2},ridgeCache:{wood:2,stone:1,bandage:1}};

test('three new one-time field caches form playable quests between reconnaissance stages',()=>{
 assert.deepEqual(Array.from(quests.filter(q=>!baseQ.some(p=>p.id===q.id)).map(q=>q.id)),cacheIds);
 assert.deepEqual(Array.from(objects.filter(o=>!baseO.some(p=>p.id===o.id)&&!newResourceIds.includes(o.id)&&o.id!=='site-storage').map(o=>o.id)),cacheIds);
 for(const id of cacheIds){const q=quests.find(q=>q.id===id),o=objects.find(o=>o.id===id);assert.ok(q&&o);assert.equal(q.target,id);assert.equal(o.phase,'fieldCache');assert.equal(o.type,'storySite');assert.ok(Math.hypot(o.x+4,o.z+2)>22,'no cache near camp');}
 for(const [a,b,c] of [['coastSurvey','coastCache','westSurvey'],['westSurvey','westCache','ridgeSurvey'],['ridgeSurvey','ridgeCache','surveyNotes']]) assert.ok(quests.findIndex(q=>q.id===a)<quests.findIndex(q=>q.id===b)&&quests.findIndex(q=>q.id===b)<quests.findIndex(q=>q.id===c));
});

test('original quests, objects and world positions unchanged',()=>{
 const clean=x=>JSON.parse(JSON.stringify(x.map(o=>({id:o.id, target:o.target, x:o.x, z:o.z, name:o.name, type:o.type, phase:o.phase, repeat:o.repeat, xp:o.xp, desc:o.desc}))));
 assert.deepEqual(clean(quests.filter(q=>!cacheIds.includes(q.id))),clean(baseQ));
 assert.deepEqual(clean(objects.filter(o=>!cacheIds.includes(o.id)&&!newResourceIds.includes(o.id)&&o.id!=='site-storage')),clean(baseO));
 assert.equal(source.match(/const KEY='([^']+)'/)[1],base.match(/const KEY='([^']+)'/)[1]);
 assert.equal(source.match(/const BASE=\{version:(\d+)/)[1],base.match(/const BASE=\{version:(\d+)/)[1]);
 const currentBuild=list(source,'const BUILD=',';\nconst OBJ=');
 const originalBuild=list(base,'const BUILD=',';\nconst OBJ=');
 assert.deepEqual(JSON.parse(JSON.stringify(Object.fromEntries(Object.entries(currentBuild).filter(([id])=>id!=='storage')))),JSON.parse(JSON.stringify(originalBuild))); // Only the new optional camp store may differ.
});

test('interaction gate and single award per cache, even after save reload',()=>{
 assert.match(source,/if\(o\.type==='storySite'&&\(o\.phase==='survey'\|\|o\.phase==='fieldCache'\)\)return currentQuest\(\)\?\.target===o\.id&&!state\.flags\[o\.id\]/);
 assert.match(source,/if\(state\.flags\[id\]\)return;/);
 assert.match(source,/state\.flags\[id\]=true;/);
 for(const [id,goods] of Object.entries(expected))assert.match(source,new RegExp(id+':\\{'+Object.entries(goods).map(([key,n])=>key+':'+n).join(',')+'\\}'));
 assert.match(source,/checkQuest\(\);save\(true\);\s*\},1\.8\);return;/);
});

test('migration skips caches behind existing progress without granting XP or duplicate supplies',()=>{
 assert.match(source,/past\.westSurvey\|\|past\['quest-westSurvey'\]/);
 assert.match(source,/past\.ridgeSurvey\|\|past\['quest-ridgeSurvey'\]/);
 assert.match(source,/past\.surveyNotes\|\|past\['quest-surveyNotes'\]/);
 const slice=source.slice(source.indexOf('const skip={coastCache:'),source.indexOf('for(let site of Object.keys(BUILD))'));
 assert.doesNotMatch(slice,/awardXP\(|add\(/);
 const flags={coastSurvey:true,coastCache:false,westSurvey:false,westCache:false,ridgeSurvey:false,ridgeCache:false,surveyNotes:false};
 const save={flags,story:{fate:'mara',finalSignal:true},built:{},bag:{},skills:{}};
 for(const q of quests){if(q.id==='last')break;flags['quest-'+q.id]=true;}
 const current=()=>quests.find(q=>(!q.active||q.active(save))&&!flags['quest-'+q.id]&&!q.done(save));
 for(const id of ['coastCache','westSurvey','westCache','ridgeSurvey','ridgeCache','surveyNotes']){
  assert.equal(current().id,id);flags[id]=true;flags['quest-'+id]=true;
 }
 assert.equal(current().id,'expedition');
});


test('real field-cache interaction callback grants rewards once and persists the claim',()=>{
 const start=source.indexOf(" if(o.phase==='fieldCache'){",source.indexOf('function interactStorySite(o)'));
 const end=source.indexOf(" if(id==='campPlan')",start);
 assert.ok(start>=0&&end>start,'field interaction source found');
 const statements=source.slice(start,end);
 for(const [id,expectedGoods] of Object.entries(expected)){
  const state={flags:{},journal:[],day:2};
  const saved=[];
  const ctx={state,ITEM:Object.fromEntries(Object.keys(expectedGoods).map(k=>[k,['',k]])),currentQuest:()=>({target:id}),finishAction:(o,kind,callback)=>callback(),add:(kind,count)=>{state.inventory??={};state.inventory[kind]=(state.inventory[kind]||0)+count;},flash:()=>{},checkQuest:()=>{},save:()=>{saved.push(JSON.parse(JSON.stringify(state)));}};
  const run=runInNewContext('(function interact(o){const id=o.id,f=state.flags,quest=currentQuest();'+statements+'})',ctx);
  run({id,phase:'fieldCache'});
  assert.deepEqual(JSON.parse(JSON.stringify(state.inventory)),expectedGoods);
  assert.equal(state.flags[id],true);
  assert.equal(saved.length,1);
  run({id,phase:'fieldCache'});
  assert.deepEqual(JSON.parse(JSON.stringify(state.inventory)),expectedGoods);
  assert.equal(saved.length,1,'opening the same cache twice does not duplicate rewards');
  assert.equal(state.journal.length,1);
 }
});
