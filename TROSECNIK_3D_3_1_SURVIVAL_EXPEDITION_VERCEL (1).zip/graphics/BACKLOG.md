# Grafický backlog · aktuální větev 2.4.2

- [ ] P0: Zachytit skutečné snímky fungující WebGL scény na iPhonu 390×844 a 844×390, změřit FPS při chůzi a otáčení.
- [ ] P0: Zkontrolovat root / hips klipy Robinsona na konkrétním GLB a odstranit případné posuny kamery či skluz chodidel, bez úpravy kolizí.
- [ ] P1: Srovnat přechod den / noc / bouře pro čitelnost cesty a orientačních bodů.
- [ ] P1: Nahradit nejvýraznější zástupné geometrie podél hlavní stezky kvalitními lokálně uloženými assety s ověřenou licencí a fallbackem.
- [ ] P1: Optimalizovat počet stínujících objektů a průhledných ploch v mangrovech; ověřit reálný mobilní výkon.
- [ ] P2: Ujednotit PBR materiály dřeva, písku, kamene a mokré půdy; vytvořit konzistentní prostředí.
- [ ] P2: Grafický test všech nabídek, joysticku a titulku na mobilu při skutečném vykreslování scény.

Položku označuj jako dokončenou teprve po implementaci a ověření. Nepleť si vizuální kvalitu s počtem přidaných souborů.

- [x] GFX 6: Přenést existující lokální GLB palmy a bedny do aktuální verze 2.4.2; ověřit strukturu a načítací cesty. Skutečná vizuální kvalita na zařízení zůstává neověřena.

- [x] GFX 8: Prototyp skalní stěny a vodopádu vznikl v legacy `src/game.js`; aktivní Three.js port je součást GFX 9.

- [x] GFX 9: Aktivní cinematic environment pass: sky-dome, voda, mokré pobřeží, skutečně vykreslovaný vodopád, vzdálené hory, kapradinový podrost a kontaktní stín Robinsona. Herní pravidla a save formát beze změny; vizuální test zařízení stále čeká.

- [x] GFX 10: Dva originální lokální GLB modely postaveného tábora (přístřešek a ohniště), zapojené s fallbackem do aktivní scény; statický audit a offline náhled modelů.
- [ ] GFX 10 navazující: vizuálně ověřit načtení nových modelů a průchod stavěním na iPhonu; při přechodu do final stage nesmí dojít k výpadku vizuálu.
- [ ] Fotorealistické materiály a textury a skutečně skinovaný Robinson stále vyžadují samostatnou výrobu a kontrolu rig/animací.

- [x] GFX 11: Originální lokální materiálové textury pro stávající animovaný model Robinsona a fallback na původní GLB. Offline strukturální kontrola prošla; vizuální a FPS test na zařízení stále čeká.
- [ ] Další práce: nový skutečně skinovaný humanoidní Robinson s věrohodnější geometrií a pohybem; před integrací nutno porovnat osm současných animací a zachovat fyzikální root.

- [x] GFX 12: Originální lokální GLB vraku Esperanzy zapojený v aktivní scéně se samostatným procedurálním fallbackem, offline kontrolou modelu a regresním porovnáním herních souborů.
- [ ] GFX 12 navazující: potvrdit ve skutečné WebGL hře, že se vrak nenačte dvojmo, nedochází ke změně viditelnosti po dokončení úkolu a výkon na cílovém iPhonu vyhovuje.

- [x] GFX 13: Vytvořit lokální originální GLB skalní stěny za pramenem, nahradit původní statické skály v aktivní scéne s fallbackem; struktura modelu, aktivní integrace a neměnnost herní logiky ověřena offline.
- [ ] GFX 13 navazující: Porovnat stejné kamerové záběry vodopádu s/bez GLB ve WebGL na desktopu a iPhonu na výšku i na šířku. Zkontrolovat případné průniky skal do vody, kontakt s terénem, přechod na procedural fallback a dopad na FPS a stíny.

- [x] GFX 14: Upravit originální opakovaný GLB palmy na detailnější zakřivený kmen s lístky a snížit počet materiálových skupin 19 → 5, zachovat všechna umístění stromů a procedurální fallback; offline geometrie a kontrola nezměněné herní logiky ověřeny.
- [ ] GFX 14 navazující: na iPhonu i desktopu porovnat pláž / lesní cestu, počet skutečných draw calls, načtení nové palmy, stíny listů, průjezd kamerou a FPS proti GFX 13. Tento záznam není tvrzením o fotorealismu.

- [x] GFX 15: Vytvořit originální lokální GLB pro dokončený vodní filtr a signální stanoviště, zapojit je s fallbackem do aktivní scény a zachovat herní logiku, stavby i ukládání.
- [ ] GFX 15 navazující: vizuálně ověřit dokončený filtr a signální stanoviště v běžící WebGL hře na iPhonu i desktopu, zkontrolovat průniky s terénem, správné přepnutí fallbacku a dopad na FPS během pobytu v táboře.

- [x] GFX 16: Opravit rybářskou minihru, aby zásah viditelné zelené oblasti fungoval i při dlouhém dotyku a bez dvojitého započtení. Jednotná geometrie zelené zóny, kontrola hranic a statické regresní testy.
- [ ] GFX 16 navazující: na reálném iPhonu vyzkoušet 3 zásahy / 7 pokusů při dotyku, rychlé tapnutí i dlouhý dotyk, získání ryby, uložení a limit XP.

- [x] GFX 17: Procedurální neutrální mikrotextura pouze na existujícím terénu a vizuální změna jeho PBR drsnosti za deště bez zásahu do fyziky, pravidel či uložení; offline syntaxe a regresní kontrola rybářské minihry.
- [ ] GFX 17 navazující: na skutečném WebGL porovnat pobřeží a les za jasna, deště a bouře (desktop / iPhone) včetně FPS a případných opakujících se vzorů textury.

- [x] GFX 18: Přidat nenápadnou šipku nad hlavu Robinsona, která ukazuje na aktuální objekt úkolu bez změny herních pravidel a save dat.
- [ ] GFX 18 navazující: Ověřit ve skutečné hře na mobilu i desktopu, že šipka není příliš rušivá, nezaniká proti obloze a správně mizí po příchodu k cíli.

- [x] GFX 19: Opravit čitelnost navigační šipky nad postavou při otáčení kamery; promítat ji nad hlavu pomocí kamery, zavést otestovaný model směru v obou mobilních orientacích a odebrat původní grafické 3D draw calls.
- [ ] GFX 19 navazující: na reálném iPhonu a ve WebGL ověřit správnou pozici ukazatele nad hlavou, míření i při kameře přes rameno, skrývání v dialogu/minihře a nízký vizuální kontrast v noci.

- [x] SURVIVAL 21: Přidat tři malé originální interakční bedny k průzkumným trasám s omezenou jednorázovou odměnou a bez změny původních kolizí; offline testy logiky, terénu a strukturálního auditu.
- [ ] SURVIVAL 21 navazující: Na skutečném iPhonu ověřit průchod ke všem třem úkrytům, jejich čitelnost a zmizení po vyzvednutí i při načtení pozice.

### Plán verze 3.0 · Živý ostrov

- [x] ALFA 1: První fungující táborový sklad s vizuálem, skutečnou interakcí, omezenou kapacitou a trvalým uložením surovin; nosnost a vyrobitelný větší batoh.
- [ ] ALFA 2: Fyzické nástroje v Robinsonových rukou a pracovní animace. Ověřit licenčně čistý skinovaný humanoidní model s funkčním rigem a skutečné načtení modelu ve WebGL.
- [ ] ALFA 3: Rozlišitelné biomy, detailnější vegetace a osvětlení optimalizované pro mobil; vizuální testy na zařízení.
- [ ] ALFA 4: Další užitečné pracovní stanice, recepty a zdroje v odlehlých oblastech bez rychlého respawnu u tábora.
- [ ] ALFA 5: Nové průzkumné oblasti a příběhové kapitoly, ověřit reálnou délku kampaně bez umělého čekání.
- [ ] BETA: Kompletní průchod hry, kontrola starých pozic, export/import, desktop/iPhone výkon a ovládání.
