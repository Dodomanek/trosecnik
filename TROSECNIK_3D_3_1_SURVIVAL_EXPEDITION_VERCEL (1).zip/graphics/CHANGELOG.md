# Grafické změny

## 2.4.1 · Založení agenta

Přidán pracovní rámec agenta, grafický backlog, offline auditor zdrojů a CI kontrola. Záměrně bez změny modelů, grafiky a herních pravidel. Vizuální ověření na iPhonu čeká na reálný test.

## 2.4.2 · GFX 6 · Lokální 3D palmy a bedny

Do skutečného projektu 2.4.2 byly přeneseny dva již dříve vytvořené lokální GLB modely (`palm.glb`, `crate.glb`). Existující načítání a procedurální fallback zůstávají beze změny. Nejde o fotorealistickou proměnu ani o nový model Robinsona. GLB struktura, syntaxe a statický audit byly zkontrolovány; vizuální vykreslení na iPhonu neověřeno.

## GFX 7 · Pobřežní materiál (2026-09-22)
- V terénním fragment shaderu přidány jemné suché pískové variace a nepravidelný tmavší vlhký pás přílivu podle světových souřadnic.
- Nemění se výšková mapa, kolize, rozmístění objektů, herní stav ani ukládání. Žádné nové textury nebo draw calls.
- Vizuální vykreslení na desktopu/iPhonu neověřeno; statický audit není vizuální test.

## GFX 8 (2026-09-22)
- Přidána vrstvená skalní stěna a vodopád za pramenem; samostatná vodní geometrie využívá existující shader.
- Beze změn herní logiky, terénní funkce, kolizí a save klíče.
- Audit a syntaxe prošly; vizuální vykreslení neověřeno.

## GFX 9 · Aktivní cinematic environment pass (2026-09-22)
- Oprava pracovního směru: předchozí GFX 7/8 zasahovaly také do starého `src/game.js`, ale skutečná hra startuje přes `src/main.js` → `src/game_logic.js` + `src/renderer.js`. GFX 9 proto provádí změny v aktivní renderovací cestě.
- Přidán procedurální sky-dome s viditelným sluncem, teplým ranním/večerním horizontem a vazbou na počasí bez změny herního času.
- Aktivní moře a vodopád používají nový lehký shader s fresnelem, animovanými vlnami, pěnou, slunečním odleskem a mlhou.
- Pobřežní materiál v aktivní mapě má nově tmavší mokrý pás a jemnější barevné přechody písku.
- Vodopád za původním pramenem je nyní vykreslován ve skutečné Three.js scéně; interakce pramene, kolize a uložený postup zůstaly stejné.
- Přidán vzdálený horský horizont mimo průchozí herní elipsu a levný kapradinový podrost sloučený do statického meshe bez nových draw callů pro jednotlivé rostliny.
- GLB Robinson dostal konzervativnější fyzikální materiál a průhledný kontaktní stín; rig, animace, pozice postavy a fyzika se nemění.
- `node tools/graphics_agent.mjs audit` a syntaxe `renderer.js`, `main.js`, `game_logic.js` prošly. Vizuální vykreslení neověřeno, protože testovací prostředí nemá dostupný lokální Three.js balík a síť k CDN je blokovaná.

## GFX 10 · Originální 3D modely tábora (2026-09-22)

- Vytvořeny dva **skutečné lokální modely GLB** generátorem `tools/generate_camp_assets.py`: `shelter.glb` (dřevěné vzpěry, šikmá palmová střecha, výplet a lehátko) a `campfire.glb` (kameny, polena, uhlíky). Nejsou použity cizí ani placené assety.
- Integrované v **aktivní** cestě `src/game_logic.js → src/renderer.js` pouze pro již postavené (stage >= 3) přístřeší a ohniště. Plameny dále využívají původní animaci, která není součástí statického GLB.
- Pokud se volitelný GLB nenačte, zachová se původní procedurální geometrie. Rozpracované stavby i herní interakce se zobrazují původním způsobem.
- `tools/preview_camp_assets.py` vytváří offline softwarový náhled přímo z obou GLB, **nikoli screenshot hry**.
- Nedotčené: kolize, stage/progres stavění, inventář, questy, příběh, dabing, klíče a formát uložení.
- Omezení: 3D assety jsou stále zjednodušené procedurální modely s PBR barvami, **ne fotorealistické modely**. Vizuální vykreslení v běžící hře a výkon na iPhonu neověřeny; runtime Three.js závisí na nedostupném CDN.

## GFX 11 · Robinson: lokální materiálové textury (2026-09-22)

- Rozšířen původní animovaný `robinson.glb` o **šest originálních procedurálních 256×256 PNG mikrotextur** přímo uvnitř GLB pro kůži, len, kalhoty, vlasy, brašnu a provaz. Nejsou potřeba externí URL, placená generace ani cizí assety.
- Textury jsou použity výhradně na 18 existujících UV-mapovaných primitivech. V původní geometrii, hierarchii a osmi animačních klipech nejsou žádné změny; originální obličejová textura zůstala zachována.
- Původní animovaný model uložen jako `robinson_base.glb` a přidán lokální fallback v `src/renderer.js`, aby selhání načtení texturované verze neodstranilo 3D postavu ze hry.
- `tools/upgrade_robinson_materials.py` reprodukuje výsledek z původního GLB, `tools/check_gfx11_character.py` kontroluje odkazy na textury, strukturu, animace, binární data a nezměněnou herní logiku. `tools/preview_robinson_materials.py` vytváří **pouze přibližný offline náhled skutečných GLB trojúhelníků**, nikoli screenshot hry.
- Limity: Robinson má stále zjednodušenou segmentovanou geometrii bez humanoidního skinu, model není fotorealistický. Vizuální vykreslení neověřeno v běžící WebGL hře a výkon na iPhonu nezměřen.

## GFX 12 · Vrak Esperanzy jako samostatný lokální GLB (2026-09-22)

- Originální vývojový model `assets/models/wreck.glb` tvořený přímo z procedurální geometrie: rozpukaný trup, otevřená žebra, nepravidelná paluba, lomené stěžně, roztržená plachta, lana a trosky. Generátor `tools/generate_wreck_asset.py` reprodukuje stejný model bez externích ani placených assetů.
- Aktivní `src/game_logic.js` nyní kreslí GLB přímo na stávajících souřadnicích Esperanzy. Původní vrak zůstává jako samostatný fallback mesh při nezdařeném nebo probíhajícím načtení; nejsou vykreslovány oba trupy zároveň. Nedotčeno rozmístění vraku, jeho interakční rádius, kolize, inventář, questy, čas hry, save formát ani dabing.
- `tools/check_gfx12_wreck.py` ověřuje načtení GLB, velikost, materiály a hranice modelu; přesným porovnáním s GFX 11 ověřuje, že veškerý původní herní kód mimo vyjmenovanou vizuální substituci a 144 ostatních souborů zůstal beze změn.
- `tools/preview_wreck_asset.py` vykresluje z reálných GLB trojúhelníků pouze offline diagnostický náhled, nejde o screenshot ani doklad herního WebGL.
- Omezení: model je středně detailní procedurální PBR geometrie bez fotorealistických povrchových textur. Vizuální vykreslení ve hře neověřeno: lokální HTTP přístup Chromium blokuje správce prostředí, reálné testy na iPhonu/FPS a stav po interakci s vrakem čekají.

## GFX 13 · Skalní stěna pramene jako originální lokální model (2026-09-22)

- `assets/models/spring_cliff.glb`: nově vytvořená samostatná 3D skála se stupňovitými útesy, nepravidelným kamením, puklinami, mechem, krátkými liánami a listy kapradin. Generátor `tools/generate_spring_cliff.py` používá pouze procedurálně vytvořenou geometrii a lokální neprůhledné PBR materiály, bez externích textur a cizích či placených assetů. 8 820 trojúhelníků, osm meshů, 150 184 B.
- Model nahrazuje **pouze původní statické skály** za pramenem ve skutečné Three.js renderovací cestě. Původní skalní geometrie je uložena v odděleném bufferu a při nenačtení GLB zůstane viditelná. Animovaná voda, pěna a pramen nejsou měněny.
- Herní souřadnice, fyzika/kolize, interakce, questy, ukládání, model Robinsona, dabing, povrch terénu a stávající modely zůstávají beze změny. Kontrolní skript `tools/check_gfx13_spring_cliff.py` porovnává aktivní JS se základem GFX12 po přesně vymezené vizuální substituci a ověřuje neměnnost ostatních souborů.
- `graphics/previews/spring-cliff-gfx13-offline.png` je rasterizace **skutečných trojúhelníků** GLB, ale není snímkem běžící hry a neukazuje animovanou vodu. Jde o stylizovanou PBR geometrii, nikoli fotorealistickou podobu předlohy.
- Statický audit, syntaxe a offline validace GLB prošly. Vizuální vykreslení neověřeno; skutečný výkon na iPhonu, působení modelu při pohybu kamery a noční světlo je nutné otestovat ve WebGL.

## GFX 14 · Tropické palmy, úspornější GLB (2026-09-22)

- `assets/models/palm.glb` má nový **originální procedurální 3D model**: jeden zakřivený zužující se kmen s povrchovými segmenty kůry, deset klenutých palmových listů s párovými lístky a kokosové ořechy. Materiály jsou matné PBR; nepoužity externí, placené ani licenčně nejasné assety.
- Snížení počtu mesh skupin jedné palmy z 19 na 5 při 1 700 trojúhelnících (dříve 1 352); toto omezuje teoretický počet vykreslovacích volání u opakovaných GLB instancí. Nejde o naměřené zrychlení FPS.
- Původní načítání `palm.glb` a samostatný původní procedurální fallback se nemění. Všechna umístění stromů, kolize a ostatní herní soubory zůstávají beze změn.
- Reprodukovatelná tvorba: `python tools/generate_palm_gfx14.py`; náhled skutečných GLB trojúhelníků: `python tools/preview_palm_gfx14.py`. Náhled NENÍ screenshot běžící hry.
- Statický audit, validace modelu, regresní porovnání všech herních JS a syntaxe prošly. Vizuální vykreslení neověřeno. Vykreslování/FPS na skutečném iPhonu a načtení přes Vercel je nutné zkontrolovat po nasazení do testovacího prostředí.

## GFX 15 · Vodní filtr a signální stanoviště jako lokální GLB (2026-09-22)

- Vytvořeny dva nové **originální lokální GLB modely**: `assets/models/filter.glb` (dvousloupkový vodní filtr s listovým trychtýřem, provazovým svodem, sudovou nádrží a kamenným podložím) a `assets/models/signal.glb` (A-rámové signální stanoviště s plošinou, stožárem, košem ohně a plachtovými praporky). Oba modely vznikly skriptem `tools/generate_filter_signal_assets.py` bez externích textur, cizích nebo placených assetů.
- Aktivní `src/game_logic.js` nyní načítá nové modely v **aktuální Three.js renderovací cestě** pouze pro dokončené stavby `filter` a `signal`; při selhání načtení zůstává původní procedurální geometrie beze změny.
- Zachováno: herní pravidla, kolize, potřeby pro stavbu, questy, dabing, save klíč i formát uložení. Jde pouze o vizuální náhradu dokončených stavenišť.
- `tools/preview_filter_signal_assets.py` vytváří offline náhled skutečných GLB trojúhelníků v `graphics/previews/sites-gfx15-offline.png`; nejde o screenshot běžící hry.
- Statický audit, syntaxe `renderer.js`, `main.js`, `game_logic.js` a GLB kontrola prošly. Vizuální vykreslení v běžící hře a výkon na iPhonu zatím neověřeny.

## GFX 16 · Oprava zásahu do zeleného pole rybářské minihry (2026-09-22)

- Původní vyhodnocení zásahu používalo aktuální čas z `mini.t` až při události `click` (u dotyku až po uvolnění). Ukazatel se mezitím mohl přesunout mimo zelené pole, přestože byl při stisknutí viditelně v něm.
- Zásah `ZASÁHNOUT` se nyní pro myš a dotyk vyhodnocuje při `pointerdown` ze **skutečně poslední zobrazené pozice** ukazatele; přidaná ochrana proti dvojímu započtení následným `click`. Klávesnice/asistivní aktivace zůstávají podporovány prostřednictvím `click` s `detail=0`.
- Kreslení zelené oblasti 40–61 % a logika uznání zásahu používají společné konstanty; na hranách je tolerance 1,5 procentního bodu kvůli šířce ukazatele. Ostatní pravidla (tři zásahy, nejvýše sedm pokusů, XP limit a ryby) jsou zachována.
- Přidán čistý modul `src/fishing_timing.js` a test `node --test tools/test_fishing_timing.mjs` pro hranice zeleného pole a dlouhý dotyk. Uložené pozice, dabing, grafické modely ani systém příběhu nebyly měněny.
- Kontroly syntaxe a statický grafický audit prošly; skutečný dotyk na iPhonu a vykreslení WebGL nejsou tímto offline testem ověřeny.

## GFX 17 · Jemná textura terénu a mokrý povrch (2026-09-22)

- Pouze aktivní `src/renderer.js`: jemná procedurální, bezešvá 128×128 neutrální textura na již existujícím terénu. UV souřadnice se odvozují z původních vrcholů beze změny poloh či kolizí; žádné externí obrázky ani nové draw calls pro objekty.
- Při dešti a bouři se mírně mění PBR drsnost a tón **pouze** materiálu terénu. Survival hodnoty, meteorologická logika, herní čas a ukládání se nemění.
- Zachována oprava rybářské minihry z GFX 16 a všechny stávající lokální GLB modely a dabing.
- Cíl je přiblížit uvěřitelnější barevné a materiálové podání pobřeží, ne napodobit licencované modely či prohlásit hru za graficky totožnou s Bootstrap Island.
- Statický audit, syntaxe, rybářské regresní testy a kontrola ZIP jsou offline; reálné vizuální vykreslení a FPS na iPhonu nebyly ověřeny.

## GFX 18 · Nenápadná navigační šipka nad Robinsonem (2026-09-22)

- Do aktivní renderovací cesty v `src/game_logic.js` přidána **jemná šipka nad hlavou Robinsona**, která se horizontálně natáčí směrem k aktuálnímu cíli úkolu.
- Šipka používá stejný zdroj pravdy jako deník úkolů: aktivní úkol z `currentQuest()` a příslušný objekt ve světě pouze pokud je skutečně dostupný (`objectAvailable`).
- Marker je úmyslně nenápadný: malý zlatohnědý ukazatel s lehkým pohupem, bez zásahu do kolizí, save dat, pravidel hry nebo příběhu.
- Pokud je hráč prakticky u cíle, šipka se skryje, aby zbytečně nerušila.
- Statická kontrola syntaxe a offline grafický audit prošly; vizuální chování ověřeno jen kódem, ne na reálném iPhonu.

## GFX 19 · Čitelnější směrová šipka nad Robinsonem (2026-09-22)

- Původní šipka z pěti až šesti samostatně vykreslovaných 3D primitivů v `src/game_logic.js` nahrazena jediným neinteraktivním SVG v `index.html`. Je umístěna nad promítnutou hlavou Robinsona a otáčí se podle směru aktuálního objektu úkolu v rovině kamery. Zůstává jemná a malá i na mobilu.
- Nový čistě matematický `src/quest_pointer.js` počítá projekci z aktuálního kamerového prostoru do CSS pixelů. Skrývá značku mimo obraz, za kamerou, při chybějícím cíli a v interakční blízkosti. Při otevřeném menu, rybářské minihře nebo před zahájením hry je značka vypnutá.
- Ukazatel nyní směřuje na aktivní objekt úkolu i během dočasného cooldownu sběru, místo aby kvůli cooldownu nečekaně zmizel. Žádná nová herní akce nebo změna úkolu z toho neplyne.
- Regresní kontrola dokládá nezměněný herní a save kód mimo vymezenou navigační úpravu a identitu ostatních 164 souborů vůči GFX18. Testy orientace a zobrazení pokrývají rozměry 390×844 a 844×390.
- Vizuální vykreslení neověřeno v běžící WebGL hře ani na reálném iPhonu; automatizované testy ověřují projekční výpočty, syntax a strukturu, nikoli reálný výkon nebo grafický vzhled.

## 3.0 ALFA 1 · Logistika výprav (2026-09-23)

- V aktivní herní cestě vznikl originální procedurálně vykreslovaný táborový sklad. Má tři skutečné stavební etapy a interakční menu u dokončené stavby; není potřeba externí licence nebo síťový asset.
- Nové `src/camp_logistics.js` nabízí otestované přesuny surovin mezi batohem a skladem, limit 120 jednotek hmotnosti, měření zátěže a vliv na chůzi bez tvrdého zákazu sběru.
- Přidán vyrobitelný výpravní batoh; stav skladu se ukládá do každé stávající herní pozice zvlášť. Stávající questy, původní modely a hlavní příběh zůstaly beze změny.
- Kontroly modulových testů a grafického auditu jsou offline; reálné WebGL/iPhone vykreslení neověřeno. Současný Robinson pořád nemá skutečný glTF skin.
