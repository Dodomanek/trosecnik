# Trosečník 3D 3.2 – finální grafická verze pro Vercel

Balík obsahuje hratelnou verzi 3.2 s novými materiály terénu, vodou, trávou, listovím, palmami, detaily tábora a animovaným ohněm. Český dabing, příběh, herní mechaniky 3.2 a formát uložených pozic zůstávají zachované.

## Nasazení
Rozbalte ZIP a nahrajte jeho obsah do kořene repozitáře propojeného s Vercel. Soubor index.html musí být přímo v kořeni. Framework nastavte na Other, Build Command ponechte prázdný a publikujte kořen projektu. Balík je statický a nevyžaduje instalaci balíčků. K načtení knihovny Three.js potřebuje internet. Nasazení nebylo provedeno.

## Ověření 26. 9. 2026
- 50 z 50 regresních testů prošlo.
- Skutečný Chromium: pohyb, otáčení, přepnutí kamer, rozměry 1280 × 720, 390 × 844 a 844 × 390, přepnutí nízké/vysoké kvality; bez chyb konzole a přetečení šířky.
- Ve všech 10 kontrolních stavech nulový počet NaN/Inf v osmi kontrolovaných renderovacích bufferech. Opraveny neplatné hodnoty shaderu kamenů a okrajů plamene, které bloom rozšiřoval do černých ploch.
- ZIP ověřen kontrolou CRC a přesnou shodou každého souboru se zdrojem.
- Mobilní rozměry byly simulované v Chromium; fyzický telefon a Safari nebyly ověřeny. Výkon na konkrétním telefonu není změřen.

Texturový atlas vznikl pomocí OpenAI ImageGen. Higgsfield generování odmítl kvůli tarifu účtu a nebyl použit. Původ textury a zadání jsou v assets/textures/PROVENANCE.md. Nové palmy a koruny stromů mají přiložené generátory v tools/.
