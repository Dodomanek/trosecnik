# TROSEČNÍK 3D 3.1 – Survival Expedition

Vercel-ready statický balík. Bez build kroku.

## Upgrade 3.1
- první osoba s viditelnými pažemi, nohami a vybavenou zbraní
- přepnutí 1./3. osoby klávesou V
- boj pěstmi, kyjem, kopím, zpevněným kopím, sekerou, pazourkovým nožem a kladivem
- různé poškození, dosah, rychlost a spotřeba energie
- smrt Robinsona, checkpoint posledního splněného úkolu a ztráta části zásob
- další recepty: kyj, zpevněné kopí, kamenné kladivo, listová zbroj
- 19 dovedností až do úrovně 15+
- směrová šipka k aktivnímu úkolu
- rotující minimapa a velká fog-of-war mapa průzkumu (M)
- nové rizikové zóny: mlžný les, ostrá rokle a černá pláž navíc k existujícím oblastem
- dabing zůstává lokálně v assets/audio/dialogue
- PCF soft shadows 2048, SSAO, jemný bloom, dynamická mlha, denní obloha, upravené materiály a voda
- vyleštěnější UI a post-processing
