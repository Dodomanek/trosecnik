# Trosečník 3D 3.2 · Tábor a souboje

Připravená lokální aktualizace ze zdrojového ZIPu 3.1 a dodaného balíčku GFX20. Nikam nebyla nasazena.

## Co je nové

- **Kanec:** 0,95 s přípravy s varováním a označením směru, poté přímý výpad. Uhni do strany. Po výpadu se 1,8 s zotavuje a dostává o 35 % vyšší poškození. Jeden výpad tě zasáhne nejvýše jednou. Útok hráče znovu kontroluje dosah při dopadu. Kanec se natáčí, při přípravě se přikrčí, při běhu hýbe nohama; zásah krátce rozsvítí tělo a přehraje zvuk podle nastavení zvuku.
- **Přístřešek:** první etapa ukazuje nosnou kostru, druhá částečnou střechu, třetí hotový model.
- **Sušák:** u tábora postav tři etapy. Vlož přes AKCE jednu syrovou rybu; po 60 sekundách aktivního hraní vyzvedni dvě sušené porce. Sůl není potřeba. Během otevřené nabídky a mimo hru sušení neběží.
- **Sběrač vody:** za deště ukládá až 70 bodů pitné vody. AKCE doplní žízeň; nevyužitá voda zůstane uvnitř. Za jasna nová voda nepřibývá.
- **Pracovní stůl:** tři etapy; po dokončení otevírá Výrobu. Receptům s nejméně dvěma vlákny trvale ubere jedno vlákno z ceny. Stejná cena platí ve výrobě i na HUDu.
- **Připnutí receptu:** ve Výrobě zvol „Připnout na HUD“. Sleduje jeden recept a skutečně chybějící suroviny v batohu, včetně úspory pracovního stolu. Materiál ve skladu nejprve vyzvedni. Stejným tlačítkem recept odepneš; výběr se ukládá.
- **GFX20:** převzaté `rock.glb` a `canopy.glb`, jejich generovací zdroje a aktivní integrace. Při nedostupném modelu zůstávají původní procedurální skály/stromy.
- **Grafické opravy:** opravená kompilace vodního shaderu a skrývání celého Robinsona v první osobě.

## Spuštění

Rozbal celý ZIP. V rozbalené složce spusť například `python3 -m http.server 8000` a otevři `http://localhost:8000`. Hra nepotřebuje sestavení. Three.js se stejně jako dříve načítá z CDN, proto je potřeba připojení. Pouhé otevření index.html přes file:// není podporované spuštění modulů.

Pro budoucí statický hosting patří index.html, src/, assets/ a vercel.json do kořene projektu. Tento balíček žádné nasazení neprovedl.

## Uložené pozice a dabing

Klíč úložiště i datová verze 2 zůstávají zachované. Existující pozice 3.1 doplní nové stavby hodnotou 0; inventář, sklad, příběh a původní stavby zůstanou zachované. Nové údaje jsou doplňující položky v existujících flags/built. Pro přenos na jinou adresu použij export/import v menu — prohlížeč nesdílí úložiště mezi doménami. Před výměnou vlastní hry si exportuj důležité pozice.

České audio a src/voice.js jsou byte po bytu shodné se zdrojem 3.1. Žádná nová kapitola ani společník nepřibyli.

## Ověření a hranice

Viz `TEST_REPORT_3_2.md`. Automatické testy: `node --test tools/test_*.mjs`. Strukturní grafický audit: `node tools/graphics_agent.mjs audit`.

Higgsfield byl skutečně osloven pro herní texturu, ale vrátil „Requires basic plan or higher“. Nevznikl žádný výstup ani generovací job a nebyl koupen tarif. Požadavek na Higgsfield grafiku čeká na volbu uživatele; tento ZIP žádné Higgsfield obrázky neobsahuje.

Desktopový WebGL a rozměry 390×844 / 844×390 byly ověřeny v Chromium. Skutečné zařízení iPhone, jeho FPS, dotykové ovládání a Safari zatím ověřeny nejsou. Styl zůstává stylizovaná low-poly hra, nikoli fotorealistická přestavba.
