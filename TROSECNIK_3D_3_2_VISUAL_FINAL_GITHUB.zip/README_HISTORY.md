# Trosečník 3D 2.4.1: Cesta za obzor

Tento samostatný projekt navazuje na verzi 2.3. Zpřísňuje úvod a po stavbě nouzového majáku přidává čtvrtou příběhovou kapitolu **Ztracená expedice**.

## Co je ve hře

- Celkem **59 záznamů v hlavní posloupnosti úkolů**, z toho několik je alternativních podle toho, zda přežije Mára, nebo Ivo. Nový úvod obsahuje 15 mezikroků a čtvrtá kapitola 22 navazujících úkolů.
- Úvod: bedna s menším množstvím zásob → dřevo, kámen, vlákna, kokos → obhlídka tábora → opakované napití u pramene → provaz, troud → ohniště → ryba → vaření → přístřešek → spánek → návod na sekeru → násada a sekera → vrak → lodní zápisník → filtr vody → signál.
- Recepty se postupně odemykají podle příběhu a materiály se skutečně spotřebovávají. K prvnímu ohni je nutný provaz a troud, přístřešek rovněž vyžaduje provaz. Sekera vyžaduje zhotovenou násadu.
- Čtvrtá kapitola: zachycený zápis, kartografická schránka, kompas, cesta severozápadním lesem, třístupňová lávka, vyproštění Jany, ošetření, pryskyřice, voděodolné pouzdro, archiv v mokřadu, východní radiostanice, generátor, hádanka se třemi číslicemi, jižní evakuační bod, světlice, molo, závěrečné zásoby a odplutí.
- Původní ostrov 2.3 a čtyři vzdálené oblasti zůstávají; v nich se nachází 19 dalších 3D interakčních míst a nová postava Jana. Lokace využívají stylizované geometrické objekty a dosavadní herní engine, nejde o fotorealistické prostředí.
- Zachované jsou Mára, Ivo a rozhodnutí s následky, XP, dovednosti, hlad, žízeň, zranění, chlad, divočáci, 3 pozice, export/import záloh, mobilní joystick a ↩ odblokování.

## Záchrana uložené hry

Před nahrazením stávajícího webu exportuj v menu každou důležitou pozici. Verze 2.4 používá stejný klíč úložiště jako 2.3 a rozpoznává starý postup. Pokud byla ve staré pozici hotová první velká stavba nebo vrak, její úvodní mezikroky se při migraci označí jako dokončené **bez opětovného udělení XP**. Čerstvá pozice prochází prodlouženým začátkem. Import není určený pro starou generaci 0.x.

## Vercel

Rozbal ZIP. V kořenové složce projektu musí být `index.html`, `src/`, `assets/`, `manifest.webmanifest` a `vercel.json`. Není potřeba npm ani build. Na Vercelu použij Framework Preset `Other`. Tato verze nebyla na Vercel nasazena automaticky.

Three.js a GLTFLoader se načítají z veřejného CDN a vyžadují internet. Model Robinsona `assets/models/robinson.glb` je v balíčku lokálně. Ostatní externí modely jsou volitelné.

## Ověření a omezení

Syntaxe herních skriptů je zkontrolována. Průchod od prvního úkolu do závěru byl ověřen logickými testy pro obě příběhové větve s doplňováním testovacích surovin a přesunem hráče k interakčním místům. V testu fungovalo ukládání, obnovení pozic a první zachycení ryby v minihře. Tato kontrola **neprokazuje, že člověk dokáže dohrát celou hru bez pomoci**, ani nedokládá plynulost a skutečné vykreslení na GPU iPhonu. Grafiku je třeba prověřit na reálném zařízení. Hra není profesionálně animovaná ani fotorealistická.

## Přírůstek 2.4.1: měření doby hry (vývojový mezikrok)

- Deník ukazuje skutečnou aktivní dobu hry a orientační dobu strávenou na jednotlivých splněných úkolech. Čas menu a neaktivních karet se nezapočítává; rybářská minihra ano.
- Čas je uložen pro každou ukládací pozici zvlášť a je součástí exportované JSON zálohy. Staré pozice zůstanou kompatibilní, nově měřený čas začíná nulou.
- Naměřená délka není vyhodnocením 20hodinového cíle. Ten musí být potvrzen průchodem skutečných hráčů bez doplňování surovin.
- Ostatní 3D modely, podmínky úkolů, výroba a příběh jsou beze změny.

## Grafický agent (vývojové rozšíření)

Ve složce projektu je `AGENTS.md` s pravidly samostatného grafického vývoje pro Codex, `graphics/BRIEF.md` a `graphics/BACKLOG.md` se zadáním a prioritami, a `tools/graphics_agent.mjs` s offline auditem GLB modelů a zdrojů. Spuštění: `node tools/graphics_agent.mjs audit`; výsledný `graphics/REPORT.md` obsahuje konkrétní nálezy. GitHub Action `.github/workflows/graphics-audit.yml` audit provede na změně zdrojových grafických souborů, pokud celý projekt uložíš do repozitáře v jeho kořeni.

Pro diagnostiku skutečného vykreslování otevři web s `?gfxdebug=1`. V testovacím překrytí uvidíš orientační FPS, počet vykreslovacích volání, trojúhelníků, rozlišení a stav načtení Robinsona. Překrytí nemění hru a při běžném spuštění se nezobrazuje. Tyto hodnoty je nutné změřit na konkrétním telefonu, nejsou zárukou výkonu.

**Zjištění prvního auditu:** současný `robinson.glb` má animace a geometrii, ale **nemá glTF skin**, takže nejde o profesionálně skinovaného humanoida. Grafický agent má tuto skutečnost řešit při další výměně modelu, nikoli tvrdit, že už je postava fotorealistická.

**Omezení autonomie:** AGENTS.md je instrukční soubor pro Codex nad zpřístupněným repozitářem; script sám negeneruje assety ani neprovádí grafické změny. Změny velkého rozsahu vyžadují předchozí souhlas uživatele. Verze 2.4.1 s agentem není automaticky nasazena do GitHubu nebo Vercelu.

## Verze 2.4.2 · český dabing

Tato verze obsahuje všech 112 souborů dodaných hráčem: 64 Robinson, 25 Mára, 23 Ivo. Nahrávky jsou součástí projektu v `assets/audio/dialogue/<postava>/<id>.mp3`; nejde o odkazy na externí audio služby. Soubor `assets/audio/dialogue/captions.json` obsahuje předběžné titulky podle původního scénáře (text hlasů nebyl automaticky přepisován z MP3).

Nový `src/voice.js` řídí hlasové fronty a titulky. Vázané události: úvod, vybrané úkoly a sběr, první a opakované rozhovory s Márou/Ivem, nález úkrytu, osudová volba a obě varianty závěrečného vysílání. Repliky druhé příběhové větve se nepřehrají v dané uložené pozici. Pozdější kapitola s Janou nemá dodané hlasové nahrávky a její textové dialogy zůstávají beze změny.

Ovládání: titulky zobrazují právě hranou repliku; tlačítko `Přeskočit` přeskočí jednotlivé audio bez změny herního stavu, `▶` ji přehraje znovu. V menu `Hra a nastavení` jsou přepínač dabingu a hlasitost. Hlavní přepínač zvuku hry vypíná také hlas. Po zahájení hry může iPhone vyžadovat první klepnutí na `▶` pro povolení přehrávání. Původní herní data / klíče ukládání zůstávají beze změny.

**Nasazení:** ZIP rozbal tak, aby `index.html`, `src/`, `assets/` a `vercel.json` byly v kořenové složce publikovaného projektu. Není potřeba buildovací krok ani externí zdroj dabingu. Three.js se nadále načítá z veřejného CDN, takže 2.4.2 není plně offline. Nejde o nasazenou ani na GPU telefonu vizuálně ověřenou verzi.

**Poznámka k testům:** Kontrola syntaxe JavaScriptu, souhlas názvů MP3 s titulky, platnost MP3 hlaviček a izolovaný test přehrávací logiky prošly. Skutečný poslech dialogů, časování titulků podle konkrétních nahrávek, vzhled a FPS na iPhonu je ještě nutné ověřit na zařízení.

## GFX 10: originální modely tábora

Dva nové lokální assety `assets/models/shelter.glb` a `assets/models/campfire.glb` obsahují geometrii a PBR materiály bez externích licencí. Jejich zdrojovým generátorem je `python tools/generate_camp_assets.py` (vyžaduje `trimesh`, `numpy`). Zobrazují se jen u kompletně postaveného přístřešku / ohniště; pokud načtení selže, zůstane původní procedurální model. Animace plamene zůstává v původní vykreslovací cestě.

Nejde o kompletní grafickou proměnu ani ověřený WebGL/iPhone release. Offline modelový náhled lze přegenerovat `python tools/preview_camp_assets.py` (Pillow, trimesh, numpy); náhled neprokazuje skutečný render ve hře. Uložený postup a původní herní logika nejsou úmyslně měněné.

### GFX 12 · Vrak Esperanzy

Nový volitelný originální model `assets/models/wreck.glb` se zapojí na původním místě ve hře; při selhání načtení zůstane původní procedurální vrak. Model obnovíš příkazem `python tools/generate_wreck_asset.py`, offline regresní kontrolu spustíš přes `python tools/check_gfx12_wreck.py` a náhled skutečné GLB geometrie přes `python tools/preview_wreck_asset.py`. Náhled není screenshot z běžící hry. Neověřeno na skutečném iPhonu.

## GFX 13 · Skalní stěna u pramene

Nový lokální `assets/models/spring_cliff.glb` přidává vrstvené kameny, pukliny, mech, liány a kapradiny za již existující animovaný vodopád. Původní statická skalní stěna zůstává fallbackem. Nedotčeny jsou interakce pramene, kolize, herní pravidla a uložený postup. Regenerace: `python tools/generate_spring_cliff.py`; strukturální a regresní kontrola: `python tools/check_gfx13_spring_cliff.py`; offline diagnostický náhled: `python tools/preview_spring_cliff.py`. Náhled není screenshot ze hry a iPhone FPS / skutečné vykreslení nebyly ověřeny.

## GFX 14 · Vercel balíček s novými palmami

Kořen ZIP archivu obsahuje přímo `index.html`, `src/`, `assets/`, `graphics/`, `tools/`, `manifest.webmanifest` a `vercel.json`. Vercel: import / drag-and-drop **obsahu rozbalené složky**, Framework Preset `Other`, build command prázdný; produkční nasazení nebylo provedeno.

Model `assets/models/palm.glb` nyní obsahuje originální stylizovaný tropický strom s detailnější korunou a pěti PBR mesh skupinami místo devatenácti. Generátor `python tools/generate_palm_gfx14.py` je součástí balíčku. Jde o vizuální úpravu modelu, nikoli fotorealistickou proměnu celého ostrova. Původní procedurální fallback zůstává aktivní při selhání načtení GLB. Herní skripty, příběh, pozice objektů, kolize, dabing a save data nebyly změněny.

Důležité: Three.js a GLTFLoader jsou stále načítány z CDN při otevření hry; nestačí jen uložit ZIP bez připojení k internetu. Vizuální vykreslení neověřeno na desktopu ani iPhonu; offline náhled v `graphics/previews/palm-gfx14-offline.png` není screenshot hry.


### GFX 16: oprava rybářské minihry
V rybářské minihře se zásah do zelené zóny vyhodnotí už při stisknutí tlačítka, nikoliv při opožděném uvolnění prstu. Opravené hranice zelené oblasti vycházejí ze stejných konstant jako její vykreslení. Kontrola: `node --test tools/test_fishing_timing.mjs`. Herní postup a uložené pozice nejsou resetovány.

## GFX 17 · Vercel vývojový balíček

Aktivní verze 2.4.2 navazuje na GFX 16 (opravené rybaření), přidává jemnou procedurální texturu stávajícího terénu a mokřejší vzhled při dešti. Nejde o úplné grafické přepracování podle hry Bootstrap Island ani o zkopírované assety. Herní logika, dabing, uložený postup i GLB modely jsou oproti GFX 16 beze změny.

ZIP má přímo v kořeni `index.html`, `src/`, `assets/` a `vercel.json`. Na Vercelu nastav Framework Preset `Other`, žádný build command; jde o vývojovou verzi bez produkčního nasazení. Three.js se načítá z veřejného CDN. Vizuální vykreslení a FPS na skutečném iPhonu nebyly ověřeny.


## GFX 18 · Navigační šipka nad Robinsonem

Aktivní render nyní zobrazuje malou nenápadnou šipku nad hlavou Robinsona, která ukazuje na aktuální cíl úkolu. Šipka se natáčí podle skutečné pozice questového objektu, lehce se pohupuje a u cíle mizí, aby nerušila. Jde pouze o vizuální navigaci — žádná pravidla, kolize, uložený postup ani quest logika se nemění.

## GFX 19 · Navigace na aktuální cíl nad Robinsonem

Dosavadní drobná šipka nad hlavou byla nahrazena promítaným SVG ukazatelem, který ukazuje v rovině obrazovky na pozici aktuálního úkolu a sleduje promítnutou pozici postavy. Při otočení kamery přepočítává směr, na dosah interakce mizí; nezakrývá dotykové prvky a nevyužívá další WebGL draw calls. Nenahrazuje automatické hledání cesty v terénu a nemusí ukazovat přesně po průchozí stezce. Není-li aktuální úkol svázán s místem ve světě, ukazatel se nezobrazí. Hratelnost a uložený postup zůstávají ve stejném formátu.

Offline testy: `node --test tools/test_quest_pointer.mjs tools/test_fishing_timing.mjs`, `python3 tools/check_gfx19_navigation.py` a `node tools/graphics_agent.mjs audit`. Testovací skripty ověřují kód a směry šipky, nikoli reálný WebGL render nebo FPS na iPhonu.

## SURVIVAL 20 · Omezené suroviny a delší výprava

Tato uživatelem schválená herní aktualizace navazuje na GFX 19. Deset nalezišť u prvního tábora má vždy nejvýše tři sběry na uloženou pozici; po vyčerpání už na stejném místě dřevo, kameny, vláknina ani kokosy znovu nevyrostou. Opakovaný sběr na dosud nevyčerpaném startovním místě je možný nejdříve po 3 minutách aktivní hry. Vzdálená naleziště se obnovují po nejméně 5 minutách; rybářské tůně po nejméně 90 sekundách od úspěšného úlovku. Když je zdroj pro aktuální úkol vyčerpaný, šipka a popis cíle přejdou na další dostupné naleziště stejného materiálu.

Před další kapitolou přibyly čtyři navazující hlavní úkoly: průzkum zátoky, mangrovů a severního hřebene a sestavení polní mapy u expedičního stolu. Přidávají cestování, orientaci, deníkové stopy a potřebu průběžně hlídat vodu a energii. Přesná délka nové výpravy nebyla změřena, a samotné čtyři úkoly nelze vydávat za mnoho dalších hodin hry.

Uložené pozice z předchozí verze lze dále načítat stejným klíčem. Pokud hráč už expedici dokončil, nová průzkumná etapa jej nevrátí zpět ani mu nepřidělí XP podruhé. Soubory s dabingem, grafickými modely a opraveným rybařením jsou zachované. Dokumentace změn a limity testů jsou v `gameplay/CHANGELOG.md`.

## SURVIVAL 21 · Výprava za třemi zásobovacími úkryty

Nová verze rozšiřuje čtyři průzkumné úkoly z verze SURVIVAL 20 o tři navazující jednorázové úkryty (pobřeží, mangrovy, hřeben) se skutečně vyzvednutelnými zásobami. Jsou dál od základního tábora, mají malé viditelné bedny a zmizí po vyzvednutí. Tím se prodlužuje samotná výprava a doplňují se materiály potřebné pro pozdější stavby bez obnovování původních nalezišť u tábora.

Uložené pozice se používají pod stejným klíčem a ve stejném formátu. Již splněný průzkum se neopakuje ani znovu neuděluje XP. Kontrola: `node --test tools/test_survival20.mjs tools/test_survival21.mjs tools/test_quest_pointer.mjs tools/test_fishing_timing.mjs`, `node tools/check_field_cache_sites.mjs` a `node tools/graphics_agent.mjs audit`. Reálná délka dohrání a běh na iPhonu nejsou změřeny. Tato vývojová verze není automaticky nasazená na Vercel.

## SURVIVAL 22 · Další suroviny a výrobky

Po výpravách do vzdálenějších oblastí může Robinson sbírat **rákos, jíl, pazourek, lesní bobule a mořskou sůl**. Hledej je v mangrovech, na horském hřebeni, u východní jeskyně, vzdálené zátoky a jižní laguny. Každá nová surovina má dvě naleziště mimo startovní tábor. Obnovují se po 320–360 sekundách aktivní hry na konkrétním místě; původní konečný limit surovin u tábora nebyl změněn.

V nabídce **Výroba a stavění** přibyly cestovní svačina, sušená ryba, bylinný obklad, hliněná čutora, rákosová rohož a pazourkový nůž. Vyrobenou čutoru lze opakovaně naplnit u přírodních pramenů nebo postaveného filtru a obsah vypít v batohu. Nůž trvale zvyšuje výtěžnost rákosu a bobulí, ostatní nové zásoby se spotřebují při použití. Nové volitelné milníky najdeš v deníku. Nijak nezadržují dosavadní hlavní úkoly. Staré uložené pozice mají stejnou save verzi a klíč; před nasazením nové verze doporučujeme exportovat zálohu.

Ověření: `node --test tools/test_*.mjs`, `node tools/graphics_agent.mjs audit`, `node --check src/game_logic.js` a `node --check src/resource_rules.js`. Jde o izolované/logické a statické kontroly, nikoliv o plný uživatelský průchod nebo měření FPS. Na Vercel nahraj obsah ZIP s `index.html` přímo v kořeni, Framework Preset `Other`, bez buildu.

## Trosečník 3D 3.0 ALFA 1 · Živý ostrov: logistika výprav

Tato verze je **první hratelný vývojový milník 3.0, ne hotová verze 3.0**. Navazuje na kompletní SURVIVAL 22, čtyři původní příběhové kapitoly, původní dabing, modely a úpravy rybářské minihry a navigace zůstávají v projektu. Nové funkce jsou integrované do **aktivního** `src/game_logic.js`, ne pouze do nevyužívaného `src/game.js`.

- **Táborový sklad:** nové fyzické stavební místo u tábora (`x=-5.9, z=3.1`), staví se třemi etapami z celkem 5 dřeva, 3 vláken a 2 kamenů. Po dokončení otevři sklad přímo tlačítkem AKCE u truhly. Ulož nebo vyzvedni jeden kus či veškeré dostupné množství. Sklad má nosnost 120 jednotek a přesun nikdy nepřekročí limit, zbytek surovin ponechá v původní tašce.
- **Uložené zásoby:** systém přijímá běžné materiály, potraviny a obvazy, nikoliv příběhové předměty, vyrobené nástroje či nový batoh. Obsah skladu je ve stávající herní pozici jako `storage`, zůstává zachován při uložení, načtení a exportu zálohy. U starých uložených her se bezpečně inicializuje prázdný sklad a nenaruší dosavadní questy.
- **Zátěž a výpravy:** batoh ukazuje aktuální hmotnost nesené výbavy a pohodlnou nosnost 28 jednotek. Při překročení limitu se pohyb postupně zpomalí, nejvíce na 55 % základní rychlosti; sbírání a dokončování úkolů se nezablokuje. Skladované suroviny se do váhy batohu nezapočítávají a recepty spotřebovávají pouze věci v batohu.
- **Výpravní batoh:** nový jednorázový vyrobitelný předmět z rákosu, vláken, provazu a dřeva. Zvyšuje pohodlnou nosnost na 46 jednotek. Vyrábí se ve stávající záložce Výroba, nijak nenahrazuje dosavadní příběhové vybavení.
- **Ovládání:** mobilní tlačítka skladu mají výšku alespoň 44 CSS px, uložení zásob lze provést jen u postavené truhly. Není třeba žádný nový npm balíček ani build.

**Omezení:** Jde o logistickou základnu 3.0, nikoliv o hotový grafický remake, nový ostrov, volně umisťované stavby nebo přepracovanou šestikapitolovou kampaň. Stávající grafické assety nejsou fotorealistické. Spuštění WebGL, ovládání a FPS na skutečném iPhonu nebyly v tomto offline prostředí ověřeny. Před nasazením exportuj rozehranou pozici; není provedeno automatické publikování na Vercel.

Pro offline regresní kontrolu: `node --test tools/test_*.mjs` a `node tools/graphics_agent.mjs audit`. Struktura Vercel ZIP má `index.html`, `src/`, `assets/` a `vercel.json` přímo v kořeni. Vercel Framework Preset `Other`, bez build command; Three.js se načítá z veřejného CDN a stále vyžaduje internet.
