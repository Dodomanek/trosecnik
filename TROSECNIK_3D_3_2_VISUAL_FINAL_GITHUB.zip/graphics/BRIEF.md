# Grafický agent: produkční brief

## Vizuální identita

Trosečník je uvěřitelná ostrovní survival hra. Přírodní materiály, věrohodné proporce, kontakt nohou s terénem, čitelné denní světlo a skutečná noc; žádné sci-fi neonové osvětlení. Přednost mají detaily viditelné při hraní: správná výška a proporce postav, stíny, vrstvy vegetace, orientace ve světě, pocit hmotnosti při práci a kamera bez poskakování. Neprezentuj současný geometrický model jako fotorealistický.

## Konkrétní grafické priority

1. Charakter Robinsona: ověř skeleton/skinning skutečného GLB, klipy Idle/Walk/Run/Work, pohyb rootu versus kostra, kontakt chodidel a smooth turning; fallback nesmí vstoupit do kamery.
2. Prostředí: kontrola velikostí stromů, kamenů a trosek, stínů a podkladových materiálů; rušivé zdvojování instancí a průniky do terénu.
3. Denní cyklus a počasí: noční čitelnost, mlha, jas, stíny; bouře nesmí znemožnit orientaci v nutných příběhových bodech.
4. iPhone: zachovat prostor pro joystick a interakční tlačítka, dotykové cíle ~44 CSS px, dynamické rozlišení pro starší zařízení, případné omezení stínů a počtu transparentních ploch.
5. Asset pipeline: lokální GLB, ověřená licence, smysluplné textury a PBR materiály, fallback, žádné expirované externí URL.

## Reprodukovatelný vizuální test

Před a po změně pořiď stejné scény: (a) pláž, (b) chůze vpřed kolem palem, (c) pramen a vrak, (d) tábor v noci, (e) džungle a horský hřeben. Zkontroluj rozlišení 390×844, 844×390 a 1280×720. Poznamenej zařízení, FPS a zda byly opravdu načteny GLB modely. Čistý screenshot HTML rozhraní bez fungujícího WebGL NEPROKAZUJE vzhled 3D světa.

## Měřitelné výkonnostní cíle, nikoli dosažené výsledky

Na cílovém iPhonu ideálně stabilních 30 FPS v otevřeném táboře a rozumnou odezvu ovládání; rozlišení vykreslování přizpůsobovat výkonu. Kvalitu stínů a počet opakovaných objektů ladit podle měření, ne libovolným zvýšením všech parametrů. Modely a textury redukovat s ohledem na kvalitu na displeji telefonu.

## Hranice autonomie

Agent může připravovat malé bezpečné grafické úpravy a porovnání bez schválení každého detailu. Přestavbu světa, modelový rework všech postav, změnu grafického enginu a produkční publikaci předkládá ke schválení uživateli.
