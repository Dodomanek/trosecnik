# Grafický audit 2026-09-26

**Kritické chyby:** 0 · **Upozornění:** 1

## Kontrolované modely

- **campfire.glb**: 0.03 MiB, 1940 trojúhelníků, 7 mesh, 0 glTF skinů, 0 textur, animace: žádné
- **canopy-refined.glb**: 0.07 MiB, 3244 trojúhelníků, 4 mesh, 0 glTF skinů, 0 textur, animace: žádné
- **canopy.glb**: 0.01 MiB, 680 trojúhelníků, 3 mesh, 0 glTF skinů, 0 textur, animace: žádné
- **crate.glb**: 0.01 MiB, 228 trojúhelníků, 19 mesh, 0 glTF skinů, 0 textur, animace: žádné
- **filter.glb**: 0.03 MiB, 1384 trojúhelníků, 11 mesh, 0 glTF skinů, 0 textur, animace: žádné
- **palm-refined.glb**: 0.04 MiB, 1400 trojúhelníků, 5 mesh, 0 glTF skinů, 0 textur, animace: žádné
- **palm.glb**: 0.05 MiB, 1700 trojúhelníků, 5 mesh, 0 glTF skinů, 0 textur, animace: žádné
- **robinson.glb**: 0.70 MiB, 6924 trojúhelníků, 54 mesh, 0 glTF skinů, 7 textur, animace: Idle, Walk, Run, Gather, Chop, Build, Drink, Rest
- **robinson_base.glb**: 0.41 MiB, 6924 trojúhelníků, 54 mesh, 0 glTF skinů, 1 textur, animace: Idle, Walk, Run, Gather, Chop, Build, Drink, Rest
- **rock.glb**: 0.01 MiB, 392 trojúhelníků, 3 mesh, 0 glTF skinů, 0 textur, animace: žádné
- **shelter.glb**: 0.11 MiB, 4408 trojúhelníků, 10 mesh, 0 glTF skinů, 0 textur, animace: žádné
- **signal.glb**: 0.03 MiB, 1400 trojúhelníků, 10 mesh, 0 glTF skinů, 0 textur, animace: žádné
- **spring_cliff.glb**: 0.14 MiB, 8820 trojúhelníků, 8 mesh, 0 glTF skinů, 0 textur, animace: žádné
- **wreck.glb**: 0.08 MiB, 4134 trojúhelníků, 9 mesh, 0 glTF skinů, 0 textur, animace: žádné

## Nálezy

- **WARN · Rig Robinsona:** GLB nemá glTF skin; není to profesionálně skinovaný humanoidní model

## Limity

Tento audit kontroluje pouze strukturu, formát a vybrané vzory zdrojového kódu. Neměří FPS, nekontroluje vzhled textur, nestartuje WebGL, nedokládá dohratelnost ani neprokazuje odstranění klepání. Pro grafické změny je nutný reálný vizuální test na zařízení.
