# Trosečník 3D 3.2 – GitHub zdrojový balík

Tento projekt vychází z přesně ověřené finální grafické verze pro Vercel. Herní soubory, modely, textury a dabing jsou shodné s finálním Vercel balíkem. Změny této distribuce jsou pouze dokumentace, vývojové nástroje a GitHub Actions; historické náhledové obrázky nejsou přibalené.

## Nahrání do GitHubu
1. Rozbalte ZIP na počítači.
2. V cílovém repozitáři otevřete Add file → Upload files, případně použijte GitHub Desktop.
3. Nahrajte obsah rozbaleného adresáře přímo do kořene repozitáře. Index.html, src/, assets/ a vercel.json nesmějí být uvnitř další obalové složky.
4. Přidejte také skryté .github/ a .gitignore. V macOS je zobrazíte pomocí Cmd + Shift + tečka. GitHub Desktop je zahrne běžně.
5. Potvrďte změny a v záložce Actions zkontrolujte výsledek Project checks.

Pouhé nahrání do GitHubu nezveřejní hru. Pro již propojený Vercel projekt se použije jeho nastavení nasazení. Tento balík sám nenastavuje GitHub Pages a žádný vzdálený repozitář nebyl změněn.

## Spuštění a kontroly
Z kořene projektu spusťte `python3 -m http.server 8000` a otevřete http://localhost:8000. Knihovna Three.js se načítá z CDN; potřebuje internet.

S Node.js 22 spusťte:

```sh
node --test tools/test_*.mjs
node tools/graphics_agent.mjs audit
```

GitHub Actions kontrolují syntaxi všech src/*.js a tools/*.mjs, regresní testy a grafický audit. Nevyžadují npm instalaci ani tajné klíče. Audit je statický; skutečné WebGL vykreslování není součástí Actions.

## Grafické zdroje
Původní atlas i přesný AI prompt jsou v assets/textures/. Pro převod atlasu a tvorbu modelů vytvořte Python prostředí a nainstalujte `pip install -r tools/requirements-graphics.txt`. Potom lze spustit:

```sh
python tools/generate_terrain_atlas.py
python tools/generate_canopy_refined.py
python tools/generate_palm_refined.py
```

Generátory přepisují příslušné odvozené assety; zazálohujte vlastní úpravy. Přegenerování AI zdrojového PNG vyžaduje samostatnou generaci podle uloženého promptu, není součástí skriptu. Starší generátory modelů jsou rovněž v tools/. Historické náhledy lze vytvořit pomocí preview skriptů, pokud jsou dostupné jejich závislosti.

- [Herní změny a ovládání](README_3_2.md)
- [Ověření finální grafiky a omezení](TEST_REPORT_VISUAL.md)
- [Testy mechanik](TEST_REPORT_3_2.md)
