# Ověření Trosečník 3D 3.2

Datum: 26. 9. 2026. Balíček nebyl nasazen do produkce.

## Zdroj a zachování dat

- Základ: přesný ZIP `TROSECNIK_3D_3_1_SURVIVAL_EXPEDITION_VERCEL (1).zip` z Dodomanek/trosecnik, větev main. Znovu stažený soubor odpovídá původní kopii SHA-256 `d7875e345c46489d2a7dae1957fe6118f76f407621b471f3e312f15f8d07da11`.
- Přidán uživatelův `TROSECNIK_3D_GFX20_rock_canopy.zip`: modely skal a korun stromů, generátory, dokumentace a renderovací integrace s fallbacky. Herní kód 3.1 nebyl nahrazen starší kopií.
- Aktivní vstup zůstává src/main.js → src/game_logic.js. Historický src/game.js se neměnil.
- Všechny původní audio soubory i src/voice.js jsou byte po bytu shodné se základem. Testy chrání původní úkoly, objekty a ceny původních staveb. Nové stavby jsou volitelné; nová kapitola ani společník nepřibyli.
- Klíč uložení a datová verze 2 jsou zachované. Test skutečného načítacího kódu ověřil doplnění nových staveb a zachování inventáře, skladu, příběhové volby a deníku.

## Automatické testy

`node --test tools/test_*.mjs`: **50 testů, 50 úspěšných, 0 chyb**.

Původních 39 testů zůstává aktivních. Historická srovnání byla rozšířena pouze o výjimky pro tři výslovně přidané stavby; test výroby dostal nové importované výpočetní funkce. Přibylo 11 testů pro:

- varování, uzamčený směr výpadu, úhyb, zotavení, jediný zásah a náraz do překážky;
- kontrolu dosahu skutečného útočného callbacku a bonus +35 % při zotavení;
- podmínky sběru deště, maximální zásobu a zachování nespotřebované vody;
- sušení, spotřebu ryby, dokončení po načtení a zákaz duplicitní odměny;
- shodné ceny výroby a HUDu, chybějící materiál a úsporu pracovního stolu;
- náklady tří etap, doplnění starých pozic a uchování nových údajů;
- přítomnost GFX20 modelů, integraci fallbacků a opravu shaderu.

Syntaxe src/main.js, src/renderer.js a src/game_logic.js prošla. Kontrola výšek příběhových úkrytů prošla. Grafický audit: **0 kritických chyb, 1 upozornění** na stávající model Robinsona bez glTF skinu.

## Běžící hra

Ověřeno v Chromium se skutečně fungujícím WebGL, nikoli pouze snímkem HTML:

- spuštění, interakce s první bednou a postup na další úkol; pohyb a tlačítko odblokování;
- tři etapy pracovního stolu, otevření výroby a skutečné odečtení zvýhodněného materiálu;
- připnutí receptu, změna požadavků podle inventáře a zachování připnutí po reloadu;
- tři etapy sušáku, vložení jedné ryby, opakovaná interakce bez druhé spotřeby, načtení rozpracovaného sušení a vyzvednutí dvou porcí;
- tři etapy sběrače a skutečné doplnění vody během deštivého herního dne;
- varování kance bez poškození během přípravy a skutečný úhyb do strany bez ztráty zdraví;
- přepnutí kamery; zobrazení při 1280×720, 390×844 a 844×390, dostupná výroba bez horizontálního přetečení;
- náhradní procedurální skály a stromy při záměrně zablokovaném načtení rock.glb/canopy.glb. Dvě očekávané síťové chyby v tomto testu nejsou chyby běžného načítání; herní běh zůstal bez výjimek.

Testy pokročilých mechanik používaly připravené pozice v izolovaném testovacím prohlížeči. Čas dokončení sušení byl pro test obnovené pozice posunut; nešlo o celou dohranou výpravu. Snímky před/po vznikly ze stejného výchozího stavu ve třech rozměrech. Původní shaderová chyba byla reprodukována před opravou; aktualizovaný běžný běh byl bez této chyby.

## Výslovné hranice

- Skutečný iPhone, Safari, fyzický dotyk, FPS a dlouhodobá stabilita na telefonu nejsou ověřené. Mobilní rozměry desktopového Chromium nejsou měření iPhonu.
- Celý příběh nebyl znovu dohrán od začátku do konce; jeho neměnnost chrání regresní testy a zachované zdrojové části.
- Higgsfield generate_image byl skutečně vyvolán pro jemnou herní texturu. Výsledek: **„Requires basic plan or higher“**, INVALID_ARGUMENT. Nevznikl obrázek ani job, nebyl koupen tarif a nebyl použit náhradní generátor. Tento požadavek čeká na rozhodnutí uživatele.

Import/export UI: PASS. Old save preserved HP 73, wood 9, storage fiber 8, story fate ivo. Export JSON independently verified.

Changed/added files: 23

- README.md
- README_3_2.md
- README_HISTORY.md
- TEST_REPORT_3_2.md
- assets/models/README.md
- assets/models/canopy.glb
- assets/models/rock.glb
- graphics/BACKLOG.md
- graphics/CHANGELOG.md
- graphics/REPORT.md
- index.html
- manifest.webmanifest
- src/game_logic.js
- src/renderer.js
- src/style.css
- src/survival32.js
- tools/generate_canopy.py
- tools/generate_rock.py
- tools/test_save32.mjs
- tools/test_survival20.mjs
- tools/test_survival21.mjs
- tools/test_survival22.mjs
- tools/test_survival32.mjs
