#!/usr/bin/env python3
"""GFX15: original local GLB models for water filter and signal station.
Reproducible, offline, no third-party or paid assets.
"""
from pathlib import Path
from collections import defaultdict
import math, random
import numpy as np
import trimesh
from trimesh.visual.material import PBRMaterial
from trimesh.visual.texture import TextureVisuals

OUT=Path(__file__).resolve().parents[1]/'assets'/'models'
rng=random.Random(241015)

PALETTE={
 'bark':(81,49,29,255),'wood':(124,80,43,255),'woodlight':(165,116,63,255),
 'wooddark':(53,36,25,255),'rope':(176,136,76,255),'leaf':(51,94,43,255),
 'leaflight':(91,125,58,255),'leafdark':(31,64,34,255),'canvas':(130,115,80,255),
 'stone':(90,91,84,255),'stoneLight':(133,130,109,255),'char':(38,31,28,255),
 'linen':(161,143,111,255),'water':(73,146,165,255),'metal':(96,104,108,255),
 'darkmetal':(49,57,60,255),'gold':(205,148,53,255),'ash':(170,161,128,255),
}

class Asset:
 def __init__(self):self.parts=defaultdict(list)
 def add(self,mesh,mat):
  mesh=mesh.copy();self.parts[mat].append(mesh)
 def box(self,extents,center,mat,rotation=0):
  m=trimesh.creation.box(extents=extents)
  if rotation:m.apply_transform(trimesh.transformations.rotation_matrix(rotation,[0,1,0]))
  m.apply_translation(center);self.add(m,mat)
 def beam(self,a,b,r,mat,sections=8):
  a,b=np.array(a,dtype=float),np.array(b,dtype=float);v=b-a;length=np.linalg.norm(v)
  if length<.0001:return
  mesh=trimesh.creation.cylinder(radius=r,height=length,sections=sections)
  mesh.apply_transform(trimesh.geometry.align_vectors([0,0,1],v/length));mesh.apply_translation((a+b)*.5)
  self.add(mesh,mat)
 def rock(self,center,radius,mat,seed):
  local=random.Random(seed);m=trimesh.creation.icosphere(subdivisions=1,radius=1)
  p=m.vertices.copy();p*=np.array(radius)[None,:]
  p*=np.array([[local.uniform(.86,1.15) for _ in range(3)] for __ in range(len(p))]);m.vertices=p
  m.apply_translation(center);self.add(m,mat)
 def disc(self,center,radius,height,mat,sections=18):
  m=trimesh.creation.cylinder(radius=radius,height=height,sections=sections)
  m.apply_translation(center);self.add(m,mat)
 def cone(self,center,radius,height,mat,sections=18,axis='y'):
  m=trimesh.creation.cone(radius=radius,height=height,sections=sections)
  if axis=='y':m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]))
  elif axis=='x':m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[0,0,1]))
  m.apply_translation(center);self.add(m,mat)
 def ribbon(self,points,widths,mat,twist=0):
  p=np.asarray(points,dtype=float);verts=[]
  for i,pt in enumerate(p):
   forward=p[min(i+1,len(p)-1)]-p[max(i-1,0)]
   perpendicular=np.cross(forward,[0,1,0]);
   if np.linalg.norm(perpendicular)<1e-8: perpendicular=np.array([1.,0.,0.])
   perpendicular/=max(1e-8,np.linalg.norm(perpendicular))
   angle=twist*math.sin(math.pi*i/max(1,len(p)-1));c=math.cos(angle);s=math.sin(angle)
   transverse=perpendicular*c+np.array([0.,1.,0.])*s
   verts.extend([pt-transverse*widths[i]*.5,pt+transverse*widths[i]*.5])
  faces=[]
  for j in range(len(p)-1):faces.extend([(2*j,2*j+1,2*j+2),(2*j+1,2*j+3,2*j+2)])
  mesh=trimesh.Trimesh(vertices=verts,faces=faces,process=False)
  self.add(mesh,mat)
  other=mesh.copy();other.faces=np.fliplr(other.faces);self.add(other,mat)
 def save(self,name):
  scene=trimesh.Scene();tris=0
  for mat,parts in self.parts.items():
   m=trimesh.util.concatenate(parts)
   m.visual=TextureVisuals(material=PBRMaterial(name=mat,baseColorFactor=PALETTE[mat],metallicFactor=0.0,roughnessFactor=.96,doubleSided=True))
   scene.add_geometry(m,node_name=mat,geom_name=mat)
   tris+=len(m.faces)
  path=OUT/name;path.write_bytes(scene.export(file_type='glb'))
  print(f'{name}: {tris} triangles, {len(self.parts)} meshes, {path.stat().st_size} bytes')
  return path

def water_filter():
 a=Asset()
 # dimensions follow existing site footprint without changing collisions
 for x in (-.48,.48):
  a.beam((x,.10,0),(x,2.22,0),.09,'bark')
  for off in (.03,.10):
   a.beam((x-.10,2.01+off,.08),(x+.10,2.03+off,-.08),.012,'rope',5)
 a.beam((-.54,2.22,0),(.54,2.22,0),.055,'wood')
 a.beam((-.54,1.98,-.34),(0.0,2.22,0),.045,'wood')
 a.beam((.54,1.98,-.34),(0.0,2.22,0),.045,'wood')
 # conical leaf funnel
 rim=[]
 for i in range(12):
  ang=math.tau*i/12
  rim.append((math.cos(ang)*.82,1.46+0.06*math.sin(ang*2),math.sin(ang)*.79))
  nxt=(i+1)%12
  ang2=math.tau*nxt/12
  p1=rim[-1]
  p2=(math.cos(ang2)*.82,1.46+0.06*math.sin(ang2*2),math.sin(ang2)*.79)
  tip=(0,.75,0)
  m=trimesh.Trimesh(vertices=[p1,p2,tip],faces=[[0,1,2]],process=False)
  a.add(m,'leaflight' if i%2 else 'leaf')
  m2=m.copy();m2.faces=np.fliplr(m2.faces);a.add(m2,'leaflight' if i%2 else 'leaf')
 # lashing ring and drip tube
 a.disc((0,1.46,0),.09,.07,'rope',12)
 a.beam((0,.75,0),(0,.38,0),.028,'rope')
 a.beam((0,.38,0),(.08,.30,.06),.022,'rope')
 # basin barrel with water
 for i in range(9):
  ang=math.tau*i/9
  a.beam((math.cos(ang)*.54,.14,math.sin(ang)*.54),(math.cos(ang)*.54,.62,math.sin(ang)*.54),.05,'woodlight')
 a.disc((0,.29,0),.58,.44,'wooddark',20)
 a.disc((0,.49,0),.47,.08,'water',20)
 a.beam((-.56,.50,0),(.56,.50,0),.022,'rope')
 # decorative stones and leaf mat under filter
 for i in range(6):
  ang=math.tau*i/6+.12
  a.rock((math.cos(ang)*.86,.07,math.sin(ang)*.74),(.18,.11,.14),'stone' if i%2 else 'stoneLight',310+i)
 for row in range(4):
  z=-.22+row*.15
  a.ribbon([(-.64,.04,z),(-.15,.05,z+.01),(.34,.05,z-.02),(.68,.04,z)], [.12,.11,.10,.08], 'leafdark' if row%2 else 'leaf', twist=.06)
 return a.save('filter.glb')

def signal_station():
 a=Asset()
 # A-frame supports and platform in the same site footprint.
 for side in (-1,1):
  a.beam((side*.72,.12,-.42),(side*.22,2.44,0),.11,'bark')
  a.beam((side*.72,.12,.42),(side*.22,2.44,0),.11,'bark')
  a.beam((side*.72,.12,-.42),(side*.72,.12,.42),.06,'wood')
 a.beam((-.82,2.42,0),(.82,2.42,0),.07,'wood')
 for z in (-.56,-.18,.18,.56): a.box((1.78,.11,.16),(0,2.42,z),'woodlight')
 for x in (-.58,0,.58): a.box((.14,.09,1.34),(x,2.49,0),'woodlight')
 # central mast and cross arm
 a.beam((0,2.52,0),(0,5.72,0),.085,'wooddark')
 a.beam((-.88,4.66,0),(.88,4.66,0),.055,'metal')
 a.beam((-.62,4.0,0),(0,5.56,0),.024,'rope')
 a.beam((.62,4.0,0),(0,5.56,0),.024,'rope')
 # beacon basket / brazier
 a.disc((0,2.86,0),.34,.20,'metal',14)
 for i in range(7):
  ang=math.tau*i/7
  a.beam((math.cos(ang)*.28,2.67,math.sin(ang)*.28),(math.cos(ang)*.18,3.08,math.sin(ang)*.18),.018,'metal')
 for i in range(6):
  a.box((.16,.07,.07),(math.cos(i)*.13,2.80,math.sin(i*1.7)*.11),'wood')
 for i in range(5):
  a.rock((rng.uniform(-.12,.12),2.75,rng.uniform(-.12,.12)),(.06,.04,.05),'ash',510+i)
 # stylized signal cone and pennants for silhouette readability
 a.cone((0,3.10,0),.23,.42,'gold',16)
 for side in (-1,1):
  pts=[(0,5.08,0),(side*.78,4.95,.03),(side*.45,4.58,.02),(side*.05,4.68,.01)]
  a.ribbon(pts,[.24,.29,.18,.06],'canvas' if side<0 else 'linen',twist=.14)
 # access ladder
 for i in range(5): a.box((.48,.05,.06),(-.92,.72+i*.34,0),'wood',0)
 a.beam((-.92,.36,0),(-.92,2.18,0),.042,'wood')
 a.beam((-.55,.40,-.55),(-.72,2.10,-.22),.02,'rope')
 a.beam((.55,.40,.55),(.72,2.10,.22),.02,'rope')
 return a.save('signal.glb')

if __name__=='__main__':
 OUT.mkdir(parents=True,exist_ok=True)
 water_filter();signal_station()
