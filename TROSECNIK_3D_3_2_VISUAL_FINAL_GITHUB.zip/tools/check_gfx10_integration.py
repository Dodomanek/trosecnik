"""Read-only regression guard for GFX 10 against unchanged previous release."""
from pathlib import Path
import zipfile,hashlib,trimesh
root=Path(__file__).resolve().parents[1]
prior=Path('/mnt/data/TROSECNIK_3D_2_4_2_GFX_9_CINEMATIC_ENVIRONMENT.zip')
source=(root/'src/game_logic.js').read_text()
assert "if(o.site==='fire'){if(!tryDrawGLB('campfire',T(x,y,z,1,1,1,0)))" in source
assert "if(o.site==='shelter'&&!tryDrawGLB('shelter',T(x,y,z,1,1,1,0)))" in source
assert "if(stage>=3)" in source
for name in ('shelter','campfire'):
 assert f"{{name:'{name}',url:'assets/models/{name}.glb'" in source
 scene=trimesh.load(root/'assets/models'/f'{name}.glb',force='scene')
 assert len(scene.geometry)>0
 assert scene.bounds[0][1]>-0.1 and scene.bounds[1][1]<3.0
 print('VALID MODEL',name,'meshes',len(scene.geometry),'triangles',sum(len(g.faces) for g in scene.geometry.values()))
# No gameplay change in any other existing JS, HTML, CSS, voice or save assets.
if prior.exists():
 with zipfile.ZipFile(prior) as z:
  priorfiles={str(Path(i.filename).relative_to('TROSECNIK_3D_2_4_2_GFX_9_CINEMATIC_ENVIRONMENT')): i for i in z.infolist() if not i.is_dir()}
  allowed={'src/game_logic.js','graphics/BACKLOG.md','graphics/CHANGELOG.md','graphics/REPORT.md','README.md'}
  unchanged=0
  for path,item in priorfiles.items():
   if path in allowed:continue
   current=root/path
   assert current.exists() and current.read_bytes()==z.read(item.filename),f'Unexpected mutation: {path}'
   unchanged+=1
  print('UNCHANGED PREVIOUS PROJECT FILES',unchanged)
  base=z.read(priorfiles['src/game_logic.js'].filename).decode()
  for text in ('function passable(', 'function safeForRecovery(', 'function makeRecipe(', 'function save(', 'function load('):
   def section(s,token):
    i=s.find(token);assert i!=-1,token
    return s[i:s.find('\n',i)]
   assert section(source,text)==section(base,text),f'Gameplay API changed: {text}'
  for needle in ("TROSECNIK_3D_2_0", "state.version", "assets/audio/dialogue"):
   assert source.count(needle)==base.count(needle),f'Unexpected save/audio token mutation: {needle}'
  print('PASS: gameplay function headers, save and audio signatures preserved')
print('PASS: asset registration, fallback logic and model bounds')
