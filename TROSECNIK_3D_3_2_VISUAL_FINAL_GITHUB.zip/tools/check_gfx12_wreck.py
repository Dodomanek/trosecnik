#!/usr/bin/env python3
"""Regression checks for the visual-only optional Esperanza shipwreck asset."""
from pathlib import Path
import zipfile
import numpy as np
import trimesh
ROOT=Path(__file__).resolve().parents[1]
PRIOR=Path('/mnt/data/TROSECNIK_3D_2_4_2_GFX_11_ROBINSON_MATERIALS.zip')
model=ROOT/'assets/models/wreck.glb'
scene=trimesh.load(model,force='scene')
assert len(scene.geometry)>=6,'expected several material groups'
triangles=sum(len(g.faces) for g in scene.geometry.values())
assert 2500<triangles<8000,triangles
bounds=scene.bounds
assert np.isfinite(bounds).all()
assert np.all(bounds[0]>[-4.9,-.12,-2.35]) and np.all(bounds[1]<[4.9,4.9,2.35]), bounds
assert model.stat().st_size<350_000, 'not mobile-budgeted'
for geom in scene.geometry.values():
 assert np.isfinite(geom.vertices).all() and len(geom.faces)>0
 assert geom.visual.material is not None, 'PBR material missing'
print('PASS: original wreck GLB loads offline; 3D bounds, materials and mobile triangle/size budget',triangles,model.stat().st_size)
source=(ROOT/'src/game_logic.js').read_text()
assert "wreckFallbackMesh=upload(wreckProcedural)" in source
assert "if(!tryDrawGLB('wreck',T(14.4,H(14.4,-11.3),-11.3,1,1,1,.28),[1,1,1]))draw(wreckFallbackMesh" in source
assert "{name:'wreck',url:'assets/models/wreck.glb',scale:1.0,yOffset:0}" in source
assert 'sceneObstacles.push({x,z,r:.50' in source
assert 'function passable(x,z)' in source
print('PASS: optional GLB registration, original-geometry fallback and unchanged world anchor')
assert PRIOR.is_file(), 'Previous release zip not found; cannot assert unmodified gameplay files'
with zipfile.ZipFile(PRIOR) as z:
 entries={str(Path(n).relative_to('TROSECNIK_3D_2_4_2_GFX_11_ROBINSON_MATERIALS')):n for n in z.namelist() if not n.endswith('/')}
 original=z.read(entries['src/game_logic.js']).decode()
 # Normalize ONLY the explicit visual substitutions and check the entire remainder byte for byte.
 restored=source.replace('let terrainMesh,seaMesh,staticMesh,staticPalmMesh,waterfallMesh,wreckFallbackMesh,campMesh,sceneObstacles=[],staticTrees=[];',
                         'let terrainMesh,seaMesh,staticMesh,staticPalmMesh,waterfallMesh,campMesh,sceneObstacles=[],staticTrees=[];')
 restored=restored.replace("// Optional GFX 12 visual: the original wreck is built in a separate static buffer\n// so a loaded GLB replaces it rather than drawing a second hull on top.\n// Wreck positions, interaction radii and terrain stay in the original game.\nlet wreckProcedural=mesh();\n",'')
 a=restored.index('// Wrecked ship Esperanza:')
 b=restored.index('// Spring: layered stone basin',a)
 part=restored[a:b].replace('wreckFallbackMesh=upload(wreckProcedural);\n','').replace('wreckProcedural','m')
 restored=restored[:a]+part+restored[b:]
 restored=restored.replace(";\n// Visual-only swap; show the original ship immediately while the optional GLB loads.\nif(!tryDrawGLB('wreck',T(14.4,H(14.4,-11.3),-11.3,1,1,1,.28),[1,1,1]))draw(wreckFallbackMesh,identity(),[1,1,1],0,0);\nif(waterfallMesh)", ";if(waterfallMesh)")
 restored=restored.replace("\n {name:'wreck',url:'assets/models/wreck.glb',scale:1.0,yOffset:0},",'')
 assert restored==original, 'Change outside explicit visual-only wreck replacement'
 n=0
 allowed={'src/game_logic.js','graphics/BACKLOG.md','graphics/CHANGELOG.md','graphics/REPORT.md','README.md'}
 for relative,name in entries.items():
  if relative in allowed:continue
  path=ROOT/relative
  assert path.is_file() and path.read_bytes()==z.read(name),f'Unexpected old file mutation: {relative}'
  n+=1
 print(f'PASS: whole original game_logic.js restored exactly after removing visual-only change; {n} previous files unchanged')
print('PASS: no gameplay, save, dubbing, quest, original model or UI file changed')
