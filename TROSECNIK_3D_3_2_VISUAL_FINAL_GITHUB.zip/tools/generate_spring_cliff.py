#!/usr/bin/env python3
"""Deterministic original waterfall backdrop GLB. Local x/z origin: existing spring cliff anchor.
Only visual geometry; no physics, gameplay data, external texture, or third-party assets.
"""
from collections import defaultdict
from pathlib import Path
import math, random
import numpy as np
import trimesh
from trimesh.visual.material import PBRMaterial
from trimesh.visual.texture import TextureVisuals

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets/models/spring_cliff.glb'
R=random.Random(24213)
PALETTE={
 'basalt':(66,72,69,255),'slate':(91,99,91,255),
 'warmstone':(132,123,104,255),'shadowcrack':(43,48,43,255),
 'moss':(48,78,49,255),'fern':(49,101,51,255),
 'fern_light':(78,124,64,255),'root':(73,57,39,255),
}
parts=defaultdict(list)

def add(g,mat):
 if g is not None and len(g.faces): parts[mat].append(g)

def rock(pos,size,mat,seed):
 # Distorted low-poly boulders have facet normals rather than placeholder spheres.
 rng=random.Random(500+seed)
 g=trimesh.creation.icosphere(subdivisions=1,radius=1)
 p=np.array(g.vertices,dtype=float)
 for i,v in enumerate(p):
  bump=.83+.32*rng.random()
  p[i]=v*bump
 p*=np.array(size)
 g.vertices=p
 g.apply_transform(trimesh.transformations.rotation_matrix(rng.uniform(-.22,.22),[0,1,0]))
 g.apply_translation(pos)
 add(g,mat)

def beam(a,b,r,mat,sides=5):
 a,b=np.asarray(a),np.asarray(b);v=b-a
 l=np.linalg.norm(v)
 if l<1e-6:return
 g=trimesh.creation.cylinder(radius=r,height=l,sections=sides)
 g.apply_transform(trimesh.geometry.align_vectors([0,0,1],v/l))
 g.apply_translation((a+b)*.5)
 add(g,mat)

def leaf(a,b,width,mat):
 # Narrow double-sided tapered leaves, intentionally opaque: no alpha overdraw on iPhone.
 a=np.asarray(a,dtype=float);b=np.asarray(b,dtype=float)
 v=b-a;side=np.cross(v,[0,1,0]);n=np.linalg.norm(side)
 if n<1e-4:side=np.array([1.,0,0])
 else:side/=n
 mid=(a+b)*.5+np.array([0,.06,0]); tip=b
 pts=np.vstack([a,mid+side*width,tip,mid-side*width]);faces=np.array([[0,1,2],[0,2,3],[2,1,0],[3,2,0]])
 add(trimesh.Trimesh(vertices=pts,faces=faces,process=False),mat)

# A staggered three-level rock wall behind the existing animated water sheet (front z=-.72).
# Keep its footprint close to the legacy boulder arrangement, well clear of game paths.
for layer,(z,height,spread) in enumerate(((1.05,1.45,2.5),(.80,2.4,2.1),(1.22,3.25,1.75))):
 for row in range(2 if layer<2 else 1):
  for j in range(9 if layer<2 else 7):
   count=9 if layer<2 else 7
   x=(j-(count-1)/2)*spread/((count-1)/2)
   if abs(x)<.83 and layer<2 and row==0:
    zoff=.45 # Central outflow stays behind the water, not across it.
   else:zoff=0
   yy=height+row*.57+.13*math.sin(j*1.7+layer)
   rr=R.uniform(.44,.75)
   rock((x+R.uniform(-.13,.13),yy,z+zoff+R.uniform(-.13,.15)),
        (rr*1.28,R.uniform(.66,.90),R.uniform(.46,.68)),
        ('basalt','slate','warmstone')[(j+layer+row)%3],100+layer*30+row*11+j)
# Side buttresses frame the waterfall rather than occluding the animated sheet.
for side in (-1,1):
 for i in range(8):
  xx=side*(1.15+(i%3)*.36); yy=.33+(i//3)*.99+R.uniform(-.15,.12)
  rock((xx,yy,.11+(i%2)*.29),(.62,.65,.61),'slate' if i%2 else 'basalt',400+i+side*20)
# Broken ledges and short crevice bands create an uneven silhouette.
for i in range(19):
 x=R.uniform(-2.4,2.4);yy=R.choice([.65,1.48,2.25,3.2,3.9])+R.uniform(-.16,.16)
 if abs(x)<.80 and yy<3.3:continue
 z=R.uniform(.22,.84)
 rock((x,yy,z),(R.uniform(.23,.43),R.uniform(.12,.22),R.uniform(.15,.33)),
      'shadowcrack' if i%3 else 'warmstone',600+i)
# Moss in isolated crevices; no billboards, alphas, or emissive materials.
for i in range(29):
 x=R.uniform(-2.55,2.55);y=R.uniform(.48,4.12)
 if abs(x)<.72 and y<3.4:continue
 rock((x,y,R.uniform(.10,.50)),(R.uniform(.17,.34),R.uniform(.065,.14),R.uniform(.10,.22)),
      'moss',700+i)
# Ferns rooted on upper terraces; fronds are double-sided opaque geometry.
for i in range(17):
 x=R.uniform(-2.3,2.3); z=R.uniform(.48,1.40); root=np.array([x,3.83+R.uniform(-.20,.24),z])
 beam(root,root+[0,.23,0],.026,'root',5)
 for j in range(6):
  angle=j*math.tau/6+R.uniform(-.24,.24)
  length=R.uniform(.35,.71)
  end=root+np.array([math.cos(angle)*length,-R.uniform(.13,.28),math.sin(angle)*length])
  leaf(root+[0,.20,0],end,R.uniform(.08,.14),'fern_light' if (i+j)%3 else 'fern')
# Short vines on side walls, away from central view through water.
for side in (-1,1):
 for i in range(7):
  x=side*R.uniform(1.05,2.36);z=R.uniform(-.04,.32); y=R.uniform(2.40,4.07)
  a=np.array([x,y,z]);b=a+np.array([R.uniform(-.08,.08),-R.uniform(.36,.88),R.uniform(-.06,.06)])
  beam(a,b,.012,'root',4)
  for f in (.23,.57,.81):
   pos=a+(b-a)*f
   leaf(pos,pos+np.array([side*R.uniform(.12,.23),-R.uniform(.09,.22),-.09]),.063,'fern')

scene=trimesh.Scene();ntri=0
for mat,meshes in parts.items():
 g=trimesh.util.concatenate(meshes)
 g.visual=TextureVisuals(material=PBRMaterial(name=mat,baseColorFactor=PALETTE[mat],roughnessFactor=.96,metallicFactor=0.,doubleSided=True))
 scene.add_geometry(g,geom_name=mat,node_name=mat);ntri+=len(g.faces)
OUT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_bytes(scene.export(file_type='glb'))
print(f'{OUT.name}: {ntri} triangles, {len(parts)} material meshes, {OUT.stat().st_size} bytes; bounds {scene.bounds.tolist()}')
