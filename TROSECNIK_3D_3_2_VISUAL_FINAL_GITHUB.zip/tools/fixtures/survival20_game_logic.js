import { computeQuestPointer } from './quest_pointer.js';
import { resourceAvailable, recordGather } from './resource_rules.js';
import {FISH_GREEN_START, FISH_GREEN_END, fishNeedlePercent, fishNeedleHitsGreen} from './fishing_timing.js';
export class GameLogic {
  init(renderer) {
    const logic = (()=>{'use strict';
// TROSEČNÍK 3D 2.4: Cesta za obzor. Survival a příběh ve čtyřech kapitolách.
const $=id=>document.getElementById(id), clamp=(n,a,b)=>Math.max(a,Math.min(b,n)), mix=(a,b,t)=>a+(b-a)*t;
const V=(x=0,y=0,z=0)=>[x,y,z], minus=(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]],dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2],cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]], len=a=>Math.hypot(...a),normalize=a=>{const m=len(a)||1;return a.map(x=>x/m)};
const copy=o=>JSON.parse(JSON.stringify(o)), now=()=>performance.now();
const KEY='trosecnik3d_2_0_saves_v1', SETTINGS='trosecnik3d_2_0_settings';
const BASE={version:2,x:-1,z:-12,yaw:Math.PI,hp:100,food:84,water:72,energy:100,clock:8.25,day:1,xp:0,level:1,points:0,skills:{},bag:{wood:0,stone:0,fiber:0,coconut:1,fish:0,axe:0,scrap:0,bandage:0,spear:0,herb:0,ration:0,core:0,lens:0,cord:0,tinder:0,handle:0,torch:0,compass:0,brace:0,resin:0,pouch:0,kit:0,chart:0,flare:0,seal:0},flags:{progression24:true},built:{fire:0,shelter:0,filter:0,signal:0,outpost:0,beacon:0,bridge:0,pier:0},story:{metMara:false,metIvo:false,evidence:false,fate:null,stolen:{},lastTheftDay:0,radioStolen:false,restored:false,repaired:false,finalSignal:false,ending:''},journal:['Den 1. Moře mě vyplavilo na neznámý ostrov. Musím najít vodu a přístřeší.'],miniAttempts:{},weather:'clear',seconds:0,exposure:0,wild:{lastHit:0,scared:{},warning:''},playMetrics:{activeSeconds:0,questSeconds:{},completedAt:{}}};
const ITEM={wood:['🪵','Naplavené dřevo'],stone:['🪨','Kámen'],fiber:['🌿','Palmové vlákno'],coconut:['🥥','Kokos'],fish:['🐟','Ryba'],axe:['🪓','Kamenná sekera'],scrap:['⚙','Kovová součástka'],bandage:['🩹','Obvaz'],spear:['🗡','Lovecké kopí'],herb:['🌱','Léčivá bylina'],ration:['🎒','Expediční balíček'],core:['📻','Rádiové jádro'],lens:['🔎','Optická čočka'],cord:['🧶','Pevný provaz'],tinder:['🔥','Suchý troud'],handle:['🪵','Dřevěná násada'],torch:['🕯','Pochodeň'],compass:['🧭','Polní kompas'],brace:['🪚','Zpevňovací vzpěra'],resin:['🍯','Pryskyřice'],pouch:['🎒','Voděodolné pouzdro'],kit:['🛠','Opravárenská sada'],chart:['🗺','Námořní mapa'],flare:['🚨','Nouzová světlice'],seal:['⚓','Přístavní pečeť']};
const SKILLS=[{id:'endurance',name:'Vytrvalost',icon:'🥾',min:2,desc:'Běh spotřebuje o 35 % méně energie.'},{id:'gatherer',name:'Sběrač',icon:'🌿',min:2,desc:'Sběr dřeva a vláken přidá o jeden kus více.'},{id:'hydration',name:'Znalec vody',icon:'💧',min:3,desc:'Pití u pramene obnoví více žízně.'},{id:'builder',name:'Tesař',icon:'🔨',min:3,desc:'Stavby vyžadují o jeden kus dřeva méně.'},{id:'fisher',name:'Rybář',icon:'🐟',min:4,desc:'Úspěšná rybářská minihra dá dvě ryby.'},{id:'scout',name:'Průzkumník',icon:'🧭',min:4,desc:'Rychlejší chůze a delší dosah odhalení předmětů.'}];
const QUESTS=[{id:'crate',name:'První zásoby',desc:'Otevři bednu vyplavenou na pláži.',target:'crate',xp:95,done:s=>s.flags.crate},{id:"firstwood",name:"První kus dřeva",desc:"Seber naplavené dřevo na pláži. Bedna sama tábor nepostaví.",target:"driftwood",xp:35,chapter:"I",done:s=>!!s.flags.firstWood},
{id:"firststone",name:"Tvrdší než písek",desc:"Najdi a zvedni pobřežní kameny potřebné na nástroje.",target:"stonePile",xp:35,chapter:"I",done:s=>!!s.flags.firstStone},
{id:"firstfiber",name:"Kde vzít vlákna",desc:"Sesbírej vláknité listy z palmy.",target:"palmFiber",xp:40,chapter:"I",done:s=>!!s.flags.firstFiber},
{id:"firstcoconut",name:"Jídlo na první cestu",desc:"Najdi kokos; cestou dál do džungle už může dojít energie.",target:"coconut",xp:40,chapter:"I",done:s=>!!s.flags.firstCoconut},
{id:"surveypoint",name:"Vybrat místo tábora",desc:"Dojdi na označené místo a prohlédni si okolí.",target:"campPlan",xp:60,chapter:"I",done:s=>!!s.flags.surveyCamp},
{id:'spring',name:'Voda je život',desc:'Projdi džunglí až k prameni a napij se.',target:'spring',xp:115,done:s=>s.flags.spring},{id:"firstdrink",name:"Nejen najít, ale napít se",desc:"Napij se u pramene ještě jednou a doplň vodu na návrat do tábora.",target:"spring",xp:55,chapter:"I",done:s=>!!s.flags.firstDrink},
{id:"firstcord",name:"První uzel",desc:"Vyrob z vláken pevný provaz v nabídce Výroba. Recept odemkne průzkum tábora.",target:"palmFiber",xp:70,chapter:"I",done:s=>!!s.flags.craftedCord},
{id:"firsttinder",name:"Rozdělat oheň není zadarmo",desc:"Nasbírej dřevo a vlákna a vyrob suchý troud.",target:"driftwood",xp:70,chapter:"I",done:s=>!!s.flags.craftedTinder},
{id:'fire',name:'První noc',desc:'Nasbírej suroviny a postav ohniště v táboře.',target:'site-fire',xp:115,done:s=>s.built.fire===3},{id:"firstfish",name:"Večeře z pobřeží",desc:"Chyť jednu rybu v rybářské minihře.",target:"fish",xp:75,chapter:"I",done:s=>!!s.flags.caughtFirstFish},
{id:"firstcook",name:"Večeře u ohně",desc:"Připrav ulovenou rybu na postaveném ohništi.",target:"site-fire",xp:90,chapter:"I",done:s=>!!s.flags.cookedFirstFish},
{id:'shelter',name:'Střecha nad hlavou',desc:'Postav přístřešek v táboře.',target:'site-shelter',xp:145,done:s=>s.built.shelter===3},{id:"firstrest",name:"První bezpečná noc",desc:"Dokonči přístřešek a odpočiň si v něm.",target:"site-shelter",xp:90,chapter:"I",done:s=>!!s.flags.firstRest},
{id:"blueprintaxe",name:"Značky starého tesaře",desc:"Na staré pracovní desce u džungle najdi nákres sekery.",target:"toolmark",xp:85,chapter:"I",done:s=>!!s.flags.toolmark},
{id:"handle",name:"Pořádná násada",desc:"Vyrob násadu na sekeru: dřevo a pevný provaz.",target:"woodJungle",xp:85,chapter:"I",done:s=>!!s.flags.craftedHandle},
{id:'axe',name:'Nástroj přežití',desc:'Vyrob kamennou sekeru v nabídce Výroba.',target:'driftwood',xp:90,done:s=>s.bag.axe>0},{id:'wreck',name:'Hlas Esperanzy',desc:'Prozkoumej vrak lodi a najdi kovovou součástku.',target:'wreck',xp:170,done:s=>s.flags.wreck},{id:"wrecklog",name:"Kdo tu byl před tebou",desc:"U vraku přečti poničený lodní zápisník.",target:"wreckLog",xp:95,chapter:"I",done:s=>!!s.flags.wreckLog},
{id:"firstfilter",name:"Voda na cestu",desc:"Dokonči vodní filtr a poprvé jej použij.",target:"site-filter",xp:110,chapter:"I",done:s=>!!s.flags.filteredFirst},
{id:'signal',name:'Světlo na pobřeží',desc:'Postav signální stanoviště a zapal oheň.',target:'site-signal',xp:220,done:s=>s.flags.signal},
{id:'mara',name:'Mára u tábora',desc:'Promluv si s rychlým a drzým trosečníkem, který se objevil po vyslání signálu.',target:'mara',xp:95,done:s=>s.story.metMara},
{id:'ivo',name:'Ivo u pramene',desc:'Najdi radistu Iva u pramene a zjisti, co zachytil.',target:'ivo',xp:95,done:s=>s.story.metIvo},
{id:'evidence',name:'Kdo krade zásoby?',desc:'V tajném úkrytu u vraku najdi důkazy o zmizelých zásobách.',target:'stash',xp:125,done:s=>s.story.evidence},
{id:'fate',name:'Rozhodnutí u vysílačky',desc:'Vrať se k signálnímu stanovišti a rozhodni, koho Robinson zabije. Tuto volbu už nepůjde vrátit.',target:'crisis',xp:115,done:s=>!!s.story.fate},
{id:'repairShelter',name:'Opravit přístřešek po bouři',desc:'Během střetu Mára zemřel a přístřešek utrpěl škodu. Dones materiál do tábora a oprav ho.',target:'site-shelter',xp:105,active:s=>s.story.fate==='mara',done:s=>s.built.shelter>=3},
{id:'restore',name:'Márův ukrytý díl',desc:'Mára umí pracovat rychle, ale zase ukradl součástku. Vrať se k úkrytu u vraku.',target:'stash',xp:125,active:s=>s.story.fate==='ivo',done:s=>s.story.restored},
{id:'repairIvo',name:'Ivova pomalá oprava',desc:'Dones Ivovi ke stanici 2 dřeva, vlákno a kovový díl. Oprava mu potrvá déle.',target:'relay',xp:155,active:s=>s.story.fate==='mara',done:s=>s.story.repaired},
{id:'repairMara',name:'Mára v opravách neztrácí čas',desc:'Přines ke stanici dřevo, vlákno a vrácený kovový díl. Dávej pozor na zásoby.',target:'relay',xp:155,active:s=>s.story.fate==='ivo',done:s=>s.story.repaired},
{id:'last',name:'Poslední rádiový signál',desc:'Vrať se k vysílačce, dokonči vysílání a přijmi následky svého rozhodnutí.',target:'relay',xp:230,done:s=>s.story.finalSignal},
{id:'coastSurvey',name:'Pobřežní průzkum',desc:'Prozkoumej vzdálenou zátoku. Najdi na břehu stopy po staré výpravě a ověř, zda je místo bezpečné pro zásoby.',target:'coastSurvey',xp:130,chapter:'III',done:s=>!!s.flags.coastSurvey},
{id:'westSurvey',name:'Stezka přes mangrovy',desc:'Dojdi k opuštěnému značení západních mangrovů a zjisti, kudy lze projít dál do vnitrozemí.',target:'westSurvey',xp:160,chapter:'III',done:s=>!!s.flags.westSurvey},
{id:'ridgeSurvey',name:'Pozorovatelna na hřebeni',desc:'Vystoupej nad džungli, ověř vodní zdroje a poznamenej si únikovou cestu zpět do tábora.',target:'ridgeSurvey',xp:180,chapter:'III',done:s=>!!s.flags.ridgeSurvey},
{id:'surveyNotes',name:'Mapa ostrova',desc:'Vrať se ke stolu v táboře a spoj tři nalezené stopy do plánu vícedenní výpravy.',target:'expedition',xp:200,chapter:'III',done:s=>!!s.flags.surveyNotes},
{id:'expedition',name:'Výprava do neznáma' ,desc:'Vyrob lovecké kopí. Připrav expediční balíček ze dvou kokosů, obvazu a vlákna u stolu v táboře.',target:'expedition',xp:210,done:s=>!!s.flags.expedition},
{id:'mangroves',name:'Lék z mangrovů',desc:'Dojdi do západních mangrovů, prozkoumej tábořiště a nasbírej dvě léčivé byliny.',target:'mangroves',xp:245,done:s=>!!s.flags.mangroves&&s.flags.herbCollected>=2},
{id:'outpost',name:'Základna v horách',desc:'Vystoupej na severní hřeben a postav horský přístřešek ve třech etapách. Bez něj je noc na hřebeni riskantní.',target:'site-outpost',xp:310,done:s=>!!s.flags.ridge&&s.built.outpost===3},
{id:'cave',name:'Jeskyně za přílivem',desc:'Na východním pobřeží se vyhni divočákovi, najdi skalní jeskyni a vyzvedni rádiové jádro. Potřebuješ kopí a světlo dne.',target:'cave',xp:320,done:s=>!!s.flags.cave&&s.bag.core>=1},
{id:'lagoon',name:'Čočka ze ztroskotané bóje',desc:'Vydej se na jižní lagunu. K vyzvednutí optické čočky potřebuješ sekeru, dost energie a dostatek pitné vody.',target:'lagoon',xp:335,done:s=>!!s.flags.lagoon&&s.bag.lens>=1},
{id:'beacon',name:'Bouřkový maják',desc:'Dones jádro a čočku na severní hřeben, dostav nouzový maják a za světla a bez bouře odvysílej souřadnice.',target:'site-beacon',xp:480,done:s=>!!s.flags.beacon},
{id:"packet",name:"Cizí volací znak",desc:"U severního majáku vyzvedni zapečetěný radiový zápis, který přišel místo záchranného signálu.",target:"packet",xp:180,chapter:"IV",done:s=>!!s.flags.packet},
{id:"charts",name:"Ztracená mapa",desc:"Na lodi Esperanza vyhledej zamčenou schránku s kartografickými podklady.",target:"chartLock",xp:180,chapter:"IV",done:s=>!!s.flags.charts},
{id:"compass",name:"Znalost směru",desc:"Vyrob polní kompas ze získaných součástek, kamene a provazu.",target:"expedition",xp:220,chapter:"IV",done:s=>!!s.flags.craftedCompass},
{id:"trail",name:"Stezka bílých značek",desc:"S kompasem vyhledej staré značení v severozápadním lese.",target:"westTrail",xp:200,chapter:"IV",done:s=>!!s.flags.westTrail},
{id:"bridge",name:"Most přes roklinu",desc:"Ve třech pracovních etapách postav lávku. Bez ní se k vozíku nedostaneš.",target:"site-bridge",xp:300,chapter:"IV",done:s=>!!s.flags.bridgeBuilt},
{id:"cart",name:"Opuštěný vozík",desc:"Prozkoumej převrácený vozík za roklinou a zjisti, kdo přežil výpravu.",target:"cart",xp:210,chapter:"IV",done:s=>!!s.flags.cartFound},
{id:"brace",name:"Zpevnit vozík",desc:"Vyrob dřevěnou vzpěru na vyproštění zasypaného vozíku.",target:"woodNorth",xp:180,chapter:"IV",done:s=>!!s.flags.craftedBrace},
{id:"release",name:"Vyproštění z trosek",desc:"Vrať se k vozíku s vyrobenou vzpěrou a odstraň překážku.",target:"cart",xp:270,chapter:"IV",done:s=>!!s.flags.cartFreed},
{id:"jana",name:"Třetí přeživší",desc:"Promluv si s Janou a zjisti, kam zmizela její expedice.",target:"jana",xp:230,chapter:"IV",done:s=>!!s.flags.metJana},
{id:"healJana",name:"Ošetření Jany",desc:"Přines Janě léčivou bylinu z mangrovů a obvaz. Bez ošetření nemůže pokračovat.",target:"jana",xp:220,chapter:"IV",done:s=>!!s.flags.janaHealed},
{id:"resin",name:"Stopy v mlžném lese",desc:"Najdi dvě dávky pryskyřice u stromů v západním mokřadu.",target:"resinA",xp:170,chapter:"IV",done:s=>(s.flags.resinCollected||0)>=2},
{id:"pouch",name:"Výstroj do vody",desc:"Vyrob voděodolné pouzdro pro mapu a staré zápisky.",target:"expedition",xp:190,chapter:"IV",done:s=>!!s.flags.craftedPouch},
{id:"fog",name:"Mlžný archiv",desc:"V nebezpečných mokřadech prozkoumej schránku a vyzvedni plombu. Je nutné pouzdro a zdraví nad 45.",target:"fogArchive",xp:280,chapter:"IV",done:s=>!!s.flags.fogArchive},
{id:"tower",name:"Stanice na skalách",desc:"Na východě ostrova najdi starou radiostanici a prostuduj její číslo.",target:"eastStation",xp:250,chapter:"IV",done:s=>!!s.flags.stationFound},
{id:"kit",name:"Sada na opravu vysílačky",desc:"Vyrob opravárenskou sadu. Bez ní generátor nerozběhneš.",target:"expedition",xp:200,chapter:"IV",done:s=>!!s.flags.craftedKit},
{id:"generator",name:"Nouzový generátor",desc:"V opravně stanice aktivuj generátor pomocí sady a kovu.",target:"eastGenerator",xp:300,chapter:"IV",done:s=>!!s.flags.generator},
{id:"decode",name:"Šifra z Esperanzy",desc:"Podle stop z vraku, plomby a východní stanice rozlušti kód v terminálu.",target:"terminal",xp:300,chapter:"IV",done:s=>!!s.flags.decoded},
{id:"southMarker",name:"Jižní signální bod",desc:"Vydej se na opačný konec ostrova a najdi značku evakuačního místa.",target:"southMarker",xp:260,chapter:"IV",done:s=>!!s.flags.southMarker},
{id:"flares",name:"Světlice ve skladišti",desc:"U jižního pobřeží otevři starý sklad a získej signální světlici.",target:"flareCache",xp:230,chapter:"IV",done:s=>!!s.flags.flares},
{id:"pier",name:"Molo pro návrat",desc:"Ve třech etapách postav molo na jižním pobřeží.",target:"site-pier",xp:370,chapter:"IV",done:s=>!!s.flags.pierBuilt},
{id:"finalPack",name:"Poslední zásoby",desc:"Připrav finální zásoby: 2 kokosové plody, obvaz, rybu a 2 pevné provazy.",target:"expedition",xp:220,chapter:"IV",done:s=>!!s.flags.finalPack},
{id:"evac",name:"Poslední cesta",desc:"Přines na jižní molo připravené zásoby, světlici a mapu. Za rozbřesku a bez bouře vyšleš signál.",target:"evac",xp:600,chapter:"IV",done:s=>!!s.flags.evacuated}];
const BUILD={fire:{name:'Ohniště',needs:{wood:3,stone:2},description:'V noci vydává světlo, umožní připravit rybu.'},shelter:{name:'Přístřešek',needs:{wood:5,fiber:3},description:'Umožní spánek a pomalejší úbytek energie.'},filter:{name:'Lapač a filtr vody',needs:{wood:3,stone:2,fiber:3},description:'Dává pitnou vodu jednou za herní den.'},signal:{name:'Signální stanoviště',needs:{wood:4,fiber:3,scrap:1},description:'Završení první příběhové kapitoly.'},outpost:{name:'Horský přístřešek',needs:{wood:7,fiber:5,stone:3},description:'Bezpečný odpočinek na hřebeni; ochrana před nočním chladem.'},bridge:{name:'Lávka přes roklinu',needs:{wood:7,fiber:5,stone:3},description:'Zpřístupní bezpečnou cestu k opuštěnému vozíku.'},pier:{name:'Nouzové molo',needs:{wood:8,fiber:5,stone:4},description:'Bez mola se záchranné plavidlo k pobřeží nedostane.'},beacon:{name:'Nouzový maják',needs:{wood:6,fiber:4,scrap:2,stone:3},description:'Třístupňová konstrukce na hřebeni, aktivace s jádrem a čočkou.'}};
const OBJ=[{id:'crate',type:'crate',name:'Vyplavená bedna',x:-3.1,z:-10.2,r:1.0},{id:'driftwood',type:'wood',name:'Naplavené dřevo',x:1.2,z:-12.1,r:.9,repeat:55},{id:'woodSouth',type:'wood',name:'Trám u pobřeží',x:-4.7,z:-12.0,r:.9,repeat:75},{id:'woodPoint',type:'wood',name:'Větve na okraji lesa',x:6.0,z:-1.0,r:.9,repeat:75},{id:'stonePile',type:'stone',name:'Kameny na pobřeží',x:3.2,z:-8.9,r:.9,repeat:52},{id:'stoneShore',type:'stone',name:'Kameny u vrakových prken',x:8.5,z:-7.5,r:.9,repeat:70},{id:'palmFiber',type:'fiber',name:'Palmové listí',x:-6.5,z:-7.9,r:.85,repeat:48},{id:'fiberShore',type:'fiber',name:'Uvízlé palmové listy',x:-9.0,z:-4.5,r:.85,repeat:75},{id:'coconut',type:'coconut',name:'Kokosy pod palmou',x:5.6,z:-3.3,r:.85,repeat:65},{id:'woodJungle',type:'wood',name:'Spadlé větve',x:-9.4,z:5.5,r:.9,repeat:65},{id:'fiberJungle',type:'fiber',name:'Pevná liána',x:-12.3,z:9.7,r:.85,repeat:60},{id:'spring',type:'spring',name:'Sladkovodní pramen',x:-14.0,z:7.7,r:1.45},{id:'wreck',type:'wreck',name:'Vrak Esperanzy',x:14.4,z:-11.3,r:2.0},{id:'fish',type:'fish',name:'Rybářská tůň',x:8.8,z:-14.7,r:1.25,repeat:35},{id:'site-fire',type:'site',site:'fire',name:'Ohniště',x:-4.0,z:-2.0,r:1.35},{id:'site-shelter',type:'site',site:'shelter',name:'Přístřešek',x:-7.0,z:-1.4,r:1.6},{id:'site-filter',type:'site',site:'filter',name:'Lapač a filtr vody',x:-1.4,z:1.5,r:1.2},{id:'site-signal',type:'site',site:'signal',name:'Signální stanoviště',x:4.6,z:-8.2,r:1.45},
{id:'mara',type:'npc',name:'Mára · rychlý pracant',x:.8,z:-3.8,r:.65},
{id:'ivo',type:'npc',name:'Ivo · pomalý radista',x:-11.4,z:8.4,r:.65},
{id:'stash',type:'stash',name:'Skrytý úkryt u vraku',x:10.7,z:-8.6,r:.90},
{id:'crisis',type:'crisis',name:'Vysílačka · osudové rozhodnutí',x:5.7,z:-5.2,r:.9},
{id:'relay',type:'relay',name:'Poškozené rádio',x:2.9,z:-5.6,r:.88},
{id:'expedition',type:'supply',name:'Připravit výpravu',x:-2.4,z:0.1,r:1.0},
{id:'mangroves',type:'landmark',name:'Západní mangrovy',zone:'mangroves',x:-51,z:13,r:1.65},
{id:'herbA',type:'herb',name:'Léčivý porost',x:-54,z:17,r:.85,repeat:170},
{id:'herbB',type:'herb',name:'Kořeny s léčivou bylinou',x:-48,z:18,r:.85,repeat:170},
{id:'fiberWest',type:'fiber',name:'Vlákna z mangrovů',x:-47,z:9,r:.85,repeat:85},
{id:'coconutWest',type:'coconut',name:'Kokosy západního pobřeží',x:-38,z:11,r:.85,repeat:95},
{id:'ridge',type:'landmark',name:'Severní hřeben',zone:'ridge',x:8,z:49,r:1.65},
{id:'site-outpost',type:'site',site:'outpost',name:'Horský přístřešek',x:12,z:47,r:1.5},
{id:'springNorth',type:'spring',name:'Pramen v horách',x:-4,z:40,r:1.3},
{id:'woodNorth',type:'wood',name:'Dřevo z horského lesa',x:15,z:34,r:.85,repeat:90},
{id:'stoneNorth',type:'stone',name:'Horský kámen',x:19,z:43,r:.85,repeat:110},
{id:'cave',type:'cave',name:'Jeskyně za přílivem',x:51,z:14,r:1.85},
{id:'stoneEast',type:'stone',name:'Kámen u jeskyně',x:42,z:10,r:.85,repeat:90},
{id:'woodEast',type:'wood',name:'Vyplavené trámy',x:39,z:-2,r:.85,repeat:95},
{id:'lagoon',type:'lagoon',name:'Jižní laguna a bóje',x:19,z:-49,r:1.6},
{id:'fishSouth',type:'fish',name:'Rybářská zátoka',x:12,z:-43,r:1.2,repeat:70},
{id:'coconutSouth',type:'coconut',name:'Kokosy u laguny',x:27,z:-39,r:.85,repeat:95},
{id:'site-beacon',type:'site',site:'beacon',name:'Nouzový maják',x:3,z:53,r:1.6},
{id:'boarWest',type:'boar',name:'Divoký kanec · mangrovy',x:-43,z:14,r:1.1},
{id:'boarNorth',type:'boar',name:'Divoký kanec · horský les',x:22,z:40,r:1.1},
{id:'boarEast',type:'boar',name:'Divoký kanec · skalní cesta',x:42,z:19,r:1.1},{id:'radioCache',type:'cache',name:'Záchranné díly na pobřeží',x:44,z:10,r:.9},
{id:"campPlan",type:"storySite",name:"Tábořiště · bezpečný průzkum",x:-3.5,z:-0.5,r:0.9,phase:"early"},
{id:"toolmark",type:"storySite",name:"Tesařská deska",x:-8.1,z:3.8,r:0.75,phase:"early"},
{id:"wreckLog",type:"storySite",name:"Lodní zápisník",x:11.2,z:-13.0,r:0.85,phase:"early"},
{id:"packet",type:"storySite",name:"Zapečetěný radiový zápis",x:6.5,z:56,r:0.9,phase:"late"},
{id:"chartLock",type:"storySite",name:"Kartografická schránka",x:17,z:-14.5,r:0.9,phase:"late"},
{id:"westTrail",type:"storySite",name:"Stezka bílých značek",x:-19,z:37,r:1,phase:"late"},
{id:"site-bridge",type:"site",name:"Lávka přes roklinu",x:-29,z:43,r:1.3,phase:"late",site:"bridge"},
{id:"cart",type:"storySite",name:"Převrácený expediční vozík",x:-39,z:43,r:1.1,phase:"late"},
{id:"jana",type:"npc",name:"Jana · kartografka",x:-36,z:45,r:0.7,phase:"late"},
{id:"resinA",type:"resin",name:"Pryskyřice mlžného lesa",x:-51,z:3,r:0.9,phase:"late",repeat:240},
{id:"resinB",type:"resin",name:"Pryskyřice staré borovice",x:-56,z:8,r:0.9,phase:"late",repeat:240},
{id:"fogArchive",type:"storySite",name:"Schránka v mlžném lese",x:-61,z:2,r:1.0,phase:"late"},
{id:"eastStation",type:"storySite",name:"Východní radiostanice",x:43,z:29,r:1.4,phase:"late"},
{id:"eastGenerator",type:"storySite",name:"Generátor radiostanice",x:46,z:32,r:1.1,phase:"late"},
{id:"terminal",type:"storySite",name:"Šifrovací terminál",x:42,z:31,r:1.0,phase:"late"},
{id:"southMarker",type:"storySite",name:"Jižní evakuační značka",x:-7,z:-58,r:1.1,phase:"late"},
{id:"flareCache",type:"storySite",name:"Sklad světlic",x:3,z:-57,r:1.0,phase:"late"},
{id:"site-pier",type:"site",name:"Nouzové molo",x:14,z:-57,r:1.4,phase:"late",site:"pier"},
{id:'evac',type:'storySite',name:'Evakuační rádiový bod',x:17,z:-54,r:1.3,phase:'late'},
// GFX20: optional-world geometry is unchanged; these three small markers sit on existing paths.
{id:'coastSurvey',type:'storySite',name:'Značka výpravy v zátoce',x:19,z:-30,r:1.0,phase:'survey'},
{id:'westSurvey',type:'storySite',name:'Značení v západních mangrovech',x:-39,z:23,r:1.0,phase:'survey'},
{id:'ridgeSurvey',type:'storySite',name:'Pozorovací místo na hřebeni',x:5,z:36,r:1.0,phase:'survey'}];
const TUTORIAL_IDS=["firstwood", "firststone", "firstfiber", "firstcoconut", "surveypoint", "firstdrink", "firstcord", "firsttinder", "firstfish", "firstcook", "firstrest", "blueprintaxe", "handle", "wrecklog", "firstfilter"];
let slot=1,state,settings={quality:'auto',camera:'follow',sensitivity:1,sound:true},started=false,changed=false,pending=null,dialog=null,toastAt=0,mode='follow',lastHud=0;
function getStorage(k){try{return JSON.parse(localStorage.getItem(k)||'null')}catch{return null}}
function save(force=false){if(!state||(!changed&&!force))return;try{let slots=getStorage(KEY)||{};slots[slot]=copy(state);localStorage.setItem(KEY,JSON.stringify(slots));changed=false}catch(e){if(force)flash('Úložiště je nedostupné. Exportuj si postup přes menu.')}}
function load(n=slot){let slots=getStorage(KEY)||{};let a=slots[n];state={...copy(BASE),...(a&&a.version===2?a:{}),bag:{...BASE.bag,...(a?.bag||{})},flags:{...BASE.flags,...(a?.flags||{})},built:{...BASE.built,...(a?.built||{})},skills:a?.skills||{},journal:Array.isArray(a?.journal)?a.journal.slice(-90):BASE.journal.slice(),miniAttempts:a?.miniAttempts||{},story:{...copy(BASE.story),...(a?.story||{})},wild:{...copy(BASE.wild),...(a?.wild||{}),scared:{...(a?.wild?.scared||{})}},playMetrics:{...copy(BASE.playMetrics),...(a?.playMetrics||{}),questSeconds:{...(a?.playMetrics?.questSeconds||{})},completedAt:{...(a?.playMetrics?.completedAt||{})}}};state.exposure=clamp(Number(state.exposure)||0,0,100);state.x=clamp(state.x,-78,78);state.z=clamp(state.z,-70,70);state.level=Math.max(1,Math.floor(state.level||1));migrateOldSave(a);
// Previous released saves may already be deep in chapter III or IV. Never send them
// backwards through new expedition reconnaissance or issue duplicate XP.
if(a&&(a.flags?.expedition||a.flags?.['quest-expedition'])){
 for(const id of ['coastSurvey','westSurvey','ridgeSurvey','surveyNotes']){
  state.flags[id]=true;state.flags['quest-'+id]=true;
 }
}
for(let site of Object.keys(BUILD))if(a?.built?.[site]===3)state.flags['build-reward-'+site]=true;slot=n;changed=true;syncPlayer();regenCamp();updateUI();save(true)}
function migrateOldSave(old){
 if(!old||old.flags?.progression24)return;
 // Import an older save without returning a developed camp to the tutorial.
 if(old.flags?.signal||old.flags?.wreck||old.built?.shelter===3){
  for(const id of TUTORIAL_IDS)state.flags['quest-'+id]=true;
  Object.assign(state.flags,{firstWood:true,firstStone:true,firstFiber:true,firstCoconut:true,surveyCamp:true,firstDrink:true,craftedCord:true,craftedTinder:true,caughtFirstFish:true,cookedFirstFish:true,firstRest:true,toolmark:true,craftedHandle:true,wreckLog:true,filteredFirst:true});
 }
 state.flags.progression24=true;
}
settings={...settings,...(getStorage(SETTINGS)||{})};
if (!renderer) { $('fatal').hidden=false; $('intro').hidden=true; return; }
// Matrix engine: column-major, Y up, character forward along local -Z.
function identity(){return new Float32Array([1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1])}
function mul(a,b){let m=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++){let sum=0;for(let k=0;k<4;k++)sum+=a[k*4+r]*b[c*4+k];m[c*4+r]=sum;}return m}
function T(x=0,y=0,z=0,sx=1,sy=1,sz=1,yaw=0,tilt=0){let m=identity(),c=Math.cos(yaw),s=Math.sin(yaw),cy=Math.cos(tilt),st=Math.sin(tilt);m[0]=c*sx;m[2]=-s*sx;m[4]=s*st*sy;m[5]=cy*sy;m[6]=c*st*sy;m[8]=s*cy*sz;m[9]=-st*sz;m[10]=c*cy*sz;m[12]=x;m[13]=y;m[14]=z;return m}
function Mv(m,v){return [m[0]*v[0]+m[4]*v[1]+m[8]*v[2]+m[12]*v[3],m[1]*v[0]+m[5]*v[1]+m[9]*v[2]+m[13]*v[3],m[2]*v[0]+m[6]*v[1]+m[10]*v[2]+m[14]*v[3],m[3]*v[0]+m[7]*v[1]+m[11]*v[2]+m[15]*v[3]]}
function perspective(fov,aspect,n,f){let m=identity(),q=1/Math.tan(fov/2);m[0]=q/aspect;m[5]=q;m[10]=(f+n)/(n-f);m[11]=-1;m[14]=2*f*n/(n-f);m[15]=0;return m}
function lookAt(eye,center){let z=normalize(minus(eye,center)),x=normalize(cross([0,1,0],z)),y=cross(z,x),m=identity();m[0]=x[0];m[1]=y[0];m[2]=z[0];m[4]=x[1];m[5]=y[1];m[6]=z[1];m[8]=x[2];m[9]=y[2];m[10]=z[2];m[12]=-dot(x,eye);m[13]=-dot(y,eye);m[14]=-dot(z,eye);return m}
function inverse(m){let a=new Float64Array(32);for(let r=0;r<4;r++)for(let c=0;c<4;c++){a[r*8+c]=m[c*4+r];a[r*8+c+4]=r===c?1:0}for(let c=0;c<4;c++){let p=c;for(let r=c+1;r<4;r++)if(Math.abs(a[r*8+c])>Math.abs(a[p*8+c]))p=r;if(Math.abs(a[p*8+c])<1e-9)return identity();for(let j=0;j<8;j++){let v=a[c*8+j];a[c*8+j]=a[p*8+j];a[p*8+j]=v}let k=a[c*8+c];for(let j=0;j<8;j++)a[c*8+j]/=k;for(let r=0;r<4;r++)if(r!==c){let d=a[r*8+c];for(let j=0;j<8;j++)a[r*8+j]-=d*a[c*8+j]}}let v=new Float32Array(16);for(let r=0;r<4;r++)for(let c=0;c<4;c++)v[c*4+r]=a[r*8+c+4];return v}
// Shader compilation and GPU state now belong to src/renderer.js.
function mesh(){return{p:[],n:[],c:[]}}
function tri(m,a,b,c,col){let v=normalize(cross(minus(b,a),minus(c,a)));for(let q of [a,b,c]){m.p.push(...q);m.n.push(...v);m.c.push(...col)}}
function quad(m,a,b,c,d,col){tri(m,a,b,c,col);tri(m,a,c,d,col)}
const rgb=(r,g,b)=>[r,g,b];const C={sand:rgb(.80,.72,.51),beach:rgb(.91,.78,.54),soil:rgb(.41,.47,.31),grass:rgb(.31,.48,.28),moss:rgb(.22,.40,.25),deep:rgb(.13,.29,.20),leaf:rgb(.18,.43,.25),leaf2:rgb(.25,.52,.29),palm:rgb(.18,.43,.27),palm2:rgb(.36,.55,.29),wood:rgb(.40,.25,.13),bark:rgb(.32,.21,.12),plank:rgb(.54,.38,.22),paleWood:rgb(.66,.48,.27),rope:rgb(.72,.59,.34),stone:rgb(.55,.54,.47),stoneLight:rgb(.68,.66,.55),metal:rgb(.45,.51,.50),darkMetal:rgb(.23,.30,.32),shirt:rgb(.48,.53,.42),shirtAlt:rgb(.40,.45,.34),pants:rgb(.29,.34,.33),boots:rgb(.23,.19,.15),skin:rgb(.77,.57,.40),skinShade:rgb(.65,.41,.28),hair:rgb(.22,.16,.11),beard:rgb(.32,.21,.14),eye:rgb(.16,.20,.18),white:rgb(.89,.87,.77),gold:rgb(.86,.65,.33),fire:rgb(1,.46,.12),shadow:rgb(.21,.33,.23),water:rgb(.16,.48,.57),paper:rgb(.72,.67,.50),red:rgb(.64,.21,.15)};
function boxMesh(){let m=mesh(),p=[[-.5,-.5,-.5],[.5,-.5,-.5],[.5,.5,-.5],[-.5,.5,-.5],[-.5,-.5,.5],[.5,-.5,.5],[.5,.5,.5],[-.5,.5,.5]];for(let f of [[0,3,2,1],[4,5,6,7],[0,4,7,3],[1,2,6,5],[3,7,6,2],[0,1,5,4]])quad(m,...f.map(i=>p[i]),[1,1,1]);return m}
function cylMesh(n=11,rt=.5,rb=.5){let m=mesh();for(let i=0;i<n;i++){let a=i*Math.PI*2/n,b=(i+1)*Math.PI*2/n,u=[Math.sin(a)*rb,-.5,Math.cos(a)*rb],v=[Math.sin(b)*rb,-.5,Math.cos(b)*rb],w=[Math.sin(b)*rt,.5,Math.cos(b)*rt],x=[Math.sin(a)*rt,.5,Math.cos(a)*rt];quad(m,u,v,w,x,[1,1,1]);if(rt)tri(m,[0,.5,0],w,x,[1,1,1]);if(rb)tri(m,[0,-.5,0],u,v,[1,1,1]);}return m}
function sphereMesh(n=12,rings=8){let m=mesh(),pt=(a,b)=>[Math.cos(a)*Math.sin(b)*.5,Math.cos(b)*.5,Math.sin(a)*Math.sin(b)*.5];for(let j=0;j<rings;j++)for(let k=0;k<n;k++){let a=2*Math.PI*k/n,b=2*Math.PI*(k+1)/n,y=Math.PI*j/rings,z=Math.PI*(j+1)/rings;quad(m,pt(a,y),pt(b,y),pt(b,z),pt(a,z),[1,1,1])}return m}
function discMesh(n=24){let m=mesh();for(let i=0;i<n;i++){let a=i*Math.PI*2/n,b=(i+1)*Math.PI*2/n;tri(m,[0,0,0],[Math.cos(b)*.5,0,Math.sin(b)*.5],[Math.cos(a)*.5,0,Math.sin(a)*.5],[1,1,1])}return m}
const raw={box:boxMesh(),cyl:cylMesh(),cone:cylMesh(11,0,.5),sphere:sphereMesh(),disc:discMesh()};
function upload(m){return renderer.upload(m)}
const meshes={};for(let [k,v] of Object.entries(raw))meshes[k]=upload(v);
function addTransformed(dst,src,m,col){let im=identity();im[0]=m[0];im[1]=m[1];im[2]=m[2];im[4]=m[4];im[5]=m[5];im[6]=m[6];im[8]=m[8];im[9]=m[9];im[10]=m[10];for(let i=0;i<src.p.length;i+=3){let q=Mv(m,[src.p[i],src.p[i+1],src.p[i+2],1]);dst.p.push(q[0],q[1],q[2]);let v=normalize(Mv(im,[src.n[i],src.n[i+1],src.n[i+2],0]).slice(0,3));dst.n.push(...v);dst.c.push(col[0],col[1],col[2])}}
function batchAdd(dst,shape,x,y,z,sx,sy,sz,col,yaw=0,tilt=0){addTransformed(dst,raw[shape],T(x,y,z,sx,sy,sz,yaw,tilt),col)}
function rand(seed){let v=Math.sin(seed*129.41+31.733)*43758.5453;return v-Math.floor(v)}
function smooth(t){return t*t*(3-2*t)}function noise(x,z){let a=Math.floor(x),b=Math.floor(z),u=smooth(x-a),v=smooth(z-b),f=(i,j)=>rand(i*431.4+j*137.12);return mix(mix(f(a,b),f(a+1,b),u),mix(f(a,b+1),f(a+1,b+1),u),v)}
function height(x,z){
  // Keep the old 2.2 play area exactly at its existing elevation.
  let r0=Math.hypot(x/37,z/32),shore0=clamp((1-r0)*7.7,-1.55,1.95);
  let hills0=(noise(x*.10,z*.1)-.50)*1.65+(noise(x*.31,z*.32)-.5)*.30;
  let up=clamp((z+3)/21,0,1),flatCamp=Math.exp(-((x+4)**2+z*z)/100);
  let original=shore0+hills0*(1-flatCamp*.68)+up*up*1.75-flatCamp*.26-.52;
  let r=Math.hypot(x/84,z/76);
  let shore=clamp((1-r)*6.4,-1.55,2.65);
  let hills=(noise(x*.075,z*.075)-.5)*1.45+(noise(x*.23,z*.23)-.5)*.52;
  let ridge=Math.exp(-((x-6)**2+(z-50)**2)/620)*1.45;
  let swamp=Math.exp(-((x+51)**2+(z-13)**2)/560)*.95;
  let distant=shore+hills+ridge-swamp-.10;
  let distance=Math.hypot(x,z),t=clamp((distance-20)/22,0,1);t=t*t*(3-2*t);
  return mix(original,distant,t);
}
const H=(x,z)=>height(x,z);let terrainMesh,seaMesh,staticMesh,staticPalmMesh,waterfallMesh,wreckFallbackMesh,cliffFallbackMesh,campMesh,sceneObstacles=[],staticTrees=[];
function generateTerrain(){let m=mesh(),grid=128,min=-85,max=85,step=(max-min)/grid;for(let i=0;i<grid;i++)for(let j=0;j<grid;j++){let x=min+i*step,z=min+j*step,a=[x,H(x,z),z],b=[x+step,H(x+step,z),z],c=[x+step,H(x+step,z+step),z+step],d=[x,H(x,z+step),z+step];let h=(a[1]+b[1]+c[1]+d[1])*.25,randcol=(noise(x*.66,z*.66)-.5)*.08,grass=(noise(x*.11,z*.11)-.5)*.12,patch=noise(x*.19,z*.19);let col;if(h<-.18)col=[.48,.48,.39];else if(h<.10)col=[.61-patch*.05,.58-patch*.04,.43-patch*.02];else if(h<.48)col=[.86,.74,.52];else if(h<1.3)col=[.39+grass,.49+grass,.31];else col=[.28+grass,.42+grass,.27];if(x<-34&&z>0&&z<29)col=[.27+grass,.37+grass,.26];if(z>38)col=[.35+grass,.41+grass,.37];if(x>38&&z>1&&z<34)col=[.53+grass,.45+grass,.36];if(z<-35&&x>2)col=[.77+grass,.68+grass,.52];col=col.map(v=>clamp(v+randcol,0,1));quad(m,a,d,c,b,col)}return upload(m)}
function generateSea(){let m=mesh(),s=120;quad(m,[-s,-.62,-s],[-s,-.62,s],[s,-.62,s],[s,-.62,-s],C.water);return upload(m)}
function segment(dst,a,b,width,col,kind='cyl'){let vec=minus(b,a),length=len(vec);if(length<.0001)return;let cy=Math.atan2(-vec[0],-vec[2]);let tilt=Math.acos(clamp(vec[1]/length,-1,1));let m=identity(),up=normalize(vec),q=normalize(cross([0,0,1],up));if(len(q)<.3)q=normalize(cross([1,0,0],up));let r=cross(up,q);m[0]=q[0]*width;m[1]=q[1]*width;m[2]=q[2]*width;m[4]=up[0]*length;m[5]=up[1]*length;m[6]=up[2]*length;m[8]=r[0]*width;m[9]=r[1]*width;m[10]=r[2]*width;m[12]=(a[0]+b[0])*.5;m[13]=(a[1]+b[1])*.5;m[14]=(a[2]+b[2])*.5;addTransformed(dst,raw[kind],m,col)}
function palm(dst,x,z,seed){let y=H(x,z),h=4+rand(seed+23)*2.6,bend=.45+rand(seed+17)*.65,dir=rand(seed+8)*6.28,up=[x+Math.cos(dir)*bend,y+h,z+Math.sin(dir)*bend];segment(dst,[x,y,z],[x+Math.cos(dir)*bend*.54,y+h*.58,z+Math.sin(dir)*bend*.54],.26,C.bark);segment(dst,[x+Math.cos(dir)*bend*.54,y+h*.58,z+Math.sin(dir)*bend*.54],up,.19,C.wood);for(let j=0;j<7;j++){let a=j*Math.PI*2/7+rand(seed)*.15,l=2.2+rand(seed+j)*.8;let mid=[up[0]+Math.cos(a)*l*.56,up[1]+.15,up[2]+Math.sin(a)*l*.56],tip=[up[0]+Math.cos(a)*l,up[1]-1.0-rand(j)*.4,up[2]+Math.sin(a)*l];segment(dst,up,mid,.19,j%2?C.palm:C.palm2);segment(dst,mid,tip,.27,j%2?C.leaf:C.palm);batchAdd(dst,'sphere',mid[0],mid[1]-.08,mid[2],l*.48,.08,.25,j%2?C.palm2:C.leaf,a)}for(let k=0;k<3;k++)batchAdd(dst,'sphere',up[0]+Math.sin(k*2.8)*.23,up[1]-.36,up[2]+Math.cos(k*2.8)*.23,.28,.37,.25,C.bark)}
function canopy(dst,x,z,seed){let y=H(x,z),h=3+rand(seed)*2.8;segment(dst,[x,y,z],[x+.1,y+h,z+.1],.24,C.bark);for(let k=0;k<4;k++){let a=k*2.4+rand(seed+11);batchAdd(dst,'sphere',x+Math.sin(a)*.77,y+h-.1+rand(seed+k)*.6,z+Math.cos(a)*.72,1.9,2.2,1.95,k%2?C.leaf2:C.leaf)}}
function rock(dst,x,z,seed){let y=H(x,z);batchAdd(dst,'sphere',x,y+.10+rand(seed)*.13,z,.65+rand(seed+1)*.72,.46+rand(seed+2)*.65,.70+rand(seed+3)*.55,seed%2?C.stone:C.stoneLight,rand(seed+13)*3.14)}
function groundCover(dst,x,z,seed){let y=H(x,z);for(let j=0;j<3;j++){let a=j*2.13+rand(seed)*2;segment(dst,[x,y+.02,z],[x+Math.cos(a)*.25,y+.23+rand(seed+j)*.3,z+Math.sin(a)*.22],.033,rand(seed+j)>0.5?C.leaf2:C.moss)}}
function fernPatch(dst,x,z,seed){let y=H(x,z)+.025;for(let j=0;j<6;j++){let a=j*Math.PI/3+rand(seed)*.45,l=.42+rand(seed+j*7)*.38,w=.055+rand(seed+j*11)*.035,ca=Math.cos(a),sa=Math.sin(a),px=-sa*w,pz=ca*w;let mid=[x+ca*l*.52,y+.16+rand(seed+j)*.08,z+sa*l*.52],tip=[x+ca*l,y+.08+rand(seed+j+9)*.12,z+sa*l];let root=[x,y,z];let col=j%2?C.leaf:C.moss;quad(dst,[root[0]+px,root[1],root[2]+pz],[root[0]-px,root[1],root[2]-pz],[mid[0]-px*.72,mid[1],mid[2]-pz*.72],[mid[0]+px*.72,mid[1],mid[2]+pz*.72],col);quad(dst,[mid[0]+px*.72,mid[1],mid[2]+pz*.72],[mid[0]-px*.72,mid[1],mid[2]-pz*.72],[tip[0]-px*.18,tip[1],tip[2]-pz*.18],[tip[0]+px*.18,tip[1],tip[2]+pz*.18],j%3?C.leaf2:C.palm);}}
function makeStatic(){let m=mesh(),proceduralPalms=mesh();sceneObstacles=[];staticTrees=[];for(let i=0;i<95;i++){let x=(rand(i*12.9)-.5)*58,z=(rand(i*17.2+4)-.5)*52;let nearCamp=Math.hypot(x+4,z),nearPath=Math.min(Math.hypot(x+14,z-8),Math.hypot(x-14,z+11),Math.hypot(x+3,z+10));if(H(x,z)<.5||nearCamp<7||nearPath<3.6||x>8&&z<0||x<-9&&z<12&&z>5||Math.hypot(x,z)>30||Math.hypot(x-2.9,z+5.6)<3||Math.hypot(x-5.7,z+5.2)<3||Math.hypot(x+11.4,z-8.4)<2.3)continue;if(i%3===0)palm(proceduralPalms,x,z,i+2);else canopy(m,x,z,i+6);sceneObstacles.push({x,z,r:i%3===0?.46:.6,kind:'tree'});staticTrees.push({x,z,r:1.0,kind:i%3===0?'palm':'canopy'})}
for(let i=0;i<86;i++){let x=(rand(i*63.1+88)-.5)*64,z=(rand(i*71.5)-.5)*57;if(H(x,z)<-.25||Math.hypot(x+4,z)<6||Math.hypot(x-14,z+11)<4||Math.hypot(x+14,z-8)<3||Math.hypot(x-2.9,z+5.6)<2||Math.hypot(x-5.7,z+5.2)<2||Math.hypot(x+11.4,z-8.4)<1.7)continue;rock(m,x,z,i);sceneObstacles.push({x,z,r:.50,kind:'rock'})}
for(let i=0;i<180;i++){let x=(rand(i*94.1+90)-.5)*61,z=(rand(i*74.5+121)-.5)*55;if(H(x,z)<.4||Math.hypot(x+4,z)<4)continue;groundCover(m,x,z,i)}
// GFX 9: cheap broadleaf understory. Flat fern cards are merged into staticMesh, so draw calls stay unchanged.
for(let i=0;i<220;i++){let x=(rand(i*41.7+510)-.5)*67,z=(rand(i*53.3+870)-.5)*61;if(H(x,z)<.35||z<-5||Math.hypot(x+4,z)<5.2||Math.hypot(x+14,z-8)<3.2||Math.hypot(x-14,z+11)<3.6)continue;fernPatch(m,x,z,900+i)}
// New exterior biomes are kept sparse to preserve iPhone performance and quest access.
const protectedPoints=OBJ.filter(o=>o.type!=='boar').map(o=>({x:o.x,z:o.z,r:o.type==='landmark'||o.type==='cave'||o.type==='lagoon'?4.8:2.7}));
for(let i=0;i<190;i++){
 let x=(rand(i*29.71+222)-.5)*148,z=(rand(i*43.51+144)-.5)*132;
 if(Math.hypot(x,z)<30||H(x,z)<.55||protectedPoints.some(p=>Math.hypot(x-p.x,z-p.z)<p.r))continue;
 // Thin the vegetation around passageways. The mangroves are mostly roots and reeds, the ridge mostly stone.
 if(x<-35&&rand(i+33)>.58)continue;
 if(z>37&&rand(i+41)>.58)continue;
 if(i%5===0){palm(proceduralPalms,x,z,i+219);sceneObstacles.push({x,z,r:.46,kind:'tree'});staticTrees.push({x,z,r:1,kind:'palm'});}
 else if(i%5===1){canopy(m,x,z,i+148);sceneObstacles.push({x,z,r:.60,kind:'tree'});staticTrees.push({x,z,r:1,kind:'canopy'});}
 else if(i%5===2){rock(m,x,z,i+78);sceneObstacles.push({x,z,r:.46,kind:'rock'});}
 else groundCover(m,x,z,i+351);
}
// Optional GFX 12 visual: the original wreck is built in a separate static buffer
// so a loaded GLB replaces it rather than drawing a second hull on top.
// Wreck positions, interaction radii and terrain stay in the original game.
let wreckProcedural=mesh();
// Wrecked ship Esperanza: broken keel, deck, bent mast, ribs and split hull, reachable from beach.
let x=14.4,z=-11.3,y=H(x,z);batchAdd(wreckProcedural,'box',x,y+.22,z,8.6,.48,2.65,C.wood,.28);batchAdd(wreckProcedural,'box',x,y+.75,z+1.1,7.8,.62,.33,C.plank,.28);batchAdd(wreckProcedural,'box',x,y+.75,z-1.12,7.8,.62,.33,C.plank,.28);for(let i=-3;i<=3;i++){batchAdd(wreckProcedural,'box',x+i*.92,y+.60,z, .13,.36,2.5,i%2?C.plank:C.paleWood,.28);batchAdd(wreckProcedural,'box',x+i*.91,y+1.02,z+1.18,.15,.88,.15,C.bark)}segment(wreckProcedural,[x-1,y+.53,z],[x-2,y+5.4,z-.4],.16,C.bark);segment(wreckProcedural,[x+1,y+.52,z],[x+3,y+3,z-.2],.13,C.wood);batchAdd(wreckProcedural,'box',x-.9,y+2.8,z-.1,.09,2.8,2.1,C.paper,.20);batchAdd(wreckProcedural,'box',x-4.0,y+.35,z+.6,1.3,.55,.94,C.darkMetal,.15);
wreckFallbackMesh=upload(wreckProcedural);
// Spring: layered stone basin, source stream and jungle stepping rocks.
let sx=-14,sz=7.7,sy=H(sx,sz);for(let j=0;j<10;j++){let a=j*6.28/10;batchAdd(m,'sphere',sx+Math.cos(a)*1.18,sy+.24,sz+Math.sin(a)*1.2,.70,.50,.56,C.stone)}batchAdd(m,'disc',sx,sy+.08,sz,2.0,1,2.0,C.water);
// GFX 9: the waterfall is now in the ACTIVE Three.js game path, behind the unchanged spring interaction.
// GFX 13: the original rock wall is a separate fallback buffer; animated water is unchanged.
let cliffProcedural=mesh();let falls=mesh(),fx=-16.8,fz=11.8,fy=H(fx,fz);for(let layer=0;layer<3;layer++){let width=3.25-layer*.55,back=fz+layer*.38,top=fy+2.8+layer*.44;for(let j=0;j<7;j++){let rx=fx+(j-3)*width/6,rz=back+.10*Math.sin(j*2.4+layer);batchAdd(cliffProcedural,'sphere',rx,fy+.68+layer*.55,rz,.76,1.42+layer*.22,.86,(j+layer)%3===0?C.stoneLight:C.stone,j*.41);batchAdd(cliffProcedural,'sphere',rx,top-.17,rz-.13,.68,.38,.74,C.moss,j*.25);}}cliffFallbackMesh=upload(cliffProcedural);for(let j=0;j<9;j++){let wx=fx+(j-4)*.17,front=fz-.72+Math.sin(j*2.3)*.045,upper=fy+3.65-.10*Math.sin(j*1.8),lower=fy+.24;quad(falls,[wx-.10,upper,front],[wx+.10,upper,front],[wx+.13,lower,front-.36],[wx-.13,lower,front-.36],j%3===0?[.66,.84,.84]:[.37,.68,.76]);batchAdd(m,'sphere',wx,fy+.22,front-.39,.27,.11,.31,C.white);}
waterfallMesh=upload(falls);
// Distant mountain silhouettes sit beyond the playable ellipse. They change the horizon, not collisions.
for(let i=0;i<17;i++){let mx=-70+i*8.7,mz=80+Math.sin(i*.73)*2.6,my=H(mx,mz);batchAdd(m,'sphere',mx,my+4.0+rand(i+770)*2.5,mz,7.4+rand(i+430)*3.8,8.2+rand(i+350)*6.0,6.8+rand(i+210)*2.7,i%3===0?C.deep:i%2?C.stone:C.moss,rand(i+99)*2.2);}
// A compact cliff marker overlooking the horizon.
for(let i=0;i<7;i++){let a=i*2.17,x=-21+Math.cos(a)*1.1,z=16+Math.sin(a)*.8;rock(m,x,z,71+i)}
staticPalmMesh=upload(proceduralPalms);return upload(m)}
terrainMesh=generateTerrain();seaMesh=generateSea();staticMesh=makeStatic();
// Rendering, dynamic geometry and articulated Robinson.
let VP=identity(),inverseVP=identity(),eye=[0,7,5],cameraPos=[0,7,5],cameraYaw=0,cameraPitch=.32,cameraDistance=7.4,wideDistance=7.4,shoulder=false,daylight=1,elapsed=0,drawCount=0,lastFrame=0,framerate=58;
let camGround=null; // Low-pass terrain height for a stable, non-bobbing camera.
let lastSafePosition={x:-1,z:-12},previousSafePosition={x:-1,z:-12},unstuckAt=-1e8;
let hero={x:-1,z:-12,y:0,yaw:Math.PI,anim:0,walk:0,run:0,working:0,kind:'gather',goal:null,target:null,step:0,headTurn:0};
function draw(meshKey,mat,col=C.white,kind=0,water=0){
 const o=meshes[meshKey]||meshKey;
 if(!o||!o.count)return;
 renderer.draw(o,mat,col,kind,water);
 drawCount++;
}
function tryDrawGLB(name,mat,tint){
 if(!renderer.hasModel(name))return false;
 renderer.drawModel(name,mat,tint||[1,1,1]);
 drawCount++;
 return true;
}
function shape(k,x,y,z,sx,sy,sz,col,yaw=0,tilt=0){draw(k,T(x,y,z,sx,sy,sz,yaw,tilt),col)}
function shapeM(k,m,col){draw(k,m,col)}
function shapeSegment(a,b,r,col,k='cyl'){let v=minus(b,a),l=len(v);if(l<.00001)return;let up=normalize(v),s=normalize(cross([0,0,1],up));if(len(s)<.3)s=normalize(cross([1,0,0],up));let d=cross(up,s),m=identity();m[0]=s[0]*r;m[1]=s[1]*r;m[2]=s[2]*r;m[4]=up[0]*l;m[5]=up[1]*l;m[6]=up[2]*l;m[8]=d[0]*r;m[9]=d[1]*r;m[10]=d[2]*r;m[12]=(a[0]+b[0])*.5;m[13]=(a[1]+b[1])*.5;m[14]=(a[2]+b[2])*.5;shapeM(k,m,col)}
function syncPlayer(){if(!state)return;hero.x=state.x;hero.z=state.z;hero.y=H(state.x,state.z);hero.yaw=state.yaw||Math.PI;cameraPos=[hero.x+6,hero.y+5,hero.z+6];camGround=hero.y;cameraYaw=-.25;hero.goal=null;hero.target=null;let desired=state.safe;lastSafePosition=desired&&Number.isFinite(desired.x)&&Number.isFinite(desired.z)?{x:desired.x,z:desired.z}:{x:-1,z:-12};previousSafePosition=state.safePrev&&Number.isFinite(state.safePrev.x)&&Number.isFinite(state.safePrev.z)?{...state.safePrev}:{x:-1,z:-12};if(!safeForRecovery(lastSafePosition.x,lastSafePosition.z)&&safeForRecovery(hero.x,hero.z))lastSafePosition={x:hero.x,z:hero.z}}

const NPCS={mara:OBJ.find(o=>o.id==='mara'),ivo:OBJ.find(o=>o.id==='ivo')};
function updateNPCs(dt){if(!state.flags.signal)return;
 if(!state.story.fate||state.story.fate!=='mara'){let o=NPCS.mara,phase=state.seconds*.83,tx=.8+Math.sin(phase)*1.25,tz=-3.8+Math.cos(phase*.71)*1.04;o.x=mix(o.x,tx,clamp(dt*2.2,0,1));o.z=mix(o.z,tz,clamp(dt*2.2,0,1));}
 if(!state.story.fate||state.story.fate!=='ivo'){let o=NPCS.ivo,phase=state.seconds*.13,tx=-11.4+Math.sin(phase)*.58,tz=8.4+Math.cos(phase)*.39;o.x=mix(o.x,tx,clamp(dt*.46,0,1));o.z=mix(o.z,tz,clamp(dt*.46,0,1));}}
function drawNPC(o){let x=o.x,z=o.z,y=H(x,z),mara=o.id==='mara',t=elapsed,pace=mara?Math.sin(t*6.8)*.12:Math.sin(t*1.2)*.025,shirt=mara?[.53,.23,.18]:[.33,.40,.52];
 shape('disc',x,y+.025,z,.69,1,.58,C.shadow);shape('sphere',x,y+1.12,z,.61,.78,.35,shirt);shape('box',x,y+1.13,z-.19,.5,.68,.24,shirt);shape('sphere',x,y+1.95,z-.035,.38,.43,.36,mara?C.skin:C.skinShade);shape('sphere',x,y+2.2,z,.39,.15,.35,mara?C.hair:C.stoneLight);shape('box',x,y+1.42,z+.31,.46,.42,.18,mara?C.wood:C.metal);
 for(let side of [-1,1]){let a=side*.18,sw=(side===-1?1:-1)*pace;shapeSegment([x+a,y+.83,z],[x+a,y+.13,z+sw],.12,C.pants);shape('box',x+a,y+.08,z-.08+sw,.23,.15,.33,C.boots);shapeSegment([x+side*.36,y+1.55,z],[x+side*.47,y+.89,z-sw],.11,shirt);shape('sphere',x+side*.47,y+.83,z-sw,.15,.15,.15,C.skin)}
 if(mara){shape('box',x+.39,y+.83,z-.24,.19,.17,.23,C.gold);shape('box',x-.21,y+1.5,z-.30,.17,.14,.06,C.rope)}
 else{shape('box',x-.42,y+.89,z-.25,.22,.27,.2,C.darkMetal);shape('box',x,y+1.95,z-.32,.38,.09,.11,C.darkMetal)}}
function drawRobinson(){if(renderer.heroReady)return;let phase=hero.anim,walk=hero.walk,work=hero.working,pace=walk>.1?Math.sin(phase*7.4)*walk:Math.sin(elapsed*.8)*.025;
let y=H(hero.x,hero.z);let local=(x,h,z)=>[hero.x+x*Math.cos(hero.yaw)+z*Math.sin(hero.yaw),y+h,hero.z-x*Math.sin(hero.yaw)+z*Math.cos(hero.yaw)];
function S(k,x,h,z,sx,sy,sz,col,ang=0,tilt=0){const w=local(x,h,z);shape(k,...w,sx,sy,sz,col,hero.yaw+ang,tilt)}
function L(a,b,r,col,k){shapeSegment(local(...a),local(...b),r,col,k)}
// Ground contact shadow and anatomy: torso, collar, layered clothing, backpack, head/face.
shape('disc',hero.x,H(hero.x,hero.z)+.016,hero.z,.98,1,.72,C.shadow);
S('sphere',0,1.47,0,.68,.95,.37,C.shirtAlt);S('box',0,1.57,-.14,.58,.77,.31,C.shirt);S('box',0,1.13,.01,.58,.16,.34,C.pants);S('sphere',0,1.80,-.19,.18,.15,.13,C.skin);S('sphere',0,2.08,-.04,.37,.45,.36,C.skin);S('sphere',0,1.94,-.355,.20,.10,.09,C.skinShade);S('sphere',-.145,2.12,-.33,.07,.065,.045,C.white);S('sphere',.145,2.12,-.33,.07,.065,.045,C.white);S('sphere',-.145,2.12,-.38,.026,.035,.026,C.eye);S('sphere',.145,2.12,-.38,.026,.035,.026,C.eye);S('sphere',0,1.91,-.35,.21,.10,.07,C.beard);S('sphere',0,2.27,-.01,.39,.18,.37,C.hair);S('sphere',-.27,2.06,.015,.07,.12,.09,C.skinShade);S('sphere',.27,2.06,.015,.07,.12,.09,C.skinShade);
// Straps, utility belt, pack; scale and proportions designed for third person at 2-8m.
S('box',0,1.69,.31,.43,.54,.24,C.wood);S('box',0,1.76,.46,.48,.14,.10,C.rope);S('box',-.24,1.49,-.14,.065,.65,.05,C.rope,-.15);S('box',.24,1.49,-.14,.065,.65,.05,C.rope,.15);S('box',0,1.14,-.19,.65,.09,.37,C.boots);S('box',.03,1.15,-.39,.15,.14,.08,C.gold);
for(let side of [-1,1]){let swing=Math.sin(phase*7.4+ (side<0?0:Math.PI))*walk,legX=.19*side,hip=[legX,1.11,0],knee=[legX+side*.015,.68,.12+swing*.18],ankle=[legX+side*.025,.17,.03+swing*.27];if(work>0)knee[2]=.06;L(hip,knee,.145,C.pants);S('sphere',...knee,.17,.18,.17,C.pants);L(knee,ankle,.124,C.pants);S('box',ankle[0],.105,ankle[2]-.115,.26,.22,.39,C.boots);L([legX,1.02,-.15],[legX,.95,-.15],.11,C.rope);
 let armW=work>0?Math.sin((1-work)*14)*.40:0,armSwing=-swing*.23;let shoulder=[side*.36,1.76,-.015],elbow=[side*.52,1.46,armSwing+armW],hand=[side*.47,1.13,armSwing*1.5+(work>0?-.54:0)];if(work>0){elbow=[side*.47,1.56,-.42];hand=[side*.35,1.38+armW,-.68]}L(shoulder,elbow,.122,C.shirt);S('sphere',...elbow,.13,.13,.13,C.shirtAlt);L(elbow,hand,.095,C.skin);S('sphere',...hand,.11,.11,.11,C.skin);
 if(side>0&&state.bag.axe>0&&(work>0||hero.walk<.18)) {let handWorld=local(...hand);shapeSegment(handWorld,[handWorld[0],handWorld[1]+.52,handWorld[2]-.07],.035,C.wood);shape('box',handWorld[0]+.06,handWorld[1]+.48,handWorld[2]-.07,.29,.13,.07,C.metal)} }
if(work>0){if(hero.kind==='drink')S('sphere',0,1.54,-.57,.13,.17,.13,C.water);if(hero.kind==='build')S('box',.01,1.13,-.71,.59,.11,.12,C.paleWood);}
}
function objectAvailable(o){if(o.phase==='late'&&!state.flags.beacon)return false;if(o.type==='npc')return o.id==='jana'?!!state.flags.cartFreed:!!state.flags.signal&&state.story.fate!==o.id;if(o.type==='stash')return !!state.flags.signal&&(!state.story.evidence||!!state.story.radioStolen||Object.values(state.story.stolen||{}).some(v=>v>0));if(o.type==='cache')return !state.flags.radioCache;if(o.type==='storySite'&&o.phase==='late')return currentQuest()?.target===o.id;if(o.type==='storySite'&&o.phase==='early')return currentQuest()?.target===o.id;if(o.type==='resin'&&!state.flags.janaHealed)return false;if(o.type==='boar')return !(state.wild?.scared?.[o.id]>state.seconds);if(o.type==='crisis')return state.story.metMara&&state.story.metIvo&&state.story.evidence&&!state.story.fate;if(o.type==='relay')return !!state.story.fate;if(o.type==='crate')return !state.flags.crate;if(o.type==='wreck')return !state.flags.wreck;if(o.type==='site')return true;if(o.type==='storySite'&&o.phase==='survey')return currentQuest()?.target===o.id;if(o.repeat!==undefined)return resourceAvailable(o,state.flags,state.seconds);return true}
function drawObject(o,highlight=false){if(!objectAvailable(o))return;const x=o.x,z=o.z,y=H(x,z),t=elapsed;if(o.type==='npc'){drawNPC(o);return}if(highlight)shape('disc',x,y+.035,z,2.1,1,2.1,C.gold);
if(o.type==='crate'){
  const mat = T(x,y+.31,z,1.1,1.1,1.1,.3);
  if(!tryDrawGLB('crate',mat,[1,1,1])){
    shape('box',x,y+.31,z,1.0,.62,.72,C.wood,.3);
    shape('box',x,y+.64,z,1.06,.13,.79,C.paleWood,.3);
    for(let i of [-1,1])shape('box',x+i*.32,y+.32,z,.08,.70,.78,C.metal,.3);
  }
}
if(o.type==='wood'){for(let j=0;j<3;j++)shape('cyl',x+j*.29-.25,y+.14,z+(j%2)*.18,.21,.95,.21,j%2?C.wood:C.bark,.25+1.4)}
if(o.type==='stone'){for(let j=0;j<5;j++){let a=j*2.43;shape('sphere',x+Math.cos(a)*.30,y+.13,z+Math.sin(a)*.25,.31,.23,.35,j%2?C.stone:C.stoneLight)}}
if(o.type==='fiber'){for(let j=0;j<5;j++){let a=j*1.88;shape('sphere',x+Math.cos(a)*.31,y+.12,z+Math.sin(a)*.23,.34,.14,.16,j%2?C.leaf:C.leaf2,a)}}
if(o.type==='coconut'){for(let j=0;j<3;j++){let a=j*2.10;shape('sphere',x+Math.cos(a)*.22,y+.19,z+Math.sin(a)*.2,.36,.37,.35,C.bark)}}
if(o.type==='spring'){shape('disc',x,y+.075,z,1.65,1,1.65,C.water);shape('sphere',x-.2,y+.21+Math.sin(t*3)*.025,z,.12,.12,.12,C.white)}
if(o.type==='wreck'){shape('box',x-3.45,y+.77,z+.73,.64,.71,.8,C.darkMetal);shape('box',x-3.45,y+1.15,z+.73,.7,.09,.82,C.metal);shape('sphere',x-3.45,y+1.22,z+.73,.20,.12,.20,C.gold)}
if(o.type==='fish'){shape('disc',x,y+.035,z,1.6,1,1.6,C.water);for(let j=0;j<3;j++){let a=j*2.1+t*.42;shape('sphere',x+Math.sin(a)*.47,y+.08,z+Math.cos(a)*.53,.27,.09,.13,C.stoneLight,a)}}
if(o.type==='stash'){shape('box',x,y+.18,z,.88,.35,.67,C.wood,.35);shape('box',x,y+.41,z,.92,.11,.70,C.paleWood,.35);shape('sphere',x+.19,y+.50,z,.12,.07,.10,C.gold)}
if(o.type==='crisis'){shape('box',x,y+.42,z,1.05,.8,.70,C.darkMetal);shape('box',x,y+.87,z,1.00,.13,.72,C.metal);shape('cone',x,y+1.38,z,.13,.95,.13,C.red);shape('sphere',x,y+1.92,z,.20,.20,.20,C.gold)}
if(o.type==='relay'){shape('box',x,y+.50,z,1.1,.83,.71,C.darkMetal);shape('box',x,y+.92,z,1.03,.12,.72,C.stoneLight);shape('cyl',x-.25,y+1.25,z,.05,.68,.05,C.metal);shape('sphere',x+.2,y+.57,z-.38,.15,.15,.10,state.story.repaired?C.leaf2:C.red)}
if(o.type==='cache'){shape('box',x,y+.38,z,1.0,.72,.80,C.darkMetal);shape('box',x,y+.80,z,1.10,.12,.81,C.stoneLight);shape('sphere',x,y+.90,z,.21,.10,.19,C.gold);}if(o.type==='supply'){shape('box',x,y+.43,z,1.35,.72,.8,C.wood,.34);shape('sphere',x,y+1.0,z,.26,.23,.25,C.palm);}
if(o.type==='herb'){for(let j=0;j<6;j++){let a=j*1.047;shape('cone',x+Math.cos(a)*.30,y+.26,z+Math.sin(a)*.30,.16,.54,.20,j%2?C.leaf:C.leaf2,a);}}
if(o.type==='landmark'){if(o.zone==='mangroves'){shape('disc',x,y+.03,z,3.2,1,2.5,[.17,.37,.32]);for(let j=0;j<5;j++){let a=j*1.256;shape('cyl',x+Math.cos(a)*1.2,y+.8,z+Math.sin(a)*1.05,.14,1.6,.14,C.bark);shape('sphere',x+Math.cos(a)*1.3,y+1.65,z+Math.sin(a)*1.1,.7,.32,.7,C.palm);}}else{for(let i=0;i<4;i++)shape('sphere',x+(i-1.5)*.7,y+.32+i*.15,z,.48,.65,.55,i%2?C.stone:C.stoneLight);shape('cyl',x,y+2.1,z,.08,3.1,.08,C.metal);shape('sphere',x,y+3.65,z,.25,.28,.25,C.gold);}}
if(o.type==='cave'){for(let j=-2;j<=2;j++){let a=j*.52;shape('sphere',x+Math.sin(a)*2,y+1.4+Math.cos(a)*2,z,.85,.9,.85,C.stoneLight);}shape('box',x,y+.9,z+.50,1.7,1.8,.30,C.darkMetal);shape('sphere',x,y+.9,z+.28,.17,.2,.14,C.gold);}
if(o.type==='lagoon'){shape('disc',x,y+.055,z,3.4,1,3.0,[.22,.61,.62]);for(let j=0;j<6;j++){let a=j*1.047;shape('sphere',x+Math.cos(a)*1.72,y+.12,z+Math.sin(a)*1.48,.40,.35,.36,j%2?C.stoneLight:C.palm);}shape('cyl',x,y+.40,z,.10,.8,.10,C.metal);shape('sphere',x,y+.87,z,.39,.32,.39,C.red);}
if(o.type==='resin'){shape('cyl',x,y+.38,z,.34,.76,.31,C.bark);shape('sphere',x+.23,y+.61,z-.20,.19,.27,.16,C.gold);}
if(o.type==='storySite'){const tall=['eastStation','eastGenerator','terminal','evac','southMarker'].includes(o.id);shape('box',x,y+.38,z,tall?1.55:1.05,.69,tall?1.15:.77,C.darkMetal,.18);shape('box',x,y+.77,z,tall?1.58:1.09,.12,tall?1.19:.80,C.stoneLight,.18);shape('sphere',x,y+1.04,z,.17,.16,.17,C.gold);if(tall){shape('cyl',x,y+1.60,z,.08,1.15,.08,C.metal);shape('sphere',x,y+2.19,z,.18,.18,.18,C.gold)}}
if(o.type==='boar'){if(state.wild?.scared?.[o.id]>state.seconds)return;let wx=x+Math.sin(elapsed*.38+o.x)*1.1,wz=z+Math.cos(elapsed*.38+o.z)*.8,hy=H(wx,wz);shape('sphere',wx,hy+.61,wz,.80,.59,.45,C.bark);shape('sphere',wx-.45,hy+.70,wz-.21,.43,.34,.36,C.wood);for(let j of [-1,1])for(let k of [-1,1])shape('cyl',wx+j*.42,hy+.27,wz+k*.30,.11,.45,.11,C.bark);for(let k of [-1,1])shape('cone',wx-.76,hy+.65,wz+k*.19,.13,.25,.11,C.stoneLight,.30);shape('disc',wx,hy+.02,wz,1.05,1,1.05,C.red);}
if(o.type==='site'){let stage=state.built[o.site];if(stage<3){for(let j=0;j<4;j++){let a=j*1.57;shape('cyl',x+Math.cos(a)*.7,y+.30,z+Math.sin(a)*.7,.10,.60,.10,C.paleWood)}for(let j=0;j<stage;j++){shape('box',x+(j-.5)*.27,y+.30+j*.13,z,.65,.15,.14,C.wood)}if(stage===0)shape('disc',x,y+.03,z,1.5,1,1.4,C.rope)}
if(stage>=3){if(o.site==='outpost'){shape('box',x,y+1.5,z,3.2,.19,2.6,C.palm);for(let k of [-1,1])for(let j of [-1,1])shape('cyl',x+k*1.4,y+.85,z+j*1.05,.14,1.7,.14,C.wood);shape('box',x,y+.28,z,2.35,.35,1.50,C.wood);}if(o.site==='beacon'){shape('cyl',x,y+3.3,z,.22,6.4,.22,C.metal);shape('box',x,y+5.6,z,1.9,.16,.22,C.darkMetal);shape('cone',x,y+6.62,z,.55,1.3,.55,C.red);}if(o.site==='fire'){if(!tryDrawGLB('campfire',T(x,y,z,1,1,1,0))){for(let j=0;j<8;j++){let a=j*Math.PI/4;shape('sphere',x+Math.cos(a)*.56,y+.12,z+Math.sin(a)*.56,.33,.22,.33,C.stone)}for(let j=0;j<3;j++){let a=j*2.1;shape('cyl',x+Math.sin(a)*.11,y+.18,z+Math.cos(a)*.09,.15,.95,.15,C.wood,a+Math.PI/2)}}for(let j=0;j<3;j++)shape('cone',x+Math.sin(j*2)*.09,y+.55+Math.sin(t*9+j)*.10,z+Math.cos(j*2)*.09,.33,.90,.33,j%2?C.fire:C.gold)}
if(o.site==='shelter'&&!tryDrawGLB('shelter',T(x,y,z,1,1,1,0))){for(let side of [-1,1]){for(let dz of [-.75,.75])shape('cyl',x+side*.95,y+1.18,z+dz,.12,2.3,.12,C.wood)}shape('box',x,y+2.29,z,2.3,.19,2.1,C.paleWood);shape('box',x,y+2.45,z-1.01,2.7,.22,.25,C.palm);shape('box',x,y+2.47,z+1.01,2.7,.22,.25,C.palm);for(let k=0;k<4;k++)shape('box',x-.87+k*.59,y+2.48,z, .55,.08,2.23,k%2?C.palm2:C.palm);shape('box',x,y+.19,z,2.3,.18,1.9,C.wood)}
if(o.site==='filter'&&!tryDrawGLB('filter',T(x,y,z,1,1,1,0))){for(let j of [-1,1])shape('cyl',x+j*.45,y+1.10,z,.10,2.2,.10,C.wood);shape('box',x,y+2.14,z,1.20,.10,.24,C.wood);shape('cone',x,y+1.30,z,1.14,1.42,1.13,C.palm);shape('cyl',x,y+.46,z,.80,.35,.80,C.darkMetal);shape('disc',x,y+.66,z,.65,1,.65,C.water)}
if(o.site==='signal'&&!tryDrawGLB('signal',T(x,y,z,1,1,1,0))){for(let j of [-.65,.65])shape('cyl',x+j,y+1.25,z,.16,2.5,.16,C.wood);shape('box',x,y+2.42,z,1.65,.20,1.3,C.plank);shape('cyl',x,y+3.67,z,.08,2.40,.08,C.metal);shape('box',x,y+4.75,z,.16,.07,1.80,C.metal);shape('cone',x,y+2.81,z,.52,.76,.52,C.gold)} } }
}
function regenCamp(){if(!state)return; /* camp structures and pickups are drawn with persistent state directly; terrain batch stays immutable */ }
function dayValue(){let t=state.clock%24;return clamp(Math.sin((t-5)*Math.PI/14)*1.36,.10,1)}
// Real gameplay gate for the sea cave. The window repeats, and the player can wait or rest.
function lowTide(){return Math.sin((state.clock-4)*Math.PI/6)<.70}
function drawScene(){
 daylight=dayValue();
 const focus=[hero.x+(shoulder?Math.cos(hero.yaw)*.34:0),(camGround??H(hero.x,hero.z))+1.43,hero.z-(shoulder?Math.sin(hero.yaw)*.34:0)];
 const dpr=Math.min(window.devicePixelRatio||1,settings.quality==='low'?1:settings.quality==='high'?1.6:framerate<31?1:1.32);
 renderer.beginFrame({width:$('world').clientWidth,height:$('world').clientHeight,dpr,
   daylight,weather:state.weather,clock:state.clock,time:elapsed,eye,focus,fov:shoulder?62:68,
   fireOn:state?.built?.fire===3?clamp((1-daylight)*1.5+.2,0,1):0,fireY:H(-4,-2)+.7});
drawCount=0;draw(terrainMesh,identity(),[1,1,1],1,0);draw(staticMesh,identity(),[1,1,1],0,0);
// Visual-only swap; show the original ship immediately while the optional GLB loads.
if(!tryDrawGLB('wreck',T(14.4,H(14.4,-11.3),-11.3,1,1,1,.28),[1,1,1]))draw(wreckFallbackMesh,identity(),[1,1,1],0,0);
// A local GLB replaces the static waterfall rocks without covering the moving water.
if(!tryDrawGLB('spring_cliff',T(-16.8,H(-16.8,11.8),11.8,1,1,1,0),[1,1,1]))draw(cliffFallbackMesh,identity(),[1,1,1],0,0);
if(waterfallMesh)draw(waterfallMesh,identity(),[1,1,1],0,2);
// Render only palm instances with the external mesh; keep broadleaf trees in staticMesh.
// If palm.glb is missing/broken, the entire original procedural palm batch remains visible.
if(renderer.hasModel('palm')){
  for(const tree of staticTrees){
    if(tree.kind!=='palm')continue;
    const y=H(tree.x,tree.z);
    const yaw=rand(tree.x*12.9+tree.z*17.2)*Math.PI*2;
    const scale=0.9+rand(tree.x*63.1+tree.z*71.5)*0.4;
    tryDrawGLB('palm',T(tree.x,y,tree.z,scale,scale,scale,yaw),[1,1,1]);
  }
}else draw(staticPalmMesh,identity(),[1,1,1],0,0);
draw(seaMesh,identity(),[1,1,1],2,1);let visible=OBJ.filter(o=>Math.hypot(hero.x-o.x,hero.z-o.z)<33);for(let o of visible)drawObject(o,hero.target?.id===o.id&&Math.hypot(hero.x-o.x,hero.z-o.z)<6);if(renderer.heroReady)draw('disc',T(hero.x,H(hero.x,hero.z)+.018,hero.z,1.0,1,.72,hero.yaw),[.18,.16,.12],3,0);drawRobinson();renderer.drawHero({x:hero.x,y:H(hero.x,hero.z),z:hero.z,yaw:hero.yaw,walk:hero.walk,working:hero.working,kind:hero.kind},Math.min(.055,Math.max(0,elapsed-(renderer.heroLastTime??elapsed))));renderer.heroLastTime=elapsed;updateQuestPointer();renderer.endFrame();}
// Movement, obstacle sliding and camera clipping. All coordinates remain in one contiguous world.
const keys=new Set(),joy={x:0,y:0},touches=new Map();let running=false,rotating=false,drag={x:0,y:0,t:0,moved:false},pinchPrevious=0,visibleObj=null,autogoal=null,prevMovement=false,pane='',mini=null;
function d2(a,b){return Math.hypot(a.x-b.x,a.z-b.z)}
function currentQuest(){return QUESTS.find(q=>(!q.active||q.active(state))&&!state.flags['quest-'+q.id]&&!q.done(state))||null}
function currentQuestTarget(){
 const quest=currentQuest(),requested=quest&&OBJ.find(o=>o.id===quest.target);
 if(!requested)return null;
 if(objectAvailable(requested))return requested;
 if(['wood','stone','fiber','coconut','herb','resin'].includes(requested.type)){
  return OBJ.filter(o=>o.type===requested.type&&objectAvailable(o))
   .sort((a,b)=>d2(hero,a)-d2(hero,b))[0]||null;
 }
 return null;
}
function facing(dx,dz){return Math.atan2(-dx,-dz)}
// GFX19: the head marker is a projected HUD element, not a flat 3D triangle.
// This keeps the direction legible at low camera angles, without GPU draw calls.
const questPointer=$('questPointer');
function updateQuestPointer(){
 if(!questPointer)return;
 const target=started&&!pane&&!mini&&state&&$('fatal').hidden?currentQuestTarget():null;
 if(!target){questPointer.hidden=true;return;}
 const cam=renderer.camera, m=cam.matrixWorld.elements;
 const box=$('world').getBoundingClientRect();
 const pose=computeQuestPointer({x:hero.x,y:H(hero.x,hero.z),z:hero.z},target,{
   eye:[m[12],m[13],m[14]],right:[m[0],m[1],m[2]],
   up:[m[4],m[5],m[6]],forward:[-m[8],-m[9],-m[10]],fov:cam.fov
 },{width:box.width,height:box.height});
 if(!pose){questPointer.hidden=true;return;}
 questPointer.hidden=false;
 questPointer.style.left=(box.left+pose.left).toFixed(1)+'px';
 questPointer.style.top=(box.top+pose.top+Math.sin(elapsed*2.2)*2).toFixed(1)+'px';
 questPointer.style.transform='translate(-50%, -50%) rotate('+pose.angle.toFixed(2)+'deg)';
}
function nearbyObject(maxDist=3.15){const max=maxDist+(state.skills.scout?1.6:0);let qobj=currentQuestTarget();if(qobj&&objectAvailable(qobj)&&d2(hero,qobj)<qobj.r+2.1)return qobj;let nearest=null,dd=max;for(let o of OBJ){if(!objectAvailable(o))continue;let r=Math.hypot(hero.x-o.x,hero.z-o.z)-o.r;if(r<dd){nearest=o;dd=r}}/* In the tutorial, do not let a nearby resource hide an equally reachable quest object. */let focus=currentQuestTarget();if(focus&&objectAvailable(focus)&&d2(hero,focus)-focus.r<max&&(!nearest||d2(hero,focus)-focus.r<dd+.70))return focus;return nearest}
function passable(x,z){if(Math.hypot(x/82,z/74)>1.04||H(x,z)<-.45)return false;for(let p of sceneObstacles){let rr=p.r+.33;if((x-p.x)**2+(z-p.z)**2<rr*rr)return false}for(let o of OBJ){if(o.type!=='site'&&o.type!=='wreck')continue;let rr=o.type==='wreck'?1.45:o.site==='shelter'&&state.built.shelter===3?1.4:.48;if((x-o.x)**2+(z-o.z)**2<rr*rr)return false}return true}
// Safe-point checkpoint uses ORIGINAL physics collision, not the character's animated mesh.
function safeForRecovery(x,z){
 if(!Number.isFinite(x)||!Number.isFinite(z)||!passable(x,z))return false;
 for(const [dx,dz] of [[.32,0],[-.32,0],[0,.32],[0,-.32]])if(!passable(x+dx,z+dz))return false;
 return Number.isFinite(H(x,z));
}
function checkpointHero(force=false){
 if(!safeForRecovery(hero.x,hero.z))return;
 if(!force&&Math.hypot(hero.x-lastSafePosition.x,hero.z-lastSafePosition.z)<1.35)return;
 previousSafePosition={...lastSafePosition};lastSafePosition={x:hero.x,z:hero.z};state.safe={...lastSafePosition};state.safePrev={...previousSafePosition};changed=true;
}
function findRecoveryPosition(){
 // First try an OLDER checkpoint: a mesh without physics collision may contain
 // the latest checkpoint. Pressing recovery should produce an actual displacement.
 const proposals=[previousSafePosition,lastSafePosition,state?.safePrev,state?.safe,{x:-1,z:-12}];
 for(const p of proposals){if(!p||!Number.isFinite(p.x)||!Number.isFinite(p.z))continue;
  if(Math.hypot(p.x-hero.x,p.z-hero.z)>1.15&&safeForRecovery(p.x,p.z))return {x:p.x,z:p.z};
 }
 // If none is distant enough, search open ground around the CURRENT position.
 for(let radius=1.5;radius<=8;radius+=.55)for(let step=0;step<32;step++){
  let a=step*Math.PI/16,x=hero.x+Math.cos(a)*radius,z=hero.z+Math.sin(a)*radius;
  if(safeForRecovery(x,z))return {x,z};
 }
 // If current position is invalid, search around saved points for a safe place.
 for(const p of proposals){if(!p||!Number.isFinite(p.x)||!Number.isFinite(p.z))continue;
  for(let radius=.65;radius<=7;radius+=.65)for(let step=0;step<24;step++){
   let a=step*Math.PI/12,x=p.x+Math.cos(a)*radius,z=p.z+Math.sin(a)*radius;
   if(safeForRecovery(x,z))return {x,z};
  }
 }
 return null;
}
function unstuckHero(){
 if(!started)return;
 if(now()-unstuckAt<1100){if(pane&&!mini)closePanel();flash('Počkej okamžik, než odblokování zopakuješ.');return;}
 let safe=findRecoveryPosition();
 if(!safe){flash('Nepodařilo se najít průchozí místo. Zkus načíst poslední uložení.');return;}
 unstuckAt=now();
 // Cancel the action before moving: an interaction must never finish remotely after teleport.
 pending=null;autogoal=null;hero.goal=null;hero.target=null;hero.working=0;hero.walk=0;
 keys.clear();running=false;joy.x=joy.y=0;$('stick').style.transform='translate(0,0)';
 hero.x=safe.x;hero.z=safe.z;hero.y=H(safe.x,safe.z);
 state.x=safe.x;state.z=safe.z;state.yaw=hero.yaw;
 previousSafePosition={...lastSafePosition};lastSafePosition={...safe};state.safe={...safe};state.safePrev={...previousSafePosition};
 camGround=hero.y;cameraPos=[hero.x+Math.sin(cameraYaw)*5,hero.y+4,hero.z+Math.cos(cameraYaw)*5];
 if(pane&&!mini)closePanel();
 changed=true;save(true);updateUI();flash('↩ Robinson je zpátky na bezpečném místě.');
}
function moveHero(dx,dz,dt,sprint){let speed=(sprint&&state.energy>7?4.7:2.55)*(state.skills.scout?1.12:1),mag=Math.hypot(dx,dz);if(mag<.09||pending||pane){hero.walk=mix(hero.walk,0,clamp(dt*8,0,1));return false}dx/=mag;dz/=mag;speed*=clamp(1.3-Math.hypot(H(hero.x+.30,hero.z)-H(hero.x-.30,hero.z),H(hero.x,hero.z+.30)-H(hero.x,hero.z-.30))*.3,.72,1.12);let step=dt*speed,nx=hero.x+dx*step,nz=hero.z+dz*step,success=false;
if(passable(nx,nz)){hero.x=nx;hero.z=nz;success=true}else if(passable(nx,hero.z)){hero.x=nx;success=true}else if(passable(hero.x,nz)){hero.z=nz;success=true}
if(success){hero.y=H(hero.x,hero.z);hero.yaw+=Math.atan2(Math.sin(facing(dx,dz)-hero.yaw),Math.cos(facing(dx,dz)-hero.y))*clamp(dt*11,0,1);hero.anim+=dt*(sprint?1.5:1.0)*2.5;hero.walk=mix(hero.walk,sprint?1.3:1,clamp(dt*8,0,1));state.x=hero.x;state.z=hero.z;state.yaw=hero.yaw;checkpointHero();state.energy=clamp(state.energy-dt*(sprint?(state.skills.endurance?.72:1.12):.22),0,100);state.food=clamp(state.food-dt*.012,0,100);state.water=clamp(state.water-dt*(Math.hypot(hero.x,hero.z)>29?.082:.026),0,100);state.food=clamp(state.food-dt*(Math.hypot(hero.x,hero.z)>29?.038:0),0,100);changed=true;return true}hero.walk=mix(hero.walk,0,clamp(dt*7,0,1));return false}
function updateCamera(dt){let distance=shoulder?4.0:wideDistance;let pitch=shoulder?clamp(cameraPitch,.05,.65):cameraPitch;if(camGround===null)camGround=H(hero.x,hero.z);camGround=mix(camGround,H(hero.x,hero.z),clamp(dt*3.6,0,1));let focus=[hero.x+(shoulder?Math.cos(hero.yaw)*.34:0),camGround+1.43,hero.z-(shoulder?Math.sin(hero.yaw)*.34:0)];let dir=[Math.sin(cameraYaw)*Math.cos(pitch),Math.sin(pitch),Math.cos(cameraYaw)*Math.cos(pitch)];let desired=[focus[0]+dir[0]*distance,focus[1]+1.2+dir[1]*distance,focus[2]+dir[2]*distance];
// Camera line-of-sight: pull in before static obstacles; never burrow through ground.
for(let t=.30;t<=1;t+=.07){let p=[mix(focus[0],desired[0],t),mix(focus[1],desired[1],t),mix(focus[2],desired[2],t)];let occluded=p[1]<H(p[0],p[2])+.72;for(let tree of staticTrees)if(Math.hypot(p[0]-tree.x,p[2]-tree.z)<tree.r&&p[1]<H(tree.x,tree.z)+3.3)occluded=true;if(occluded){let k=Math.max(.23,t-.14);desired=[mix(focus[0],desired[0],k),mix(focus[1],desired[1],k),mix(focus[2],desired[2],k)];break}}
desired[1]=Math.max(desired[1],H(desired[0],desired[2])+.75,-.1);let sm=clamp(dt*8,0,1);for(let j=0;j<3;j++)cameraPos[j]=mix(cameraPos[j],desired[j],sm);eye=cameraPos.slice();VP=mul(perspective((shoulder?62:68)*Math.PI/180,Math.max(.1,$('world').clientWidth/$('world').clientHeight),.09,190),lookAt(eye,focus));inverseVP=inverse(VP)}
function gameplay(dt){if(!started||pane||mini)return;state.seconds+=dt;updateNPCs(dt);state.clock+=dt/120;if(Math.floor(state.seconds/5)!==Math.floor((state.seconds-dt)/5))changed=true; if(state.clock>=24){state.clock-=24;state.day++;changed=true}if(state.story.stormUntil&&state.seconds<state.story.stormUntil)state.weather='storm';else if(state.day%3===0&&state.clock>13&&state.clock<17)state.weather='rain';else state.weather='clear';
let forward=(keys.has('w')||keys.has('ArrowUp')?1:0)-(keys.has('s')||keys.has('ArrowDown')?1:0)-joy.y;let strafe=(keys.has('d')||keys.has('ArrowRight')?1:0)-(keys.has('a')||keys.has('ArrowLeft')?1:0)+joy.x;let dx=strafe*Math.cos(cameraYaw)-forward*Math.sin(cameraYaw),dz=-strafe*Math.sin(cameraYaw)-forward*Math.cos(cameraYaw);
if(Math.hypot(dx,dz)>.09){autogoal=null;hero.goal=null;moveHero(dx,dz,dt,running||keys.has('Shift'))}else if(autogoal){let dd=d2(hero,autogoal);if(dd<Math.max(1.15,autogoal.r+.80)){let goal=autogoal;autogoal=null;if(goal.o)beginInteraction(goal.o);hero.walk=mix(hero.walk,0,dt*9)}else {let stepX=(autogoal.x-hero.x)/dd,stepZ=(autogoal.z-hero.z)/dd;let moved=moveHero(stepX,stepZ,dt,true);if(!moved&&hero.walk<.13)autogoal=null}}else{hero.walk=mix(hero.walk,0,clamp(dt*6,0,1));state.energy=clamp(state.energy+dt*(state.built.shelter===3?.80:.48),0,100)}
if(state.food<=0||state.water<=0){state.hp=clamp(state.hp-dt*.44,0,100);if(state.hp<=0){state.hp=34;state.food=Math.max(state.food,25);state.water=Math.max(state.water,25);hero.x=-4;hero.z=-2;state.x=hero.x;state.z=hero.z;flash('Robinson zkolaboval. Probral se v táboře, ale potřebuje vodu a jídlo.')}}
updateWildSurvival(dt);
if(pending){pending.remaining-=dt;hero.working=1-pending.remaining/pending.duration;hero.kind=pending.kind;if(pending.remaining<=0){let w=pending.work;pending=null;hero.working=0;try{w()}catch(e){console.error(e);flash('Akci se nepodařilo dokončit.')}}}else hero.working=0;
if(now()-lastHud>160){lastHud=now();updateUI()}}
function updateWildSurvival(dt){
 if(!state.wild)state.wild={lastHit:0,scared:{},warning:''};
 let safeCamp=Math.hypot(hero.x+4,hero.z+2)<8&&state.built.shelter===3;
 let safeOutpost=Math.hypot(hero.x-12,hero.z-47)<7&&state.built.outpost===3;
 let highland=hero.z>35,swamp=hero.x<-34&&hero.z>0&&hero.z<30;
 let exposed=(state.weather==='storm'||state.weather==='rain'||(highland&&(dayValue()<.48)))&&!safeCamp&&!safeOutpost;
 let rate=exposed?(highland?1.15:.53)+(swamp?.32:0):-1.85;
 state.exposure=clamp((state.exposure||0)+rate*dt,0,100);
 if(state.exposure>79)state.hp=clamp(state.hp-dt*.38,0,100);
 if(swamp){state.water=clamp(state.water-dt*.065,0,100);state.energy=clamp(state.energy-dt*.10,0,100);}
 // The boars patrol their own zones; a spear can scare them off for 45 game seconds.
 for(const boar of OBJ){if(boar.type!=='boar')continue;
  if((state.wild.scared?.[boar.id]||0)>state.seconds)continue;
  const wx=boar.x+Math.sin(elapsed*.38+boar.x)*1.1,wz=boar.z+Math.cos(elapsed*.38+boar.z)*.8;
  const distance=Math.hypot(wx-hero.x,wz-hero.z);
  if(distance<5.3&&state.seconds-(state.wild.warnAt||-1e5)>13){state.wild.warnAt=state.seconds;flash('⚠ Divoký kanec! Opatrně ustup nebo použij kopí.');}
  if(distance<2.05&&state.seconds-(state.wild.lastHit||-1e5)>9){state.wild.lastHit=state.seconds;
    const damage=state.bag.spear>0?11:23;
    state.hp=clamp(state.hp-damage,0,100);state.energy=clamp(state.energy-12,0,100);
    flash('🐗 Kanec zaútočil! -'+damage+' zdraví. '+(state.bag.spear?'Použij AKCE s kopím.':'Vyrob kopí ve Výrobě.'));
    changed=true;
  }
 }
 if(state.hp<=0){state.hp=34;state.food=Math.max(18,state.food);state.water=Math.max(18,state.water);state.exposure=30;
   hero.x=-4;hero.z=-2;hero.y=H(hero.x,hero.z);state.x=hero.x;state.z=hero.z;
   pending=null;autogoal=null;hero.target=null;camGround=hero.y;
   flash('Robinson zkolaboval a probral se v táboře. Ošetři se a doplň zásoby.');changed=true;save(true);
 }
}
function finishAction(o,kind,work,duration=1.05){if(pending)return;pending={o,kind,work,duration,remaining:duration};hero.goal=null;autogoal=null;hero.working=.01;hero.kind=kind;hero.yaw=facing(o.x-hero.x,o.z-hero.z);}
function add(id,n=1){state.bag[id]=(state.bag[id]||0)+n;changed=true;if(['wood','stone','fiber','coconut','scrap','herb'].includes(id))voiceEvent({type:'gather'});flash('+'+n+' · '+ITEM[id]?.[1]);}
function has(items){return Object.entries(items).every(([id,n])=>(state.bag[id]||0)>=n)}
function spend(items){if(!has(items))return false;for(let [id,n] of Object.entries(items))state.bag[id]-=n;changed=true;return true}
function costs(items){return Object.entries(items).map(([id,n])=>(ITEM[id]?.[0]||'◈')+' '+(ITEM[id]?.[1]||id)+' ×'+n).join(' · ')}
function needXP(lvl){return 75+lvl*42+lvl*lvl*10}
function awardXP(n,reason){state.xp+=n;flash('✦ +'+n+' XP · '+reason);while(state.xp>=needXP(state.level)){state.xp-=needXP(state.level);state.level++;state.points++;state.energy=clamp(state.energy+14,0,100);state.hp=clamp(state.hp+8,0,100);state.journal.push('Den '+state.day+': Dosáhl jsem úrovně '+state.level+'. Získal jsem bod dovedností.');flash('NOVÁ ÚROVEŇ '+state.level+' · +1 bod dovedností')}changed=true}
function checkQuest(){let completed=0;for(let q of QUESTS){if(q.active&&!q.active(state))continue;if(state.flags['quest-'+q.id])continue;if(!q.done(state))break;state.flags['quest-'+q.id]=true;voiceEvent({type:'quest',id:q.id});state.playMetrics.completedAt[q.id]=Math.round(state.playMetrics.activeSeconds);state.journal.push('Den '+state.day+': '+q.name+'. '+q.desc);awardXP(q.xp,'Úkol: '+q.name);completed++;changed=true}if(completed){save(true);updateUI()}}
const RECIPES=[
 {id:'cord',icon:'🧶',name:'Pevný provaz',desc:'Upevnění přístřešku a ohniště.',cost:{fiber:2},visible:s=>s.flags.surveyCamp,flag:'craftedCord'},
 {id:'tinder',icon:'🔥',name:'Suchý troud',desc:'Rozdělání prvního ohně.',cost:{wood:1,fiber:1},visible:s=>s.flags.craftedCord,flag:'craftedTinder'},
 {id:'handle',icon:'🪵',name:'Dřevěná násada',desc:'Připravený díl sekery.',cost:{wood:1,cord:1},visible:s=>s.flags.toolmark,flag:'craftedHandle'},
 {id:'axe',icon:'🪓',name:'Kamenná sekera',desc:'Nástroj pro dřevo a lagunu.',cost:{wood:2,stone:2,fiber:1,handle:1},visible:s=>s.flags.craftedHandle,flag:'craftedAxe',once:true},
 {id:'bandage',icon:'🩹',name:'Obvaz',desc:'Jednorázové ošetření.',cost:{fiber:2},visible:s=>s.flags.firstFiber},
 {id:'spear',icon:'🗡',name:'Lovecké kopí',desc:'Ochrana před kanci.',cost:{wood:3,stone:2,fiber:2},visible:s=>s.flags.signal,flag:'craftedSpear',once:true},
 {id:'torch',icon:'🕯',name:'Pochodeň',desc:'Prozkoumání mokřadů a jeskyně.',cost:{wood:1,tinder:1,cord:1},visible:s=>s.flags.expedition,flag:'craftedTorch',once:true},
 {id:'compass',icon:'🧭',name:'Polní kompas',desc:'Odemkne severozápadní stezku.',cost:{scrap:1,stone:1,cord:1},visible:s=>s.flags.charts,flag:'craftedCompass',once:true},
 {id:'brace',icon:'🪚',name:'Zpevňovací vzpěra',desc:'Vyproštění expedičního vozíku.',cost:{wood:3,cord:1},visible:s=>s.flags.cartFound,flag:'craftedBrace',once:true},
 {id:'pouch',icon:'🎒',name:'Voděodolné pouzdro',desc:'Ochrání mapu v mokřadu.',cost:{fiber:3,resin:2,cord:1},visible:s=>s.flags.janaHealed,flag:'craftedPouch',once:true},
 {id:'kit',icon:'🛠',name:'Opravárenská sada',desc:'Obnoví napájení radiostanice.',cost:{scrap:2,wood:1,cord:1},visible:s=>s.flags.stationFound,flag:'craftedKit',once:true},
];
function makeRecipe(id){const rc=RECIPES.find(r=>r.id===id);if(!rc||!rc.visible(state)||(rc.once&&state.flags[rc.flag]))return;if(!has(rc.cost)){flash('Chybí: '+costs(rc.cost));return}if(!spend(rc.cost))return;add(id);if(rc.flag)state.flags[rc.flag]=true;writeStory('Vyrobil jsem '+rc.name.toLowerCase()+'. '+rc.desc);checkQuest();save(true);renderPane();}
function consumeFood(){if(state.bag.coconut<=0){flash('Nemáš kokos. Najdi ho pod palmami.');return}state.bag.coconut--;state.food=clamp(state.food+32,0,100);state.water=clamp(state.water+9,0,100);changed=true;flash('🥥 Kokos zahnal hlad.');checkQuest();renderPaneIfOpen();}
function fishMini(source){mini={kind:'fish',sourceId:source?.id||'fish',t:0,hits:0,attempts:0,displayedPercent:fishNeedlePercent(0)};pane='mini';$('panel').classList.add('open');$('panel').setAttribute('aria-hidden','false');renderPane()}
function interactStorySite(o){
 const id=o.id, f=state.flags, quest=currentQuest();
 if(o.phase==='late'&&quest?.target!==id&&!(id==='cart'&&f.cartFound)){
   flash('Nejdřív dokonči aktuální úkol. Následuj značku v deníku.');return;
 }
 if(id==='coastSurvey'||id==='westSurvey'||id==='ridgeSurvey'){
  if(state.water<18||state.energy<14){flash('Na průzkum potřebuješ alespoň 18 vody a 14 energie. Napij se a odpočiň si.');return;}
  const clues={
   coastSurvey:'V zátoce jsem objevil části staré bedny a cestu podél pobřeží. Při bouři bude bezpečnější držet se výše nad hladinou.',
   westSurvey:'V mangrovech zůstaly značky staré výpravy. Opatrná stezka vede na sever, mimo hluboký mokřad.',
   ridgeSurvey:'Z hřebene je vidět horský pramen, pobřeží i kouř tábora. Tudy se dá vrátit bez bloudění.'
  };
  finishAction(o,'gather',()=>{state.flags[id]=true;state.journal.push('Den '+state.day+': '+clues[id]);flash('🧭 Průzkum dokončen. '+clues[id]);checkQuest();save(true)},2.2);return;
 }
 if(id==='campPlan'){finishAction(o,'gather',()=>{f.surveyCamp=true;writeStory('Na vyvýšeném místě jsem našel suchou půdu. Nejprve upletu provaz, potom připravím oheň.');checkQuest();save(true)},1.2);return}
 if(id==='toolmark'){finishAction(o,'gather',()=>{f.toolmark=true;writeStory('Na pracovní desce je vyrytý návod na sekeru. Nejdřív musím připravit násadu.');checkQuest();save(true)},1.4);return}
 if(id==='wreckLog'){finishAction(o,'gather',()=>{f.wreckLog=true;writeStory('Lodní zápisník zmiňuje radistu, dva trosečníky a záhadnou výpravu na severozápad.');checkQuest();save(true)},1.5);return}
 if(id==='packet'){finishAction(o,'gather',()=>{f.packet=true;writeStory('Ze signálu jsem získal volací znak K-314. Někdo na ostrově vysílá z jiné stanice.');checkQuest();save(true)},2);return}
 if(id==='chartLock'){finishAction(o,'gather',()=>{f.charts=true;add('chart');add('scrap',2);writeStory('Ve schránce jsou souřadnice severozápadní stezky, části kompasu a první číslice šifry: 3.');checkQuest();save(true)},2);return}
 if(id==='westTrail'){if(!f.craftedCompass){flash('Bez kompasu nenajdeš značky v hustém lese.');return;}finishAction(o,'gather',()=>{f.westTrail=true;writeStory('Bílé značky vedou k rozbité lávce přes roklinu. Na druhé straně leží vozík.');checkQuest();save(true)},2.1);return}
 if(id==='cart'){if(!f.bridgeBuilt){flash('Roklina je příliš hluboká. Nejdřív postav lávku.');return;}if(!f.cartFound){finishAction(o,'gather',()=>{f.cartFound=true;writeStory('Pod převráceným vozíkem je živá kartografka Jana, ale bez vzpěry vozík nezvednu.');checkQuest();save(true)},1.8);return;}if(!f.cartFreed){if(!state.bag.brace){flash('Vozík je stále zaklíněný. Vyrob zpevňovací vzpěru.');return}finishAction(o,'build',()=>{if(!spend({brace:1}))return;f.cartFreed=true;writeStory('Vozík se podařilo nadzvednout. Jana se dovlekla na stezku a teď čeká na ošetření.');checkQuest();save(true)},3.5);return;}flash('Vozík je vyproštěn. Jana čeká u stezky.');return;}
 if(id==='fogArchive'){if(!f.craftedPouch||!state.bag.pouch||!state.bag.torch){flash('Potřebuješ voděodolné pouzdro a pochodeň.');return;}if(state.hp<45||state.energy<32){flash('Mokřad je nebezpečný. Ošetři se a načerpej alespoň 32 energie a 45 zdraví.');return;}finishAction(o,'gather',()=>{state.energy=clamp(state.energy-25,0,100);f.fogArchive=true;add('seal');add('scrap',2);writeStory('Ve schránce byla přístavní pečeť. Druhá číslice šifry je 1.');checkQuest();save(true)},3.7);return;}
 if(id==='eastStation'){if(!f.fogArchive){flash('Potřebuješ nejprve přístavní pečeť z mlžného lesa.');return;}finishAction(o,'gather',()=>{f.stationFound=true;add('scrap',2);writeStory('Stanice je bez proudu. Poslední číslice šifry je 4. Generátor opravím jen se sadou nářadí.');checkQuest();save(true)},2.4);return;}
 if(id==='eastGenerator'){if(!state.bag.kit||!has({scrap:1})){flash('Generátor potřebuje opravárenskou sadu a kovovou součástku.');return;}if(state.energy<32){flash('Na opravu generátoru potřebuješ alespoň 32 energie.');return;}finishAction(o,'build',()=>{if(!spend({kit:1,scrap:1}))return;state.energy-=23;f.generator=true;writeStory('Generátor ožil. Na terminálu je zámek se třemi číslicemi.');checkQuest();save(true)},3.8);return;}
 if(id==='terminal'){if(!f.generator){flash('Terminál je bez elektřiny. Oprav generátor.');return;}openPanel('cipher');return;}
 if(id==='southMarker'){if(!f.decoded){flash('Bez rozluštěných souřadnic nepoznáš místo setkání.');return;}finishAction(o,'gather',()=>{f.southMarker=true;writeStory('Jižní pobřeží je jediný bezpečný bod pro přistání. Bude potřeba světlice a pevné molo.');checkQuest();save(true)},1.5);return;}
 if(id==='flareCache'){finishAction(o,'gather',()=>{f.flares=true;add('flare');add('wood',3);add('fiber',2);writeStory('V jihozápadním skladu zůstala poslední použitelná světlice.');checkQuest();save(true)},2.4);return;}
 if(id==='evac'){if(!f.pierBuilt||!f.finalPack||!state.bag.flare||!state.bag.chart){flash('Připrav molo, finální zásoby, světlici a mapu.');return;}if(state.weather==='storm'||state.clock<5||state.clock>9){flash('Záchranný člun připlouvá mezi 05:00 a 09:00 pouze bez bouře. Odpočiň si a vrať se ráno.');return;}if(state.hp<50||state.water<40||state.energy<40){flash('Na poslední cestu potřebuješ 50 zdraví, 40 vody a 40 energie.');return;}finishAction(o,'build',()=>{f.evacuated=true;state.bag.flare--;writeStory(state.story.fate==='mara'?'Jana s Ivem mě doprovodili na molo. Signál dorazil ke člunu, ale z ostrova se vracíme s těžkým tajemstvím.':'Jana s Márou mě doprovodili na molo. Světlice přivolala člun; Mára teď musí čelit minulosti.');checkQuest();save(true);openPanel('epilogue');},4.5);return;}
}
function interactObject(o){if(!o||pending||mini||pane)return;if(o.type==='crate'&&!state.flags.crate)voiceEvent({type:'crate-approach'});let d=d2(hero,o);if(d>o.r+1.10){autogoal={x:o.x,z:o.z,r:o.r,o};hero.target=o;flash('Robinson se přesouvá k cíli.');return}beginInteraction(o)}
function beginInteraction(o){if(pending||mini||pane||!objectAvailable(o))return;hero.target=o;let type=o.type;
if(type==='storySite'){interactStorySite(o);return;}
if(type==='resin'){finishAction(o,'gather',()=>{add('resin');state.flags.resinCollected=(state.flags.resinCollected||0)+1;recordGather(o,state.flags,state.seconds);checkQuest();save(true)},1.8);return;}
if(type==='crate')finishAction(o,'gather',()=>{state.flags.crate=true;add('wood',2);add('stone',1);add('fiber',1);state.journal.push('Pod víkem bedny byly první zásoby.');checkQuest();save(true)},1.40);
else if(type==='wood'||type==='stone'||type==='fiber'||type==='coconut')finishAction(o,type==='wood'&&state.bag.axe?'chop':'gather',()=>{add(type==='coconut'?'coconut':type,1+(state.skills.gatherer&&(type==='wood'||type==='fiber')?1:0));recordGather(o,state.flags,state.seconds);const gflag=type==='wood'?'firstWood':type==='stone'?'firstStone':type==='fiber'?'firstFiber':'firstCoconut';state.flags[gflag]=true;checkQuest()},type==='wood'&&state.bag.axe?1.40:1.06);
else if(type==='spring')finishAction(o,'drink',()=>{state.water=clamp(state.water+(state.skills.hydration?70:48),0,100);if(state.flags.spring)state.flags.firstDrink=true;state.flags.spring=true;flash('💧 Čerstvá voda obnovila žízeň. '+(state.flags.firstDrink?'Máš sílu na cestu zpátky.':'Ještě se napij a doplň zásoby na návrat.'));checkQuest();save(true)},1.08);
else if(type==='wreck')finishAction(o,'gather',()=>{state.flags.wreck=true;add('scrap',2);state.journal.push('Ve vraku Esperanzy jsem našel kovové díly. Našel jsem také značky na mapě pobřeží.');checkQuest();save(true)},1.65);
else if(type==='cache')finishAction(o,'gather',()=>{if(state.flags.radioCache)return;state.flags.radioCache=true;add('scrap',3);add('wood',2);writeStory('Našel jsem díly ze staré pobřežní stanice. Kov bude potřeba na maják.');checkQuest();save(true)},2.0);
else if(type==='supply'){
 if(currentQuest()?.id==='surveyNotes'&&!state.flags.surveyNotes){
   finishAction(o,'build',()=>{state.flags.surveyNotes=true;
    state.journal.push('Den '+state.day+': Zanesl jsem do mapy trasu z pobřeží přes mangrovy na hřeben. Další výprava povede kolem známých zdrojů vody a bezpečných úkrytů.');
    flash('🗺️ Plán výpravy je hotový. Připrav si kopí a zásoby.');checkQuest();save(true)},2.0);return;
 }
 if(state.flags.expedition){if(currentQuest()?.id==='finalPack'&&!state.flags.finalPack){let supplies={coconut:2,bandage:1,fish:1,cord:2};if(!has(supplies)){flash('Závěrečné zásoby: '+costs(supplies));return;}finishAction(o,'build',()=>{if(!spend(supplies))return;state.flags.finalPack=true;add('ration',2);writeStory('Na poslední plavbu jsem připravil jídlo, obvaz, vodu a provazy.');checkQuest();save(true)},2.6);return;}flash('Výprava je připravená. Pro další etapu sleduj deník.');return;}
 let materials={coconut:2,bandage:1,fiber:2};
 if(!state.bag.spear||!has(materials)){flash('Na výpravu potřebuješ kopí, 2 kokosy, obvaz a 2 vlákna.');return;}
 finishAction(o,'build',()=>{if(!spend(materials))return;state.flags.expedition=true;add('ration');writeStory('Připravil jsem výstroj na několikadenní cestu ostrovem.');checkQuest();save(true)},2.3);
}
else if(type==='landmark')finishAction(o,'gather',()=>{state.flags[o.zone]=true;writeStory(o.zone==='mangroves'?'Prozkoumal jsem vlhké mangrovy. Voda tu není pitná.':'Na severním hřebeni fouká silný vítr. Bez přístřešku tu nepřežiju noc.');flash(o.zone==='mangroves'?'🌿 Mangrovy prozkoumány. Hledej léčivé rostliny.':'⛰ Severní hřeben objeven. Postav horský přístřešek.');checkQuest();save(true)},1.2);
else if(type==='herb')finishAction(o,'gather',()=>{add('herb');state.flags.herbCollected=(state.flags.herbCollected||0)+1;recordGather(o,state.flags,state.seconds);checkQuest();save(true)},1.45);
else if(type==='boar'){
 if(state.bag.spear<1){flash('Kanec je nebezpečný. V nabídce Výroba nejprve vyrob lovecké kopí.');return;}
 if((state.wild?.scared?.[o.id]||0)>state.seconds)return;
 finishAction(o,'chop',()=>{state.energy=clamp(state.energy-10,0,100);state.wild.scared[o.id]=state.seconds+45;flash('🗡 Kanec utekl. Máš čas projít jeho územím.');save(true)},1.0);
}
else if(type==='cave'){
 if(state.flags.cave){flash('V jeskyni jsi už vyzvedl rádiové jádro.');return;}
 if(!state.bag.spear){flash('Stezka k jeskyni je nebezpečná. Nejprve vyrob kopí.');return;}
 if(dayValue()<.40){flash('V jeskyni je příliš tma. Počkej do dne nebo se vrať na hřeben.');return;}
 if(!lowTide()){flash('🌊 Příliv uzavřel vchod do jeskyně. Počkej na odliv; aktuální stav najdeš v mapě.');return;}
 if(state.energy<28){flash('Na průzkum jeskyně potřebuješ alespoň 28 energie.');return;}
 finishAction(o,'gather',()=>{state.energy-=24;state.flags.cave=true;add('core');writeStory('Za přílivem jsem nalezl funkční jádro nouzového vysílače.');checkQuest();save(true)},3.2);
}
else if(type==='lagoon'){
 if(state.flags.lagoon){flash('Bóje je už rozebraná.');return;}
 if(!state.bag.axe||state.energy<42||state.water<35){flash('Potřebuješ sekeru, alespoň 42 energie a 35 vody.');return;}
 finishAction(o,'gather',()=>{state.energy-=32;state.water-=18;state.flags.lagoon=true;add('lens');writeStory('Z jižní bóje jsem získal čočku pro nouzový maják.');checkQuest();save(true)},3.0);
}
else if(type==='fish')fishMini(o);
else if(type==='npc')finishAction(o,'gather',()=>talkToNPC(o.id),.75);
else if(type==='stash')finishAction(o,'gather',()=>visitStash(),1.25);
else if(type==='crisis')finishAction(o,'gather',()=>openPanel('fate'),1.20);
else if(type==='relay')repairRelay(o);
else if(type==='site'){let site=o.site,stage=state.built[site]||0;if(site==='bridge'&&!state.flags.westTrail){flash('Nejdřív vyhledej stezku s kompasem.');return;}if(site==='pier'&&!state.flags.flares){flash('Nejdřív najdi signální světlici.');return;}if(site==='beacon'&&!state.flags.cave){flash('Nejdřív najdi rádiové jádro v jeskyni.');return;}if(stage<3){if(stage===0&&site==='fire'&&!state.flags['quest-fire']&&!has({cord:1,tinder:1})){flash('Ohniště vyžaduje pevný provaz a suchý troud. Vyrob je v nabídce Výroba.');return;}if(stage===0&&site==='shelter'&&!state.flags['quest-shelter']&&!has({cord:1})){flash('Na první etapu přístřešku potřebuješ pevný provaz.');return;}let full={...BUILD[site].needs};if(state.skills.builder&&full.wood)full.wood=Math.max(1,full.wood-1);let needs={};for(let [k,v] of Object.entries(full)){let already=Math.floor(v*stage/3);let next=Math.floor(v*(stage+1)/3);if(next>already)needs[k]=next-already;}if(!has(needs)){flash('Chybí materiál: '+costs(needs));return}finishAction(o,'build',()=>{if(!spend(needs))return;if(stage===0&&site==='fire'&&!state.flags['quest-fire'])spend({cord:1,tinder:1});if(stage===0&&site==='shelter'&&!state.flags['quest-shelter'])spend({cord:1});state.built[site]=stage+1;if(state.built[site]===3){flash('✓ Dokončeno: '+BUILD[site].name);if(!state.flags['build-reward-'+site]){state.flags['build-reward-'+site]=true;awardXP(site==='signal'?65:55,'Stavba: '+BUILD[site].name);}if(site==='bridge'){state.flags.bridgeBuilt=true;writeStory('Přes roklinu vede pevná lávka. Vozík na druhé straně se dá bezpečně prozkoumat.')}if(site==='pier'){state.flags.pierBuilt=true;writeStory('Na jižním pobřeží stojí molo. Teď už zbývá připravit evakuační zásoby.')}if(site==='signal'){state.flags.signal=true;state.journal.push('Zprovoznil jsem signální stanoviště. Na horizontu se objevila slabá odpověď světlem.')}}else flash(BUILD[site].name+' · konstrukce '+(stage+1)+'/3');checkQuest();save(true)},1.6)}else if(site==='shelter'||site==='outpost')finishAction(o,'rest',()=>{state.clock+=3;if(state.clock>=24){state.clock-=24;state.day++;}state.energy=100;state.hp=clamp(state.hp+13,0,100);state.exposure=0;if(site==='shelter')state.flags.firstRest=true;checkQuest();flash('⛺ Robinson si odpočinul v bezpečí.');save(true)},1.1);else if(site==='filter')finishAction(o,'drink',()=>{if(state.flags.lastFilterDay===state.day){flash('Filtr bude mít další vodu až zítra.');return}state.flags.lastFilterDay=state.day;state.flags.filteredFirst=true;checkQuest();state.water=clamp(state.water+70,0,100);flash('💧 Filtrovaná voda doplnila zásoby.');save(true)},1.1);else if(site==='fire'){if(state.bag.fish){finishAction(o,'build',()=>{state.bag.fish--;state.food=clamp(state.food+52,0,100);state.flags.cookedFirstFish=true;checkQuest();flash('🔥 Ryba je upečená a snědená.');save(true)},1.1)}else flash('Oheň hoří. Přines rybu z rybářské tůně.')}else if(site==='pier'){if(currentQuest()?.id!=='evac'){flash('Molo je připravené. Zbývá výbava na cestu a správný čas příjezdu člunu.');return;}if(state.clock>=5&&state.clock<=9&&state.weather!=='storm'){flash('Záchranný člun může připlout právě teď. Aktivuj evakuační bod vedle mola.');return;}if(!state.bag.ration){flash('Na vyčkání u pobřeží si připrav expediční zásoby.');return;}finishAction(o,'rest',()=>{state.bag.ration--;state.day+=state.clock>=9?1:0;state.clock=6;state.energy=clamp(state.energy+18,0,100);state.food=clamp(state.food+12,0,100);state.water=clamp(state.water+12,0,100);flash('🌅 Přečkal jsi noc na molu. Je 06:00, vyšli světlici na evakuačním bodě.');writeStory('Na molu jsem spotřeboval expediční balíček a vyčkal na ranní příliv.');save(true);updateUI()},2.2);}else if(site==='beacon'){if(state.flags.beacon){flash('📡 Maják již odvysílal souřadnice.');return;}if(!state.bag.core||!state.bag.lens){flash('Chybí rádiové jádro nebo optická čočka z expedice.');return;}if(dayValue()<.42||state.weather==='storm'){flash('Maják lze aktivovat pouze za dne a bez bouře.');return;}finishAction(o,'build',()=>{state.bag.core--;state.bag.lens--;state.flags.beacon=true;writeStory('Nouzový maják odvysílal souřadnice. '+(state.story.fate==='mara'?'Ivo dál sleduje frekvenci.':'Mára hlídá pobřeží.')+' Ostrov už není bezejmenný.');awardXP(90,'Nouzové vysílání');checkQuest();save(true)},3.6);}else flash('📡 Signální stanoviště vysílá. Sleduj horizont.')}
}

function writeStory(entry){state.journal.push('Den '+state.day+': '+entry);state.journal=state.journal.slice(-100);changed=true}
function stealAtConversation(){if(state.story.lastTheftDay===state.day)return null;
 let id=['coconut','wood','fiber','scrap'].find(i=>(state.bag[i]||0)>0);
 if(!id)return null;state.bag[id]--;state.story.stolen[id]=(state.story.stolen[id]||0)+1;state.story.lastTheftDay=state.day;changed=true;return id;}
function voiceEvent(detail){window.dispatchEvent(new CustomEvent('trosecnik:voice',{detail}))} function showDialogue(name,text,detail){dialog={name,text,detail:detail||''};openPanel('dialogue')}
function talkToNPC(id){let story=state.story;if(id==='mara'||id==='ivo')voiceEvent({type:'interaction',id,metBefore:id==='mara'?story.metMara:story.metIvo,stolen:story.lastTheftDay===state.day,fate:story.fate});if(id==='jana'){if(!state.flags.metJana){state.flags.metJana=true;writeStory('Jana přežila havárii expedice a ví o staré radiostanici. K cestě ale potřebuje ošetřit.');showDialogue('Jana','„Jsem Jana, kartografka. Na severu je ztracený radiový archiv. Zůstala jsem pod vozíkem a šla bych dál, ale nedokážu chodit.“','Najdi léčivou bylinu a obvaz, potom se vrať.');}else if(!state.flags.janaHealed){if(!has({bandage:1,herb:1})){flash('Pro ošetření Jany potřebuješ jeden obvaz a jednu léčivou bylinu.');return;}if(!spend({bandage:1,herb:1}))return;state.flags.janaHealed=true;writeStory('Jana je ošetřená. Prozradila polohu mlžného archivu a způsob izolace mapy pryskyřicí.');showDialogue('Jana','„Děkuju. Severozápadně je schránka v mokřadu. Potřebuješ pouzdro proti vodě a pochodeň. A pozor na kance.“','Odemkl se recept na voděodolné pouzdro.');}else showDialogue('Jana',state.story.fate==='mara'?'„Ivo by si s tím vysílačem poradil, ale musíme mu dát čas. Klíč je v archivu.“':'„Mára umí dělat rychle, ale příště před ním schovej mapu. Klíč je v archivu.“','Jana čeká u stezky a sleduje postup výpravy.');changed=true;checkQuest();save(true);return;}if(id==='mara'){
 if(!story.metMara){story.metMara=true;let stolen=stealAtConversation();writeStory('Potkal jsem Máru. Pracuje rychle a sprostě nadává, ale při rozhovoru mi zmizel '+(stolen?ITEM[stolen][1].toLowerCase():'kus vybavení z radiostanice')+'.');showDialogue('Mára','„Kurva, konečně někdo normální! Dřevo ti nanosím dřív, než Ivo vůbec zvedne prdel. A ne, vole, nic jsem ti nevzal.“','Mára přinesl dřevo v rekordním čase. Při kontrole batohu ale chybí jedna věc.');}
 else{let stolen=stealAtConversation();showDialogue('Mára',story.fate==='ivo'?'„Do prdele, dej mi ten kabel. Opravu mám za chvíli, ty vole. Co je moje, to je tvoje… teda obráceně.“':'„Zas nějaký kecy? Kurva, já dělám za dva a všichni mě obviňujou. Já jsem nic nevzal, vole.“',stolen?'Při rozhovoru Mára schoval do kapsy '+ITEM[stolen][1].toLowerCase()+'. Úkryt u vraku může prozradit, kam své nálezy nosí.':'Mára neustále přechází po táboře a přenáší materiál.');}}
 else{if(!story.metIvo){story.metIvo=true;writeStory('Potkal jsem Iva. Je zručný radista, ale každý úkon mu trvá dlouho a občas mluví nesmysly.');showDialogue('Ivo','„Já… ehm… zachytil jsem signál. Nebo to byla asi lednice, co volala na maják? Počkej, musím to znovu proměřit.“','Ivo si dlouho připravuje vybavení, ale umí vysvětlit, proč je vysílačka poškozená.');}else showDialogue('Ivo','„Ještě chvilku. Nejdřív zkontroluju konektor… A víš, že kokos může mít tajnou anténu? Ne, to jsem si asi spletl.“',story.fate==='mara'?'Ivo je teď jediný, kdo může rádio opravit. Potřebuje připravené díly a čas.':'Na potvrzení měření budeš muset chvíli počkat.');}
 changed=true;checkQuest();save(true);}
function visitStash(){let st=state.story;if(!st.evidence){voiceEvent({type:'interaction',id:'stash'});st.evidence=true;writeStory('V úkrytu u vraku leží zásoby, které Mára popíral, a zápisky o poruše rádia.');for(let [id,n] of Object.entries(st.stolen)){if(n>0){add(id,n);st.stolen[id]=0}}add('scrap',1);showDialogue('Tajný úkryt','Pod ztrouchnivělým prknem leží ukradené zásoby a rozebraný rádiový modul. Mára zapíral. Ivo si mezitím zapsal skutečnou příčinu poruchy.','Získal jsi své věci zpět a kovovou součástku. V táboře se blíží bouře.');}
 else if(st.fate==='ivo'&&st.radioStolen&&!st.restored){voiceEvent({type:'interaction',id:'restored'});st.radioStolen=false;st.restored=true;add('scrap',1);writeStory('Mára mi po Ivově smrti ukradl důležitý díl vysílačky. Našel jsem ho v jeho úkrytu.');showDialogue('Znovu vykradený úkryt','Uvnitř je ukrytý díl, bez kterého se vysílačka nerozběhne. Mára tvrdil, že ho ztratil vítr.','Součástka je zpět v batohu. Mára slíbil opravu dokončit rychle.');}
 else{let n=0;for(let [id,v] of Object.entries(st.stolen)){if(v>0){add(id,v);n+=v;st.stolen[id]=0}}if(n)flash('Vrácené zásoby: '+n+' kusů.');else flash('Úkryt je prázdný.');}
 changed=true;checkQuest();save(true);}
function chooseFate(id){if(!['mara','ivo'].includes(id)||state.story.fate||!state.story.evidence||!state.story.metMara||!state.story.metIvo)return;
 const killed=id==='mara'?'Máru':'Iva',survivor=id==='mara'?'Ivo':'Mára';state.story.fate=id;state.story.radioStolen=id==='ivo';state.story.restored=false;state.weather='storm';state.story.stormUntil=state.seconds+45;state.clock=Math.max(18,state.clock);writeStory('Během bouře jsem při střetu u vysílačky zabil '+killed+'. '+survivor+' zůstal naživu. Moje rozhodnutí už nejde vrátit.');
 if(id==='mara'){state.built.shelter=Math.min(2,state.built.shelter);state.hp=clamp(state.hp-13,1,100);}else{state.bag.wood=Math.max(0,(state.bag.wood||0)-1);}
 changed=true;checkQuest();save(true);closePanel();voiceEvent({type:'fate-choice',killed:id});$('storyCurtain').classList.add('visible');$('storyCurtain').setAttribute('aria-hidden','false');$('storyCurtain').querySelector('b').textContent='Někdo se už nevrátí';$('storyCurtain').querySelector('p').textContent='Robinson zabil '+killed+'. '+(id==='mara'?'Ivo zůstal, ale oprava bude pomalá a přístřešek je poškozený.':'Mára zůstal, ale z vysílačky zmizel klíčový díl.');
 setTimeout(()=>{$('storyCurtain').classList.remove('visible');$('storyCurtain').setAttribute('aria-hidden','true');if(started)openPanel('aftermath');},2100);}
function repairRelay(o){if(!state.story.fate)return;let st=state.story;
 if(!st.repaired){if(st.fate==='ivo'&&!st.restored){flash('Mára ukradl rádiový díl. Najdi ho znovu v úkrytu u vraku.');return}
 const cost=st.fate==='mara'?{wood:2,fiber:1,scrap:1}:{wood:1,fiber:1,scrap:1};if(!has(cost)){flash('Pro opravu potřebuješ: '+costs(cost));return}
 finishAction(o,'build',()=>{if(!spend(cost))return;st.repaired=true;writeStory(st.fate==='mara'?'Ivo opravoval rádio dlouho, ale spoje nakonec drží.':'Mára opravil rádio rychle, přesto si během práce odložil cizí zásoby do kapsy.');if(st.fate==='ivo')stealAtConversation();flash('📻 Rádio je opravené.');checkQuest();save(true);},st.fate==='mara'?3.8:1.40);return}
 if(!st.finalSignal)finishAction(o,'build',()=>{st.finalSignal=true;st.ending=st.fate==='mara'?'ivo':'mara';writeStory(st.fate==='mara'?'S Ivem jsme vyslali pozdní, ale přesný signál. Tábor bude nutné znovu opravit.':'S Márou jsme vyslali zprávu rychle. Jeho krádeže však dál ohrožují naši důvěru i společné zásoby.');awardXP(90,'Poslední vysílání');checkQuest();save(true);openPanel('ending');},1.90);
 else openPanel('ending');}

function actionPress(){if(pane||mini){return}let o=nearbyObject();if(!o){flash('Přibliž se k předmětu nebo na něj klepni přímo ve scéně.');return}interactObject(o)}
function flash(message){if(!message)return;$('notice').textContent=message;$('notice').classList.add('show');toastAt=now()+2700;}
function openPanel(name){if(!name)return;pane=name;mini=null;autogoal=null;$('panel').classList.add('open');$('panel').setAttribute('aria-hidden','false');renderPane();if(name==='fate')voiceEvent({type:'fate'});if(name==='ending')voiceEvent({type:'ending',fate:state.story.fate});}
function closePanel(){if(mini)return;if(pane==='dialogue')voiceEvent({type:'close-dialogue'});pane='';$('panel').classList.remove('open');$('panel').setAttribute('aria-hidden','true');updateUI()}
const escapeHtml=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function paneCard(t,title,body,button='',id='',disabled=false){return '<div class="entry"><div><b>'+t+' '+escapeHtml(title)+'</b><p>'+body+'</p></div>'+(button?'<button data-action="'+id+'" '+(disabled?'disabled':'')+'>'+button+'</button>':'')+'</div>'}
function renderPaneIfOpen(){if(pane)renderPane()}
function formatPlayTime(seconds){const n=Math.max(0,Math.round(Number(seconds)||0));return Math.floor(n/3600)+' h '+String(Math.floor(n%3600/60)).padStart(2,'0')+' min';}
function renderPane(){let html='',title='';let quest=currentQuest();if(pane==='bag'){title='Batoh';html='<p class="paneLead">Suroviny a vybavení, které Robinson právě nese. Jídlo lze sníst přímo zde.</p><div class="items">';for(let [id,v] of Object.entries(ITEM)){let n=state.bag[id]||0;if(!n)continue;html+='<div class="tile"><span class="emoji">'+v[0]+'</span><b>'+escapeHtml(v[1])+'</b><small>× '+n+'</small></div>'}html+='</div><hr class="divider">'+paneCard('🥥','Sníst kokos','Doplní hlad a trochu žízně.','Sníst','eat',!state.bag.coconut);if(state.bag.ration)html+=paneCard('🎒','Sníst expediční balíček','Doplní hlad a vodu během výpravy.','Použít','eatRation');if(state.bag.herb)html+=paneCard('🌱','Léčivá bylina','Ošetři zranění a trochu sniž vyčerpání.','Použít','useHerb');}
else if(pane==='craft'){title='Výroba a stavění';html='<p class="paneLead">Recepty odemyká průzkum. Každou surovinu musíš najít a zpracovat. Větší stavby se budují po třech pracovních etapách.</p>';
for(const rc of RECIPES){if(!rc.visible(state))continue;const can=has(rc.cost)&&(!rc.once||!state.flags[rc.flag]);html+=paneCard(rc.icon,rc.name,rc.desc+'<br><span class="noticeText">'+costs(rc.cost)+'</span>',rc.once&&state.flags[rc.flag]?'Hotovo':can?'Vyrobit':'Chybí','recipe-'+rc.id,!can);}if(state.bag.bandage)html+=paneCard('🩹','Použít obvaz','Obnoví 26 bodů zdraví.','Ošetřit','heal',state.hp>=100);html+='<hr class="divider"><div class="micro">TÁBOR</div>';for(let [id,b]of Object.entries(BUILD))html+=paneCard('🏗',b.name,b.description+'<br><span class="noticeText">Postup '+(state.built[id]||0)+'/3 · '+costs(b.needs)+'</span>');}
else if(pane==='journal'){title='Úkoly a deník';html='<p class="paneLead">Kapitola I: První dny a zasloužený tábor. II: Hlasy ostrova. III: Divočina a maják. IV: Ztracená expedice a dlouhá cesta domů. Každý splněný úkol přidá XP pouze jednou.</p><p class="paneLead"><b>⏱ Skutečný čas hraní:</b> '+formatPlayTime(state.playMetrics.activeSeconds)+'. Měří se jen při aktivním hraní, nikoliv v menu nebo na neaktivní kartě. Celých 20 hodin je cílem vývoje, nikoliv aktuální dosaženou délkou hry.</p>';for(let q of QUESTS){if(q.active&&!q.active(state))continue;let done=!!state.flags['quest-'+q.id];html+='<div class="entry '+(done?'done':'')+'"><div><b>'+(done?'✓':'◇')+' '+q.name+'</b><p>'+q.desc+'<br><span class="noticeText">+'+q.xp+' XP'+(done?' · čas úkolu '+formatPlayTime(state.playMetrics.questSeconds[q.id]||0):'')+'</span></p></div><span class="micro">'+(done?'HOTOVO':q===quest?'AKTIVNÍ':'ČEKÁ')+'</span></div>'}html+='<hr class="divider"><div class="micro">ROBINSONŮV DENÍK</div>'+state.journal.slice(-24).reverse().map(x=>'<p class="paneLead">'+escapeHtml(x)+'</p>').join('');}
else if(pane==='skills'){title='Dovednosti';html='<p class="paneLead">Úroveň '+state.level+' · Nevyužité body: <b>'+state.points+'</b>. Každý nový level dá jeden bod. Schopnosti mají konkrétní vliv na pohyb, sběr a přežití.</p>';for(let s of SKILLS){let learned=!!state.skills[s.id];html+=paneCard(s.icon,s.name,s.desc+'<br><span class="noticeText">Od úrovně '+s.min+(learned?' · Naučeno':'')+'</span>',learned?'Získáno':'Naučit','skill-'+s.id,learned||state.points<1||state.level<s.min)}}
else if(pane==='map'){title='Mapa výpravy';html='<p class="paneLead">Od pláže přes mangrovy a horský hřeben až do mlžného lesa, k východní radiostanici a jižnímu evakuačnímu molu. Nová místa odemykají kapitoly a získané mapy. ⚠ Na stezkách hrozí divočáci. Suroviny u tábora mají omezenou zásobu: každé původní naleziště lze sebrat celkem třikrát a znovu jej vytěžíš nejdříve po třech minutách aktivní hry. Po vyčerpání se neobnoví. Dřevo, kamení a vlákna v dalších oblastech ostrova se obnovují pomaleji, ale zůstávají dostupné.</p><div class="mapBox">';let dots=[[-1,-12,'Pláž'],[-4,-2,'Tábor'],[-14,7.7,'Pramen'],[14.4,-11.3,'Esperanza'],[-51,13,'Mangrovy'],[8,49,'Hřeben'],[51,14,'Jeskyně'],[19,-49,'Laguna'],[hero.x,hero.z,'● TY']];if(state.flags.signal){for(let id of ['mara','ivo'])if(objectAvailable(NPCS[id]))dots.push([NPCS[id].x,NPCS[id].z,id==='mara'?'Mára':'Ivo']);dots.push([10.7,-8.6,'Úkryt']);}let tgt=OBJ.find(o=>o.id===quest?.target);if(tgt)dots.push([tgt.x,tgt.z,'◇ CÍL']);for(let [x,z,n] of dots)html+='<div class="mapDot '+(n.includes('TY')?'you':'')+'" style="left:'+clamp(50+x*.58,2,98)+'%;top:'+clamp(50-z*.63,2,98)+'%">'+escapeHtml(n)+'</div>';html+='</div><p class="noticeText">🌊 Jeskyně: '+(lowTide()?'ODLIV · vchod je volný':'PŘÍLIV · vchod je uzavřený')+' · '+(dayValue()>=.4?'denní světlo':'za tmy průzkum není bezpečný')+'.</p><p class="noticeText">⚠ Před výpravou připrav kopí, jídlo a obvaz. V horách při dešti i v noci hrozí prochladnutí. Večer se vrať do přístřešku.</p>'}
else if(pane==='menu'){title='Hra a nastavení';html='<p class="paneLead">Verze 2.4 má čtyři kapitoly a nový postupný začátek. Uložené pozice 2.2 a 2.3 se převedou, staré kapitoly zůstávají dokončené. Pozice z verze 0.9 mají jiný formát.</p><div class="choiceRow"><button class="uiBtn" data-action="unstuck">↩ Odblokovat Robinsona · návrat na bezpečné místo</button></div><div class="micro">UKLÁDACÍ POZICE</div><div class="choiceRow">';for(let i=1;i<=3;i++)html+='<button class="uiBtn" data-action="slot-'+i+'" '+(slot===i?'style="background:#b19456;color:#101914"':'')+'>Pozice '+i+'</button>';html+='</div><div class="choiceRow"><button class="uiBtn" data-action="people">🧍 Postavy ostrova · vztahy a následky</button></div><p class="noticeText">Výběr jiné pozice automaticky ukládá současnou a načítá zvolenou.</p><hr class="divider"><div class="choiceRow"><button class="uiBtn" data-action="save">Uložit</button><button class="uiBtn" data-action="export">Export zálohy</button><button class="uiBtn" data-action="import">Import zálohy</button></div><p class="noticeText">Chceš zažít delší úvod od začátku? Nejdřív exportuj zálohu; nová hra přepíše jen aktuálně vybranou pozici.</p><div class="choiceRow"><button class="uiBtn" data-action="newgame">Nová hra v této pozici</button></div><hr class="divider"><div class="micro">GRAFIKA</div><div class="choiceRow">';for(let q of ['low','auto','high'])html+='<button class="uiBtn" data-action="quality-'+q+'" '+(settings.quality===q?'style="background:#b19456;color:#101914"':'')+'>'+({low:'Úsporná',auto:'Automatická',high:'Vyšší'}[q])+'</button>';html+='</div><p class="noticeText">Kamera: tažením po scéně měníš směr. Tlačítko POHLED přepíná kameru přes rameno.</p><div class="choiceRow"><button class="uiBtn" data-action="sound">Zvuk: '+(settings.sound?'zapnutý':'vypnutý')+'</button><button class="uiBtn" data-action="resetCamera">Vrátit kameru</button></div>';}
else if(pane==='people'){title='Postavy ostrova';html='<p class="paneLead">Po zapálení signálního stanoviště se u tábora a pramene objeví další trosečníci. Jejich činy mají trvalé následky.</p>';
 html+=paneCard('🪓','Mára · rychlý pracant','Rychle nosí materiál a opravuje vybavení, ale lže, krade zásoby a mluví hodně sprostě. '+(state.story.metMara?'Setkal ses s ním.':'Dosud jste se nepotkali.')+(state.story.fate==='mara'?'<br><b>Mára zemřel.</b>':''));
 html+=paneCard('📻','Ivo · pomalý radista','Opravám rozumí, ale všechno mu trvá a občas pronáší úplné nesmysly. '+(state.story.metIvo?'Setkal ses s ním.':'Dosud jste se nepotkali.')+(state.story.fate==='ivo'?'<br><b>Ivo zemřel.</b>':''));
 if(state.story.fate)html+='<hr class="divider"><p class="paneLead">Rozhodnutí: Robinson zabil '+(state.story.fate==='mara'?'Máru':'Iva')+'. Naživu zůstal '+(state.story.fate==='mara'?'Ivo':'Mára')+'. Další vysílání i osud tábora závisí na této volbě.</p>';}
else if(pane==='dialogue'){title=dialog?.name||'Rozhovor';html='<div class="storyText">'+escapeHtml(dialog?.text||'')+'</div><p class="paneLead">'+escapeHtml(dialog?.detail||'')+'</p><div class="choiceRow"><button class="uiBtn" data-action="continueStory">Pokračovat →</button></div>';}
else if(pane==='fate'){title='Osudové rozhodnutí';html='<p class="paneLead">Bouře poškodila vysílačku. Mára a Ivo se kvůli zmizelým součástkám obrátili proti sobě. Robinson je v ozbrojeném střetu a musí rozhodnout, koho zabije. Rozhodnutí je nevratné a bude uloženo do této rozehrané hry.</p><div class="fateChoices">'+paneCard('🪓','Zabít Máru','Ivo přežije. Oprava bude pomalá a bouře poškodí přístřešek. Krádeže ustanou.','ZABÍT MÁRU','choose-mara')+paneCard('📻','Zabít Iva','Mára přežije a opraví rádio rychle, ale ukradne klíčový díl. Budeš ho muset znovu najít.','ZABÍT IVA','choose-ivo')+'</div><p class="noticeText">Můžeš nabídku zavřít a před rozhodnutím uložit hru, v příběhu však bez této volby nepokročíš.</p>';}
else if(pane==='aftermath'){title='Po bouři';html='<div class="storyText">'+(state.story.fate==='mara'?'Mára zemřel. Ivo se třesoucíma rukama pustil do opravy. „Půjde to… jen mi dej čas. Mimochodem, myslíš, že rádio poslouchá stromy?“':'Ivo zemřel. Mára se už hrabe ve vysílačce. „Do prdele, hotovo to bude hned. Ale… ten kovovej díl jsem nikde neviděl, vole.“')+'</div><p class="paneLead">'+(state.story.fate==='mara'?'Připrav dřevo, vlákno a kovový díl. Oprav poškozený přístřešek.':'Vrať se ke skrytému úkrytu u vraku pro ukradený rádiový díl.')+'</p><div class="choiceRow"><button class="uiBtn" data-action="continueStory">Pokračovat ve výpravě →</button></div>';}
else if(pane==='ending'){title='Poslední signál';html='<div class="storyText">'+(state.story.ending==='ivo'?'Signál odešel pozdě, ale Ivo nakonec doladil frekvenci. Na obzoru se objevilo vzdálené světlo. V táboře zůstává poškozený přístřešek a ticho po Márovi. Robinson musí znovu připravit zásoby.':'Mára opravil vysílačku rychle. Z moře přišla odpověď a nad hladinou se objevila světla. Robinson ale zjistil, že Mára si opět schoval zásoby. Záchrana je blízko, důvěra se nevrátila.')+'</div><p class="paneLead">Tvoje volba rozhodla o tom, kdo přežil, jak dlouho oprava trvala a co zbylo v táboře. Další část ostrova můžeš dál prozkoumávat.</p><div class="choiceRow"><button class="uiBtn" data-action="continueStory">Zpět do hry →</button></div>';}
else if(pane==='cipher'){title='Šifra z Esperanzy';html='<p class="paneLead">Slož kód ze tří nalezených stop. Ve vraku byla první číslice, v mokřadu druhá a ve stanici třetí. Chybný pokus unaví Robinsona.</p><div class="choiceRow"><button class="uiBtn" data-action="cipher-314">3 - 1 - 4</button><button class="uiBtn" data-action="cipher-341">3 - 4 - 1</button><button class="uiBtn" data-action="cipher-413">4 - 1 - 3</button></div>'; }
else if(pane==='epilogue'){title='Konec výpravy · nová naděje';html='<div class="storyText">'+escapeHtml(state.story.fate==='mara'?'S Ivem a Janou jsem odplul od ostrova. Mára se nevrátí. Nalezený archiv vysvětluje, proč předchozí expedice zmizela.':'S Márou a Janou jsme se dostali k záchrannému člunu. Ivo se nevrátí. Mára slíbil, že se přestane vymlouvat, ale o jeho dalších krocích rozhodne až pevnina.')+'</div><p class="paneLead">Ostrov zůstává přístupný k dalšímu průzkumu. Můžeš pokračovat nebo načíst jinou pozici.</p><div class="choiceRow"><button class="uiBtn" data-action="continueStory">Pokračovat →</button></div>';}
else if(pane==='mini'){title='Rybářská minihra';let value=fishNeedlePercent(mini.t);mini.displayedPercent=value;html='<p class="paneLead">Klepni na ZASÁHNOUT, když se plovák ocitne v zelené oblasti. Potřebuješ 3 úspěšné zásahy.</p><div style="height:26px;border:1px solid #d1c797;border-radius:10px;position:relative;background:linear-gradient(90deg,#573c2a 0 '+FISH_GREEN_START+'%,#639b6b '+FISH_GREEN_START+'% '+FISH_GREEN_END+'%,#573c2a '+FISH_GREEN_END+'%);overflow:hidden"><i id="needle" style="position:absolute;left:'+value+'%;top:0;bottom:0;width:4px;background:#fff7e1"></i></div><p class="paneLead" id="miniScore">Zásahy: '+mini.hits+'/3 · Pokusy: '+mini.attempts+'/7</p><div class="choiceRow"><button class="uiBtn" data-action="miniHit">🎣 ZASÁHNOUT</button><button class="uiBtn" data-action="miniQuit">Odejít</button></div>'}
$('paneTitle').textContent=title;$('paneContent').innerHTML=html;}
function panelAction(action){if(!action)return;if(action.startsWith('cipher-')){if(action==='cipher-314'){state.flags.decoded=true;writeStory('Zápisky, plomba i stanice ukázaly kód 314. Terminál odemkl plán jižního evakuačního bodu.');checkQuest();save(true);closePanel();}else{state.energy=clamp(state.energy-9,0,100);flash('Špatný kód, -9 energie. Zkontroluj stopy v deníku.');save(true);renderPane();}return;}if(action==='unstuck'){unstuckHero();return}if(action==='eat'){consumeFood();return}if(action==='eatRation'){if(state.bag.ration){state.bag.ration--;state.food=clamp(state.food+48,0,100);state.water=clamp(state.water+28,0,100);flash('🎒 Expediční zásoby doplněny.');changed=true;save(true);renderPane();}return}if(action==='useHerb'){if(state.bag.herb){state.bag.herb--;state.hp=clamp(state.hp+19,0,100);state.exposure=clamp(state.exposure-24,0,100);flash('🌱 Ošetřil sis zranění.');changed=true;save(true);renderPane();}return}if(action.startsWith('recipe-')){makeRecipe(action.slice(7));return}if(action==='people'){pane='people';renderPane();return}if(action==='continueStory'){closePanel();return}if(action==='choose-mara'||action==='choose-ivo'){chooseFate(action.slice(7));return}if(action.startsWith('skill-')){let id=action.slice(6),s=SKILLS.find(x=>x.id===id);if(!s||state.skills[id]||state.points<1||state.level<s.min)return;state.skills[id]=true;state.points--;flash('✦ Naučeno: '+s.name);save(true);renderPane();return}

if(action==='heal'){if(state.bag.bandage>0){state.bag.bandage--;state.hp=clamp(state.hp+26,0,100);flash('🩹 Obvaz obnovil zdraví.');save(true);renderPane()}return}
if(action.startsWith('slot-')){let n=Number(action.slice(5));save(true);load(n);flash('Načtena pozice '+n);renderPane();return}
if(action==='newgame'){if(!window.confirm('Začít novou výpravu v pozici '+slot+'? Současný postup v této pozici bude nahrazen. Před pokračováním si případně exportuj zálohu.'))return;state=copy(BASE);pending=null;mini=null;autogoal=null;dialog=null;started=true;syncPlayer();changed=true;save(true);closePanel();updateUI();voiceEvent({type:'new-game'});flash('🏝️ Nová výprava. Začni u vyplavené bedny na pobřeží.');return}if(action==='save'){save(true);flash('Hra uložena do pozice '+slot);return}
if(action==='export'){save(true);let blob=new Blob([JSON.stringify({game:'TROSECNIK_3D_2_0',slot,state},null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='trosecnik_3d_2_0_pozice_'+slot+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),2500);flash('Záloha připravena ke stažení.');return}
if(action==='import'){$('importFile').click();return}
if(action.startsWith('quality-')){settings.quality=action.slice(8);localStorage.setItem(SETTINGS,JSON.stringify(settings));renderPane();return}
if(action==='sound'){settings.sound=!settings.sound;voiceEvent({type:'master-sound',on:settings.sound});if(settings.sound)startSound();if(ambientGain)ambientGain.gain.value=settings.sound?.024:0;localStorage.setItem(SETTINGS,JSON.stringify(settings));renderPane();return}
if(action==='resetCamera'){cameraYaw=hero.yaw+Math.PI;cameraPitch=.32;wideDistance=7.4;shoulder=false;renderPane();return}
if(action==='miniQuit'){mini=null;pane='';$('panel').classList.remove('open');$('panel').setAttribute('aria-hidden','true');return}
if(action==='miniHit'){if(!mini)return;mini.attempts++;let hit=fishNeedleHitsGreen(mini.displayedPercent);if(hit)mini.hits++;if(mini.hits>=3||mini.attempts>=7){let won=mini.hits>=3,daykey='fish-'+state.day;state.miniAttempts[daykey]=state.miniAttempts[daykey]||0;if(won){const fishSource=OBJ.find(o=>o.id===mini.sourceId);if(fishSource)recordGather(fishSource,state.flags,state.seconds);add('fish',state.skills.fisher?2:1);state.flags.caughtFirstFish=true;checkQuest();if(state.miniAttempts[daykey]<3){awardXP(28,'Rybaření');state.miniAttempts[daykey]++}else flash('Ryba chycena. Denní limit XP je vyčerpán.')}else flash('Ryba unikla. Zkus to znovu.');mini=null;pane='';$('panel').classList.remove('open');$('panel').setAttribute('aria-hidden','true');save(true);updateUI()}else renderPane();return}}
function updateUI(){if(!state)return;for(let [id,amount] of [['hp',state.hp],['food',state.food],['water',state.water],['energy',state.energy]]){$(id+'Num').textContent=Math.round(amount);$(id+'Bar').style.width=clamp(amount,0,100)+'%'}$('levelText').textContent='LVL '+state.level;$('xpText').textContent=state.xp+' / '+needXP(state.level)+' XP';$('xpFill').style.width=clamp(state.xp/needXP(state.level)*100,0,100)+'%';let q=currentQuest();$('taskName').textContent=q?.name||'Výprava je dokončená';$('taskDesc').textContent=q?.desc||'Evakuační signál byl vyslán. Můžeš pokračovat v průzkumu ostrova nebo zahájit novou hru v jiné pozici.';const qi=q?QUESTS.indexOf(q):QUESTS.length;const chapter=qi<QUESTS.findIndex(t=>t.id==='mara')?'I · PRVNÍ DNY':qi<QUESTS.findIndex(t=>t.id==='coastSurvey')?'II · HLASY':qi<QUESTS.findIndex(t=>t.id==='packet')?'III · DIVOČINA':'IV · ZTRACENÁ EXPEDICE';$('questProgress').textContent='KAPITOLA '+chapter+' · ÚKOL '+(q?qi+1:QUESTS.length)+' / '+QUESTS.length;let target=currentQuestTarget();$('objectiveMarker').style.display=target?'':'none';if(target)$('objectiveDist').textContent=target.name+' · '+Math.round(d2(hero,target))+' m';let z=hero.z,x=hero.x;if(state.exposure>45)$('location').title='Prochladnutí '+Math.round(state.exposure)+'/100 · dojdi do přístřešku';else $('location').title='';$('location').textContent=x<-35&&z>0&&z<30?'MANGROVY':z>36?'SEVERNÍ HŘEBEN':x>36&&z>0?'VÝCHODNÍ JESKYNĚ':z<-36&&x>0?'JIŽNÍ LAGUNA':x>9&&z<-4?'VRAK ESPERANZY':x<-10&&z>4?'PRAMEN':Math.hypot(x+4,z)<7?'TÁBOR':z>4?'DŽUNGLE':'PLÁŽ';if(state.exposure>45)$('location').textContent+=' · ❄ '+Math.round(state.exposure);const nearbyBoar=OBJ.some(e=>e.type==='boar'&&!(state.wild?.scared?.[e.id]>state.seconds)&&Math.hypot(e.x-hero.x,e.z-hero.z)<5.2);$('survivalAlert').textContent=nearbyBoar?'🐗 NEBEZPEČÍ':state.exposure>45?'❄ '+Math.round(state.exposure)+' %':'';let o=nearbyObject();visibleObj=o;$('target').classList.toggle('visible',!!o&&!pane);if(o){$('targetName').textContent=o.name;$('targetHint').textContent=o.type==='site'&&state.built[o.site]===3?'Použít dokončenou stavbu':'Stiskni AKCE nebo E'}$('actionLabel').textContent=o?(o.type==='site'?'STAVĚT / POUŽÍT':o.type==='spring'?'PÍT':o.type==='wreck'?'PROZKOUMAT':o.type==='fish'?'RYBAŘIT':'AKCE'):'AKCE';}
// Ray through camera using inverse combined projection-view. Hit tested against object spheres and terrain.
function rayFromScreen(px,py){let nx=px/$('world').clientWidth*2-1,ny=1-py/$('world').clientHeight*2,a=Mv(inverseVP,[nx,ny,-1,1]),b=Mv(inverseVP,[nx,ny,1,1]);let near=a.map(v=>v/a[3]).slice(0,3),far=b.map(v=>v/b[3]).slice(0,3);return{near,dir:normalize(minus(far,near))}}
function pickObject(px,py){let {near,dir}=rayFromScreen(px,py),best=null,bd=1e9;for(let o of OBJ){if(!objectAvailable(o))continue;let r=Math.max(.75,o.r),cen=[o.x,H(o.x,o.z)+.55,o.z],v=minus(cen,near),pr=dot(v,dir),d2=dot(v,v)-pr*pr;if(pr>0&&d2<r*r&&pr<bd){best=o;bd=pr}}return best}
function aimAt(x,z){autogoal={x,z,r:.2};hero.target=null}
function rayGround(px,py){let {near,dir}=rayFromScreen(px,py),prev=null;for(let t=.3;t<65;t+=.43){let p=[near[0]+dir[0]*t,near[1]+dir[1]*t,near[2]+dir[2]*t];if(p[1]<=H(p[0],p[2])+.08)return{x:p[0],z:p[2]};prev=p}return null}
function bindInput(){document.addEventListener('keydown',e=>{if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(e.key))e.preventDefault();keys.add(e.key.toLowerCase());keys.add(e.key);if(!e.repeat){if(e.key.toLowerCase()==='e')actionPress();if(e.key.toLowerCase()==='v')switchCamera();if(e.key.toLowerCase()==='u'&&!e.ctrlKey&&!e.metaKey&&!e.altKey){e.preventDefault();unstuckHero();}if(e.key==='Escape')closePanel();if(e.key==='Shift')running=true}});document.addEventListener('keyup',e=>{keys.delete(e.key.toLowerCase());keys.delete(e.key);if(e.key==='Shift')running=false});window.addEventListener('blur',()=>{keys.clear();running=false;joy.x=0;joy.y=0;$('stick').style.transform='translate(0,0)'});
$('action').addEventListener('click',actionPress);$('unstuckBtn').addEventListener('click',unstuckHero);$('run').addEventListener('pointerdown',e=>{e.preventDefault();running=true;$('run').classList.add('pressed');try{$('run').setPointerCapture(e.pointerId)}catch{}});for(let ev of ['pointerup','pointercancel','lostpointercapture'])$('run').addEventListener(ev,()=>{running=false;$('run').classList.remove('pressed')});$('cameraBtn').addEventListener('click',switchCamera);$('menuBtn').addEventListener('click',()=>openPanel('menu'));document.querySelectorAll('#dock button').forEach(b=>b.addEventListener('click',()=>openPanel(b.dataset.pane)));$('closePanel').addEventListener('click',()=>{if(mini){panelAction('miniQuit')}else closePanel()});// Touch/click release can occur long after the marker was visibly in the green area.
// Evaluate on pointer DOWN; keyboard/screen-reader activation still uses click(detail=0).
$('panel').addEventListener('pointerdown',e=>{if(e.button!==0)return;let b=e.target.closest('button[data-action="miniHit"]');if(b&&!b.disabled&&mini){e.preventDefault();panelAction('miniHit')}});
$('panel').addEventListener('click',e=>{if(e.target.id==='panel'&&!mini)closePanel();let b=e.target.closest('button[data-action]');if(b&&!b.disabled){if(b.dataset.action==='miniHit'&&e.detail!==0)return;panelAction(b.dataset.action)}});
let stick=$('stick'),base=$('joy'),joyPointer=null;function moveStick(e){let box=base.getBoundingClientRect(),cx=box.left+box.width/2,cy=box.top+box.height/2,vx=e.clientX-cx,vy=e.clientY-cy,dd=Math.max(1,Math.hypot(vx,vy)),r=Math.min(1,dd/(box.width*.34));joy.x=vx/dd*r;joy.y=vy/dd*r;stick.style.transform='translate('+joy.x*35+'px,'+joy.y*35+'px)'}base.addEventListener('pointerdown',e=>{e.preventDefault();joyPointer=e.pointerId;base.setPointerCapture(e.pointerId);moveStick(e)});base.addEventListener('pointermove',e=>{if(e.pointerId===joyPointer)moveStick(e)});for(let ev of ['pointerup','pointercancel','lostpointercapture'])base.addEventListener(ev,e=>{if(joyPointer===e.pointerId){joyPointer=null;joy.x=joy.y=0;stick.style.transform='translate(0,0)'}});
let canvas=$('world');canvas.addEventListener('contextmenu',e=>e.preventDefault());canvas.addEventListener('pointerdown',e=>{if(!started||pane)return;canvas.setPointerCapture(e.pointerId);touches.set(e.pointerId,{x:e.clientX,y:e.clientY,prevX:e.clientX,prevY:e.clientY,startX:e.clientX,startY:e.clientY,t:now(),moved:false});if(touches.size===2){for(let touch of touches.values())touch.moved=true;let a=[...touches.values()];pinchPrevious=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y)}});canvas.addEventListener('pointermove',e=>{let p=touches.get(e.pointerId);if(!p||pane)return;let dx=e.clientX-p.prevX,dy=e.clientY-p.prevY;p.x=e.clientX;p.y=e.clientY;p.prevX=e.clientX;p.prevY=e.clientY;if(Math.hypot(p.x-p.startX,p.y-p.startY)>7||Math.abs(dx)+Math.abs(dy)>3)p.moved=true;if(touches.size>=2){let a=[...touches.values()],d=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);if(pinchPrevious)wideDistance=clamp(wideDistance+(pinchPrevious-d)*.014,4.7,11);pinchPrevious=d;return}if(Math.abs(dx)+Math.abs(dy)>0){cameraYaw-=dx*.0041*settings.sensitivity;cameraPitch=clamp(cameraPitch+dy*.0034*settings.sensitivity,-.05,1.05)}});canvas.addEventListener('pointerup',e=>{let p=touches.get(e.pointerId);touches.delete(e.pointerId);if(touches.size<2)pinchPrevious=0;if(!p||pane||!started)return;if(p.moved||now()-p.t>300)return;let r=canvas.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top,o=pickObject(x,y);if(o){hero.target=o;interactObject(o);updateUI()}else{let g=rayGround(x,y);if(g&&passable(g.x,g.z))aimAt(g.x,g.z)}});canvas.addEventListener('pointercancel',e=>{touches.delete(e.pointerId);if(touches.size<2)pinchPrevious=0});
$('start').addEventListener('click',()=>{started=true;$('intro').style.display='none';voiceEvent({type:'started',fresh:currentQuest()?.id==='crate'});flash('🏝️ '+(currentQuest()?.desc||'Příběh je dokončený. Pokračuj v průzkumu ostrova.'));if(settings.sound)startSound()});}
function switchCamera(){shoulder=!shoulder;cameraYaw=hero.yaw+Math.PI;cameraPitch=shoulder?.19:.35;flash(shoulder?'Kamera: přes rameno Robinsona':'Kamera: široký pohled')}
let audioCtx,noiseSource,ambientGain;function startSound(){try{if(!audioCtx){audioCtx=new (window.AudioContext||window.webkitAudioContext)();let buffer=audioCtx.createBuffer(1,audioCtx.sampleRate*2,audioCtx.sampleRate),data=buffer.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=(Math.random()*2-1)*(.28+.14*Math.sin(i/1222));let source=audioCtx.createBufferSource();source.buffer=buffer;source.loop=true;let filter=audioCtx.createBiquadFilter();filter.type='lowpass';filter.frequency.value=400;let gain=audioCtx.createGain();gain.gain.value=settings.sound?.024:0;ambientGain=gain;source.connect(filter);filter.connect(gain);gain.connect(audioCtx.destination);source.start();noiseSource=source}else audioCtx.resume()}catch(e){console.warn('Ambientní zvuk není dostupný',e)}}
function frame(time){try{if(!lastFrame)lastFrame=time;let dt=clamp((time-lastFrame)/1000,0,.055);lastFrame=time;elapsed=time/1000;if(started&&state&&!document.hidden&&(!pane||mini)){const m=state.playMetrics;m.activeSeconds+=dt;const q=QUESTS.find(x=>(!x.active||x.active(state))&&!state.flags['quest-'+x.id]);if(q)m.questSeconds[q.id]=(m.questSeconds[q.id]||0)+dt;const sec=Math.floor(m.activeSeconds);if(sec%5===0&&sec!==Math.floor(m.activeSeconds-dt))changed=true;}framerate=mix(framerate,1/Math.max(dt,.005),.035);if(mini&&!document.hidden){mini.t+=dt;let needle=$('needle');if(needle){mini.displayedPercent=fishNeedlePercent(mini.t);needle.style.left=mini.displayedPercent+'%'}}gameplay(dt);updateCamera(dt||.016);drawScene();if(toastAt&&now()>toastAt){$('notice').classList.remove('show');toastAt=0}if(started&&changed&&Math.floor(state.seconds)%5===0&&Math.floor(state.seconds)!==Math.floor(state.seconds-dt))save()}catch(e){console.error('Trosečník 2.0 render/tick',e);if(!$('fatal').hidden)return; $('fatal').hidden=false;$('fatal').querySelector('h2').textContent='Nepodařilo se vykreslit hru';$('fatal').querySelector('p').textContent=e.message;return}}
window.__trosecnikVoiceState=()=>({fate:state?.story?.fate||null,food:state?.food??100,water:state?.water??100,energy:state?.energy??100,clock:state?.clock??12,sound:settings.sound});window.addEventListener('trosecnik:voice-duck',e=>{if(ambientGain)ambientGain.gain.value=settings.sound?(e.detail?.active?.009:.024):0});function boot(){let inp=document.createElement('input');inp.type='file';inp.id='importFile';inp.accept='.json,application/json';inp.hidden=true;document.body.appendChild(inp);inp.addEventListener('change',async()=>{let file=inp.files?.[0];inp.value='';if(!file)return;try{let v=JSON.parse(await file.text());if(v.game!=='TROSECNIK_3D_2_0'||v.state?.version!==2||!v.state.bag||typeof v.state.x!=='number')throw Error('Jiná nebo poškozená záloha.');save(true);state={...copy(BASE),...v.state,bag:{...BASE.bag,...v.state.bag},built:{...BASE.built,...(v.state.built||{})},story:{...copy(BASE.story),...(v.state.story||{})},wild:{...copy(BASE.wild),...(v.state.wild||{}),scared:{...(v.state.wild?.scared||{})}},playMetrics:{...copy(BASE.playMetrics),...(v.state.playMetrics||{}),questSeconds:{...(v.state.playMetrics?.questSeconds||{})},completedAt:{...(v.state.playMetrics?.completedAt||{})}}};state.exposure=clamp(Number(state.exposure)||0,0,100);state.x=clamp(state.x,-78,78);state.z=clamp(state.z,-70,70);migrateOldSave(v.state);syncPlayer();changed=true;save(true);flash('Záloha byla načtena do pozice '+slot);renderPane()}catch(e){flash('Import selhal: '+e.message)}});load(1);cameraYaw=Math.PI;cameraPitch=.34;bindInput();updateUI();
// Original, locally bundled Robinson GLB: no ephemeral CDN asset URLs.
renderer.loadHero('assets/models/robinson.glb').then(ok=>{if(ok)flash('🧍 Nový Robinson: plynulý pohyb a animace.');});
// Asynchronous optional models must never delay startup or prevent the procedural fallback.
renderer.loadModels([
 {name:'palm',url:'assets/models/palm.glb',scale:1.0,yOffset:0},
 {name:'crate',url:'assets/models/crate.glb',scale:.6,yOffset:0},
 {name:'shelter',url:'assets/models/shelter.glb',scale:1.0,yOffset:0},
 {name:'campfire',url:'assets/models/campfire.glb',scale:1.0,yOffset:0},
 {name:'filter',url:'assets/models/filter.glb',scale:1.0,yOffset:0},
 {name:'signal',url:'assets/models/signal.glb',scale:1.0,yOffset:0},
 {name:'wreck',url:'assets/models/wreck.glb',scale:1.0,yOffset:0},
 {name:'spring_cliff',url:'assets/models/spring_cliff.glb',scale:1.0,yOffset:0},
]).then(n=>{if(n)flash('🌴 Načteno '+n+' externích 3D modelů')})
  .catch(e=>console.warn('Volitelné 3D modely nejsou dostupné:',e));
}
boot();
return frame;
})();
this.tick=logic;
this.elapsedMs=0;
}
update(dt){
 if(typeof this.tick!=='function')return;
 this.elapsedMs+=Math.max(0,Math.min(.055,dt))*1000;
 this.tick(this.elapsedMs);
}
}
