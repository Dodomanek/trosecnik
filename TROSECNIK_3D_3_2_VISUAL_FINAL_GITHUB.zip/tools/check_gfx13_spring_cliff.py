#!/usr/bin/env python3
"""Validate a visual-only waterfall cliff replacement against supplied GFX12 release."""
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import subprocess
import numpy as np
import trimesh

ROOT=Path(__file__).resolve().parents[1]
PRIOR=Path('/mnt/data/TROSECNIK_3D_2_4_2_GFX_12_ESPERANZA_MODEL.zip')
MODEL=ROOT/'assets/models/spring_cliff.glb'
scene=trimesh.load(MODEL,force='scene')
triangles=sum(len(g.faces) for g in scene.geometry.values())
assert 5000<=triangles<=12000,triangles
assert 5<=len(scene.geometry)<=10,len(scene.geometry)
assert MODEL.stat().st_size < 250_000,MODEL.stat().st_size
assert np.isfinite(scene.bounds).all()
assert np.all(scene.bounds[0] > [-3.7,-.6,-.8]),scene.bounds
assert np.all(scene.bounds[1] < [3.7,4.5,2.6]),scene.bounds
for geom in scene.geometry.values():
 assert np.isfinite(geom.vertices).all() and geom.visual.material is not None
assert (ROOT/'graphics/previews/spring-cliff-gfx13-offline.png').stat().st_size>20_000
print(f'PASS 1/4: original GLB geometry and PBR materials ({triangles} triangles, {len(scene.geometry)} meshes, {MODEL.stat().st_size} bytes)')

source=(ROOT/'src/game_logic.js').read_text()
assert "{name:'spring_cliff',url:'assets/models/spring_cliff.glb',scale:1.0,yOffset:0}" in source
assert "if(!tryDrawGLB('spring_cliff',T(-16.8,H(-16.8,11.8),11.8,1,1,1,0),[1,1,1]))draw(cliffFallbackMesh" in source
assert 'cliffFallbackMesh=upload(cliffProcedural)' in source
assert 'waterfallMesh=upload(falls)' in source
print('PASS 2/4: GLB registration, unchanged waterfall shader/animation and original-rock fallback in active renderer')

assert PRIOR.is_file()
with ZipFile(PRIOR) as z:
 prefix='TROSECNIK_3D_2_4_2_GFX_12_ESPERANZA_MODEL/'
 entries={n[len(prefix):]:n for n in z.namelist() if n.startswith(prefix) and not n.endswith('/')}
 with TemporaryDirectory() as tmp:
  base=Path(tmp)
  (base/'src').mkdir();(base/'tools').mkdir()
  (base/'src/game_logic.js').write_bytes(z.read(entries['src/game_logic.js']))
  (base/'tools/patch_gfx13_cliff.py').write_bytes((ROOT/'tools/patch_gfx13_cliff.py').read_bytes())
  subprocess.run(['python',str(base/'tools/patch_gfx13_cliff.py')],capture_output=True,check=True)
  expected=(base/'src/game_logic.js').read_bytes()
  assert expected==(ROOT/'src/game_logic.js').read_bytes(),'Unexpected change outside explicit cliff rendering substitution'
 print('PASS 3/4: entire active game_logic.js byte-identical after applying only explicit visual-only patch to GFX12')
 excluded={'src/game_logic.js','README.md','assets/models/README.md','graphics/CHANGELOG.md','graphics/BACKLOG.md','graphics/REPORT.md'}
 for relative,name in entries.items():
  if relative in excluded:continue
  actual=ROOT/relative
  assert actual.is_file() and actual.read_bytes()==z.read(name),f'Unexpected mutation: {relative}'
 print(f'PASS 4/4: {len(entries)-len(excluded)} earlier files unchanged, including every quest, save format, dubbing and original model')
