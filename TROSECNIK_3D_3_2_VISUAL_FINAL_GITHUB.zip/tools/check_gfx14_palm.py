#!/usr/bin/env python3
"""Offline, read-only GFX14 GLB / regression / Vercel layout checks."""
from pathlib import Path
import hashlib
import trimesh
ROOT=Path(__file__).resolve().parents[1]
PREVIOUS=Path('/mnt/data/trosecnik_gfx13_build')

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
model=trimesh.load(ROOT/'assets/models/palm.glb',force='scene')
old=trimesh.load(PREVIOUS/'assets/models/palm.glb',force='scene')
tris=sum(len(x.faces) for x in model.geometry.values())
assert 1000<=tris<=3000, f'unexpected triangles: {tris}'
assert len(model.geometry)<=5 and len(model.geometry)<len(old.geometry)
assert model.bounds[0,1]>=-.01 and 5.7<model.bounds[1,1]<7.2, model.bounds
assert model.bounds[1,0]-model.bounds[0,0]<9.5 and model.bounds[1,2]-model.bounds[0,2]<9.5,model.bounds
assert all(m.is_winding_consistent for m in model.geometry.values())
for m in model.geometry.values():
    material=getattr(m.visual,'material',None)
    assert material is not None and getattr(material,'doubleSided',False)
changed=[];missing=[]
for oldfile in PREVIOUS.rglob('*'):
    if not oldfile.is_file():continue
    name=oldfile.relative_to(PREVIOUS)
    current=ROOT/name
    if not current.is_file():missing.append(str(name));continue
    if sha(oldfile)!=sha(current):changed.append(str(name))
assert not missing, f'missing baseline files: {missing}'
allowed={'assets/models/palm.glb','README.md','graphics/BACKLOG.md','graphics/CHANGELOG.md','graphics/REPORT.md'}
assert set(changed)<=allowed, f'unexpected baseline changes: {set(changed)-allowed}'
assert 'assets/models/palm.glb' in changed
for filename in ['index.html','vercel.json','manifest.webmanifest','src/main.js','src/renderer.js',
                 'src/game_logic.js','src/voice.js','assets/audio/dialogue/captions.json']:
    assert sha(ROOT/filename)==sha(PREVIOUS/filename), filename
assert (ROOT/'index.html').is_file() and (ROOT/'src/renderer.js').is_file() and (ROOT/'vercel.json').is_file()
assert len(list((ROOT/'assets/audio/dialogue').rglob('*.mp3')))==len(list((PREVIOUS/'assets/audio/dialogue').rglob('*.mp3')))
print('GFX14 PASS: valid GLB,',tris,'triangles,',len(model.geometry),'mesh groups (prior:',len(old.geometry),').')
print('GFX14 PASS: unchanged gameplay/renderer/voice/save and all original files retained.')
print('GFX14 PASS: Vercel static root, index.html + src/ + vercel.json present.')
print('Modified prior files:',', '.join(changed))
