#!/usr/bin/env python3
"""GFX20: original low-poly broadleaf canopy tree GLB replacing the sphere-cluster
`canopy()` placeholder. Regenerate with: python tools/generate_canopy.py
Only a static visual GLB is produced. No external assets, textures or downloads.
Coordinates: Y up, base y=0; overall height matches the previous procedural canopy
(trunk height 3-5.8 units, foliage clumps ~1.9-2.2 unit radius).
"""
from pathlib import Path
import hashlib
import math
import numpy as np
import trimesh
from trimesh.visual.material import PBRMaterial
from trimesh.visual.texture import TextureVisuals

OUT = Path(__file__).resolve().parents[1] / 'assets/models/canopy.glb'
PALETTE = {
    'bark': (78, 54, 31, 255),
    'leaf_deep': (46, 110, 64, 255),
    'leaf_lit': (98, 148, 74, 255),
}


def seeded_unit(*vals):
    h = hashlib.sha256(','.join(f'{v:.6f}' for v in vals).encode()).digest()
    return int.from_bytes(h[:4], 'little') / 2**32


def tapered_trunk(height, base_r, top_r, sides=7, rings=6, lean=(.12, .05)):
    v = []
    f = []
    for r in range(rings):
        t = r / (rings - 1)
        radius = base_r * (1 - t) + top_r * t
        cx = lean[0] * t * t
        cz = lean[1] * t * t
        y = height * t
        for j in range(sides):
            a = 2 * math.pi * j / sides
            wobble = 1 + .05 * math.sin(j * 2.3 + r * 1.7)
            v.append((cx + math.cos(a) * radius * wobble, y, cz + math.sin(a) * radius * wobble))
    for r in range(rings - 1):
        for j in range(sides):
            a = r * sides + j
            b = r * sides + (j + 1) % sides
            c = (r + 1) * sides + j
            d = (r + 1) * sides + (j + 1) % sides
            f.extend([(a, b, c), (b, d, c)])
    return trimesh.Trimesh(vertices=np.array(v), faces=np.array(f), process=False)


def foliage_clump(seed, center, radius, squash, jitter=.22):
    """Faceted, non-spherical foliage lobe: an icosphere pushed into an irregular
    blob so the canopy silhouette reads as leaf mass, not three smooth balls."""
    sphere = trimesh.creation.icosphere(subdivisions=1, radius=1.0)
    v = sphere.vertices.copy()
    for i in range(len(v)):
        n = v[i] / np.linalg.norm(v[i])
        bump = 1.0
        for freq, amp in ((1.3, .55), (2.6, .32), (4.7, .18)):
            bump += amp * jitter * math.sin(
                n[0] * freq * 5.3 + seeded_unit(seed, i, 1) * 6.28
                + n[1] * freq * 6.1 + seeded_unit(seed, i, 2) * 6.28
                + n[2] * freq * 4.6 + seeded_unit(seed, i, 3) * 6.28
            )
        v[i] = n * bump
    v[:, 0] *= radius
    v[:, 2] *= radius
    v[:, 1] *= radius * squash
    v[:, 1] += radius * squash * .15  # lift the underside above the branch point
    v += np.array(center)
    mesh = trimesh.Trimesh(vertices=v, faces=sphere.faces, process=False)
    mesh.fix_normals()
    return mesh


scene = trimesh.Scene()
groups = {'bark': [], 'leaf_deep': [], 'leaf_lit': []}

TRUNK_H = 3.35
trunk = tapered_trunk(TRUNK_H, base_r=.26, top_r=.15)
groups['bark'].append(trunk)
# A couple of short branch stubs low in the crown, matching the original's single
# trunk + offset foliage look, for a less perfectly-symmetrical silhouette.
for i, (ang, len_) in enumerate([(1.1, .55), (3.6, .48), (5.0, .5)]):
    a0 = np.array([0, TRUNK_H * .82, 0])
    a1 = a0 + np.array([math.cos(ang) * len_, len_ * .35, math.sin(ang) * len_])
    branch = tapered_trunk(1.0, base_r=.09, top_r=.05)
    # orient the tiny cylinder along a0->a1
    direction = a1 - a0
    length = np.linalg.norm(direction)
    branch.apply_scale([1, length, 1])
    zaxis = np.array([0, 1, 0])
    d = direction / length
    axis = np.cross(zaxis, d)
    if np.linalg.norm(axis) > 1e-6:
        angle = math.acos(np.clip(np.dot(zaxis, d), -1, 1))
        branch.apply_transform(trimesh.transformations.rotation_matrix(angle, axis))
    branch.apply_translation(a0)
    groups['bark'].append(branch)

# Four offset, irregular foliage clumps around the crown (echoes the original's 4-sphere
# ring) plus one smaller top clump, all faceted rather than smooth spheres.
crown = np.array([0, TRUNK_H, 0])
lobes = [
    dict(seed=11, off=(.75, -.05, .05), radius=1.55, squash=.82, mat='leaf_lit'),
    dict(seed=12, off=(-.35, .35, .70), radius=1.65, squash=.86, mat='leaf_deep'),
    dict(seed=13, off=(-.60, .05, -.65), radius=1.50, squash=.80, mat='leaf_lit'),
    dict(seed=14, off=(.35, .30, -.55), radius=1.45, squash=.84, mat='leaf_deep'),
    dict(seed=15, off=(.05, 1.05, .05), radius=1.10, squash=.78, mat='leaf_lit'),
]
for lobe in lobes:
    center = crown + np.array(lobe['off'])
    clump = foliage_clump(lobe['seed'], center, lobe['radius'], lobe['squash'])
    groups[lobe['mat']].append(clump)

for name, parts in groups.items():
    if not parts:
        continue
    merged = trimesh.util.concatenate(parts)
    merged.visual = TextureVisuals(material=PBRMaterial(
        name=name, baseColorFactor=PALETTE[name], metallicFactor=0,
        roughnessFactor=.95 if name == 'bark' else .88, doubleSided=name != 'bark'))
    scene.add_geometry(merged, node_name=name, geom_name=name)

OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_bytes(scene.export(file_type='glb'))
print('GFX20 CANOPY', OUT, 'bytes', OUT.stat().st_size,
      'meshes', len(scene.geometry),
      'triangles', sum(len(g.faces) for g in scene.geometry.values()),
      'bounds', scene.bounds.tolist())
