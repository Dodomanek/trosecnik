#!/usr/bin/env node
/** Offline grafický auditor Trosečníka. Nemění hru ani nevydává AI generace.
 *  Usage: node tools/graphics_agent.mjs audit|plan
 */
import {readFileSync,writeFileSync,existsSync,statSync,readdirSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(fileURLToPath(new URL('..',import.meta.url)));
const issues=[];
const note=(level,name,detail)=>issues.push({level,name,detail});
const read=p=>readFileSync(join(root,p),'utf8');
const requireFile=p=>{if(!existsSync(join(root,p))){note('ERROR',p,'Soubor chybí');return false;}return true;};
function inspectGLB(file){
 const b=readFileSync(file); if(b.length<20||b.toString('ascii',0,4)!=='glTF'||b.readUInt32LE(4)!==2)throw Error('Neplatná hlavička GLB v2');
 const size=b.readUInt32LE(8);if(size!==b.length)throw Error('Nesouhlasí délka GLB');
 let off=12,data=null;
 while(off+8<=size){const len=b.readUInt32LE(off),kind=b.readUInt32LE(off+4);off+=8;if(off+len>size)throw Error('Chunk přesahuje GLB');if(kind===0x4e4f534a)data=JSON.parse(b.subarray(off,off+len).toString('utf8'));off+=len;}
 if(off!==size||!data)throw Error('Chybí JSON chunk / nesouhlasí hranice');
 const meshes=data.meshes||[], accessors=data.accessors||[]; let triangles=0;
 for(const mesh of meshes)for(const p of mesh.primitives||[]){if(p.mode!==undefined&&p.mode!==4)continue;const id=p.indices,position=p.attributes?.POSITION;triangles+=Math.floor((id!==undefined?accessors[id]?.count:accessors[position]?.count||0)/3);}
 return {bytes:b.length,triangles,nodes:data.nodes?.length||0,meshes:meshes.length,skins:data.skins?.length||0,animations:(data.animations||[]).map(a=>a.name||'(bez názvu)'),textures:data.textures?.length||0,materials:data.materials?.length||0};
}
const checks=['index.html','src/main.js','src/renderer.js','src/game_logic.js','src/style.css','assets/models/robinson.glb','AGENTS.md','graphics/BRIEF.md'];
for(const p of checks)requireFile(p);
if(existsSync(join(root,'src/renderer.js'))){
 const r=read('src/renderer.js');
 for(const [pattern,label] of [[/THREE\.WebGLRenderer/, 'Three.js WebGLRenderer'],[/AnimationMixer/, 'Animace postavy'],[/actor\.position\.set\(x,y,z\)/,'Stabilní root animované postavy'],[/setPixelRatio\(ratio\)/,'Dynamické rozlišení'],[/shadow\.mapSize\.set\(/,'Stínové mapy']])if(!pattern.test(r))note('WARN',label,'Nenalezen očekávaný vzor, manuálně zkontrolovat');
 if(/setPixelRatio\(window\.devicePixelRatio\)/.test(r))note('WARN','Mobilní rozlišení','Neomezený devicePixelRatio může zpomalit telefon');
}
if(existsSync(join(root,'src/game_logic.js'))){
 const logic=read('src/game_logic.js');if(!/unstuck|odblok|safePos|lastSafe/i.test(logic))note('WARN','Odblokování','Nenalezen ukazatel na odblokovací funkci');
}
const modelDir=join(root,'assets/models');const modelResults={};
if(existsSync(modelDir))for(const f of readdirSync(modelDir).filter(f=>/\.glb$/i.test(f))){
 try{const data=inspectGLB(join(modelDir,f));modelResults[f]=data;
  if(data.triangles>25000)note('WARN',f,`${data.triangles} trojúhelníků; ověř mobilní FPS`);
  if(data.bytes>5_000_000)note('WARN',f,`${(data.bytes/1048576).toFixed(1)} MiB; ověř dobu načtení na mobilu`);
  if(f==='robinson.glb'){for(const a of ['Idle','Walk','Run','Gather','Chop','Build'])if(!data.animations.includes(a))note('ERROR','Animace Robinsona',`Chybí ${a}`);if(!data.skins)note('WARN','Rig Robinsona','GLB nemá glTF skin; není to profesionálně skinovaný humanoidní model');}
 }catch(e){note('ERROR',f,e.message)}
}
const errors=issues.filter(i=>i.level==='ERROR').length;
const results=[`# Grafický audit ${new Date().toISOString().slice(0,10)}`,'',`**Kritické chyby:** ${errors} · **Upozornění:** ${issues.length-errors}`,'', '## Kontrolované modely',''];
for(const [name,d] of Object.entries(modelResults))results.push(`- **${name}**: ${(d.bytes/1048576).toFixed(2)} MiB, ${d.triangles} trojúhelníků, ${d.meshes} mesh, ${d.skins} glTF skinů, ${d.textures} textur, animace: ${d.animations.join(', ')||'žádné'}`);
if(!Object.keys(modelResults).length)results.push('- Žádné GLB modely nenalezeny.');
results.push('','## Nálezy','');
if(issues.length)for(const i of issues)results.push(`- **${i.level} · ${i.name}:** ${i.detail}`);else results.push('- V mezích dostupných statických kontrol bez nálezu.');
results.push('','## Limity','', 'Tento audit kontroluje pouze strukturu, formát a vybrané vzory zdrojového kódu. Neměří FPS, nekontroluje vzhled textur, nestartuje WebGL, nedokládá dohratelnost ani neprokazuje odstranění klepání. Pro grafické změny je nutný reálný vizuální test na zařízení.','');
const report=results.join('\n');if(process.argv[2]==='plan'){process.stdout.write(read('graphics/BACKLOG.md'));}else if(process.argv[2]==='audit'||!process.argv[2]){writeFileSync(join(root,'graphics/REPORT.md'),report);console.log(report);process.exitCode=errors?1:0;}else{console.error('Použití: node tools/graphics_agent.mjs audit|plan');process.exitCode=2;}
