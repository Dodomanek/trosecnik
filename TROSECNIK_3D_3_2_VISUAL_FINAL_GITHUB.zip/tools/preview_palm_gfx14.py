#!/usr/bin/env python3
"""CPU rasterizer from the actual GFX14 GLB mesh, NOT a screenshot of the game."""
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
import trimesh
ROOT=Path(__file__).resolve().parents[1]
scene=trimesh.load(ROOT/'assets/models/palm.glb',force='scene')
W,H=1100,760
im=Image.new('RGB',(W,H)); pix=im.load()
for py in range(H):
    t=py/H
    rgb=(int(43+121*t),int(83+105*t),int(118+67*t)) if py<H*.78 else (int(161+38*t),int(147+32*t),int(112+26*t))
    for px in range(W):pix[px,py]=rgb
eye=np.array([11.,8.,-15.]);target=np.array([.45,3.15,.15]);
forward=(target-eye);forward/=np.linalg.norm(forward)
right=np.cross(forward,[0,1,0]);right/=np.linalg.norm(right);up=np.cross(right,forward)
light=np.array([.34,.81,-.43]);light/=np.linalg.norm(light)
triangles=[]
for mesh in scene.geometry.values():
    base=getattr(getattr(mesh.visual,'material',None),'baseColorFactor',[110,112,70,255])
    if base is None:base=[110,112,70,255]
    if max(base[:3])<=1:base=np.array(base[:3])*255
    pts=np.asarray(mesh.vertices); rel=pts-eye; depth=rel@forward
    sx=W*.50+(rel@right)/np.maximum(depth,.001)*1900
    sy=H*.56-(rel@up)/np.maximum(depth,.001)*1900
    for i,face in enumerate(mesh.faces):
        d=depth[face]
        if np.min(d)<.1:continue
        n=mesh.face_normals[i];shade=.57+.52*max(0,float(np.dot(n,light)))
        col=tuple(int(np.clip(float(c)*shade,0,255)) for c in base[:3])
        poly=[(float(sx[j]),float(sy[j])) for j in face]
        triangles.append((float(np.mean(d)),poly,col))
d=ImageDraw.Draw(im)
for _,poly,color in sorted(triangles,key=lambda e:-e[0]):d.polygon(poly,fill=color)
d.rounded_rectangle((22,22,500,94),radius=10,fill=(17,32,37))
d.text((38,38),'GFX 14  /  COASTAL PALM',fill=(253,215,143))
d.text((38,65),'OFFLINE GLB MODEL PREVIEW  |  NOT IN-GAME',fill=(213,221,215))
dst=ROOT/'graphics/previews/palm-gfx14-offline.png';im.save(dst,optimize=True)
print('PALM PREVIEW',dst,'triangles',len(triangles),'bytes',dst.stat().st_size)
