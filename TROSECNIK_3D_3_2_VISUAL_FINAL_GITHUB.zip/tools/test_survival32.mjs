import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInNewContext} from 'node:vm';
import {stepBoar,recipeCost,missingIngredients,updateRain} from '../src/survival32.js';
const src=readFileSync(new URL('../src/game_logic.js',import.meta.url),'utf8');
const data=(start,end)=>runInNewContext('('+src.slice(src.indexOf(start)+start.length,src.indexOf(end,src.indexOf(start))).replace(/;$/,'')+')');
const base=data('const BASE=',';\nconst ITEM='),build=data('const BUILD=',';\nconst OBJ='),objects=data('const OBJ=',';\nconst TUTORIAL_IDS=');
const boar=()=>({_wx:0,_wz:0});
test('windup locks direction, causes no damage, permits lateral dodge and ends in recovery',()=>{
 const b=boar(),h={x:0,z:3};assert.equal(stepBoar(b,h,.05),'warn');
 h.x=4;
 for(let i=0;i<19;i++)assert.notEqual(stepBoar(b,h,.05),'hit');
 assert.equal(b._phase,'charge');let hits=0;
 for(let i=0;i<14;i++)hits+=stepBoar(b,h,.05)==='hit';
 assert.equal(hits,0);assert.equal(b._wx,0);assert.equal(b._phase,'recover');
 const z=b._wz;for(let i=0;i<35;i++)stepBoar(b,h,.05);assert.equal(b._wz,z);
 stepBoar(b,h,.1);assert.equal(b._phase,'stalk');
});
test('charge hits at most once; collision aborts charge; swept test catches crossed player',()=>{
 const b=boar(),h={x:0,z:2};stepBoar(b,h,.01);stepBoar(b,h,1);
 let hits=0;for(let i=0;i<14;i++)hits+=stepBoar(b,h,.05)==='hit';assert.equal(hits,1);
 const c=boar();stepBoar(c,h,.01);stepBoar(c,h,1);stepBoar(c,h,.05,()=>false);assert.equal(c._phase,'recover');assert.equal(c._wz,0);
 const d=boar();stepBoar(d,h,.01);stepBoar(d,h,1);assert.equal(stepBoar(d,h,.6),'hit');
});
test('rain collects only after completion and only during rain, with persistent cap',()=>{
 const s={built:{rainCollector:2},weather:'rain',flags:{}};
 updateRain(s,50);assert.equal(s.flags.rainWater,undefined);
 s.built.rainCollector=3;updateRain(s,10);assert.equal(s.flags.rainWater,6);
 s.weather='clear';updateRain(s,100);assert.equal(s.flags.rainWater,6);
 s.weather='storm';updateRain(s,100);assert.equal(s.flags.rainWater,70);
 const restored=JSON.parse(JSON.stringify(s));updateRain(restored,10);assert.equal(restored.flags.rainWater,70);
});
test('bench discount and HUD deficits share cost, never spend storage or mutate recipe',()=>{
 const r={cost:{fiber:3,wood:2,cord:1}},s={built:{workbench:3},bag:{fiber:1,wood:2},storage:{fiber:30}};
 assert.deepEqual(recipeCost(r,s),{fiber:2,wood:2,cord:1});assert.equal(r.cost.fiber,3);
 assert.deepEqual(missingIngredients(recipeCost(r,s),s.bag),{fiber:1,cord:1});
 s.built.workbench=2;assert.equal(recipeCost(r,s).fiber,3);
 assert.equal(recipeCost({cost:{fiber:1}}, {built:{workbench:3}}).fiber,1);
});
test('three optional camp sites have complete base defaults and integer three-stage costs',()=>{
 for(const id of ['dryingRack','rainCollector','workbench']){
  assert.equal(base.built[id],0);assert.equal(objects.filter(o=>o.site===id).length,1);
  for(const [k,v] of Object.entries(build[id].needs)){let sum=0;for(let stage=0;stage<3;stage++)sum+=Math.floor(v*(stage+1)/3)-Math.floor(v*stage/3);assert.equal(sum,v,k);}
 }
 assert.equal(base.version,2);
});
const campCode=src.slice(src.indexOf("else if(site==='dryingRack')"),src.indexOf("else if(site==='storage')",src.indexOf("else if(site==='dryingRack')"))).replace(/^else /,'');
function campEnv(){const state={seconds:10,bag:{fish:1},flags:{},water:30};return {state,site:'dryingRack',add:(k,n)=>state.bag[k]=(state.bag[k]||0)+n,spend:cost=>{if(Object.entries(cost).some(([k,n])=>(state.bag[k]||0)<n))return false;for(const [k,n] of Object.entries(cost))state.bag[k]-=n;return true;},flash:()=>{},save:()=>{},openPanel:()=>{}};}
test('active rack callback consumes once, waits, gives two portions once, survives serialization',()=>{
 const e=campEnv(),act=()=>runInNewContext('(function(){'+campCode+'})()',e);
 act();assert.equal(e.state.bag.fish,0);assert.equal(e.state.flags.dryingUntil,70);
 act();assert.equal(e.state.bag.fishJerky,undefined);
 e.state=JSON.parse(JSON.stringify(e.state)); // callbacks below bind current restored state
 e.add=(k,n)=>e.state.bag[k]=(e.state.bag[k]||0)+n;
 e.state.seconds=70;act();assert.equal(e.state.bag.fishJerky,2);assert.equal(e.state.flags.dryingUntil,0);
 act();assert.equal(e.state.bag.fishJerky,2);
});
test('active collector callback conserves water and leaves unused reserve',()=>{
 const e=campEnv();e.site='rainCollector';e.state.water=90;e.state.flags.rainWater=70;
 runInNewContext('(function(){'+campCode+'})()',e);assert.equal(e.state.water,100);assert.equal(e.state.flags.rainWater,60);
 runInNewContext('(function(){'+campCode+'})()',e);assert.equal(e.state.flags.rainWater,60);
});
test('active combat callback rejects out-of-range targets and rewards recovery hits',()=>{
 const a=src.indexOf("else if(type==='boar'){",src.indexOf('function beginInteraction'));
 const b=src.indexOf("else if(type==='cave')",a);const code=src.slice(a,b).replace(/^else /,'');
 function run(distance,phase){const state={seconds:20,wild:{boarHP:{},boarDown:{}},energy:100};const o={id:'test',r:1.1,_phase:phase};let sound=0;const env={type:'boar',hero:{},state,o,weaponStats:()=>({id:'spear',cost:10,damage:20,range:2,duration:.4,name:'kopí'}),flash:()=>{},finishAction:(o,k,fn)=>fn(),clamp:(n,a,b)=>Math.max(a,Math.min(b,n)),objectAvailable:()=>true,d2:()=>distance,combatSound:()=>sound++,save:()=>{},awardXP:()=>{}};runInNewContext('(function(){'+code+'})()',env);return {state,sound};}
 assert.equal(run(5,'recover').state.wild.boarHP.test,undefined);
 assert.equal(run(1,'stalk').state.wild.boarHP.test,76);
 assert.equal(run(1,'recover').state.wild.boarHP.test,69);
 assert.equal(run(1,'recover').sound,1);
});
test('GFX20 models and fallbacks are wired and water shader avoids duplicate color declaration',()=>{
 for(const id of ['rock','canopy']){assert.ok(readFileSync(new URL('../assets/models/'+id+'.glb',import.meta.url)).length>100);assert.ok(src.includes("renderer.hasModel('"+id+"')"));assert.ok(src.includes("url:'assets/models/"+id+".glb'"));}
 assert.ok(src.includes('else draw(staticCanopyMesh'));assert.ok(src.includes('else draw(staticRockMesh'));
 const renderer=readFileSync(new URL('../src/renderer.js',import.meta.url),'utf8');assert.ok(!renderer.includes('attribute vec3 color;'));
});
