#!/usr/bin/env python3
"""GFX20: original low-poly boulder GLB replacing the sphere-batch `rock()` placeholder.
Regenerate with: python tools/generate_rock.py
Only a static visual GLB is produced. No external assets, textures or downloads.
Coordinates: Y up, base y=0 sits on the terrain; silhouette fits existing rock world scale
(the previous procedural rock spans roughly 1.1-1.7 units wide, ~0.9-1.4 tall).
"""
from pathlib import Path
import hashlib
import math
import numpy as np
import trimesh
from trimesh.visual.material import PBRMaterial
from trimesh.visual.texture import TextureVisuals

OUT = Path(__file__).resolve().parents[1] / 'assets/models/rock.glb'
PALETTE = {
    'stone': (140, 138, 121, 255),
    'stone_light': (173, 168, 140, 255),
    'moss': (86, 99, 68, 255),
}


def seeded_unit(*vals):
    """Deterministic pseudo-random float in [0,1) from integer/float seeds, no RNG state."""
    h = hashlib.sha256(','.join(f'{v:.6f}' for v in vals).encode()).digest()
    return int.from_bytes(h[:4], 'little') / 2**32


def faceted_boulder(seed, radius, squash, seg_lat=7, seg_lon=11, jitter=.16):
    """Icosphere-derived boulder with per-vertex displacement and NO normal smoothing,
    so faces read as flat, distinct facets (deliberate low-poly look, not a smooth ball)."""
    sphere = trimesh.creation.icosphere(subdivisions=1, radius=1.0)
    v = sphere.vertices.copy()
    for i in range(len(v)):
        n = v[i] / np.linalg.norm(v[i])
        bump = 1.0
        for freq, amp in ((1.7, .5), (3.1, .3), (5.4, .2)):
            bump += amp * jitter * math.sin(
                n[0] * freq * 6.0 + seeded_unit(seed, i, 1) * 6.28
                + n[1] * freq * 4.4 + seeded_unit(seed, i, 2) * 6.28
                + n[2] * freq * 5.2 + seeded_unit(seed, i, 3) * 6.28
            )
        v[i] = n * bump
    v[:, 0] *= radius
    v[:, 2] *= radius
    v[:, 1] *= radius * squash
    v[:, 1] -= v[:, 1].min()  # sit flush on y=0
    mesh = trimesh.Trimesh(vertices=v, faces=sphere.faces, process=False)
    mesh.fix_normals()
    return mesh


def moss_cap(host, seed, coverage=.22):
    """A thin shell over only the most upward-facing faces, for a second, sparser material band."""
    v = host.vertices
    f = host.faces
    normals = host.face_normals
    noisy = normals[:, 1] + 0.20 * np.array([seeded_unit(seed, i) - .5 for i in range(len(f))])
    threshold = np.quantile(noisy, 1 - coverage)
    keep = noisy >= max(threshold, .55)
    if not keep.any():
        return None
    faces = f[keep]
    cap = trimesh.Trimesh(vertices=v + host.vertex_normals * .006, faces=faces, process=False)
    cap.remove_unreferenced_vertices()
    return cap


scene = trimesh.Scene()
groups = {'stone': [], 'stone_light': [], 'moss': []}

# One boulder cluster: one dominant rock plus 2-3 smaller companions, matching the
# footprint and silhouette of the original rock() sphere batch (~1.3m wide clump).
layout = [
    dict(seed=1, x=0.00, z=0.00, radius=.62, squash=.72, mat='stone'),
    dict(seed=2, x=0.46, z=0.22, radius=.34, squash=.66, mat='stone_light'),
    dict(seed=3, x=-.30, z=-.36, radius=.27, squash=.70, mat='stone'),
    dict(seed=4, x=.05, z=.48, radius=.19, squash=.62, mat='stone_light'),
]
for part in layout:
    boulder = faceted_boulder(part['seed'], part['radius'], part['squash'])
    boulder.apply_translation([part['x'], 0, part['z']])
    groups[part['mat']].append(boulder)
    cap = moss_cap(boulder, part['seed'])
    if cap is not None:
        groups['moss'].append(cap)

for name, parts in groups.items():
    if not parts:
        continue
    merged = trimesh.util.concatenate(parts)
    merged.visual = TextureVisuals(material=PBRMaterial(
        name=name, baseColorFactor=PALETTE[name], metallicFactor=0,
        roughnessFactor=.97 if name != 'moss' else .93, doubleSided=False))
    scene.add_geometry(merged, node_name=name, geom_name=name)

OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_bytes(scene.export(file_type='glb'))
print('GFX20 ROCK', OUT, 'bytes', OUT.stat().st_size,
      'meshes', len(scene.geometry),
      'triangles', sum(len(g.faces) for g in scene.geometry.values()),
      'bounds', scene.bounds.tolist())
