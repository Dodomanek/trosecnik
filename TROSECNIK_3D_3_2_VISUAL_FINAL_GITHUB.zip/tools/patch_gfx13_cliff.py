#!/usr/bin/env python3
"""Idempotent visual-only substitution of the existing GFX9 waterfall backdrop."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'src/game_logic.js'
s=p.read_text()
assert 'spring_cliff.glb' not in s,'Already patched'
old='let terrainMesh,seaMesh,staticMesh,staticPalmMesh,waterfallMesh,wreckFallbackMesh,campMesh,sceneObstacles=[],staticTrees=[];'
new='let terrainMesh,seaMesh,staticMesh,staticPalmMesh,waterfallMesh,wreckFallbackMesh,cliffFallbackMesh,campMesh,sceneObstacles=[],staticTrees=[];'
assert s.count(old)==1
s=s.replace(old,new)
old='let falls=mesh(),fx=-16.8,fz=11.8,fy=H(fx,fz);for(let layer=0;layer<3;layer++)'
new='// GFX 13: the original rock wall is a separate fallback buffer; animated water is unchanged.\nlet cliffProcedural=mesh();let falls=mesh(),fx=-16.8,fz=11.8,fy=H(fx,fz);for(let layer=0;layer<3;layer++)'
assert s.count(old)==1
s=s.replace(old,new)
start=s.index('let cliffProcedural=mesh();let falls=mesh()')
end=s.index('waterfallMesh=upload(falls);',start)
segment=s[start:end]
assert segment.count("batchAdd(m,'sphere',rx,")==2
segment=segment.replace("batchAdd(m,'sphere',rx,","batchAdd(cliffProcedural,'sphere',rx,")
assert "for(let j=0;j<9;j++)" in segment
segment=segment.replace('for(let j=0;j<9;j++){let wx=', 'cliffFallbackMesh=upload(cliffProcedural);for(let j=0;j<9;j++){let wx=')
s=s[:start]+segment+s[end:]
old='if(waterfallMesh)draw(waterfallMesh,identity(),[1,1,1],0,2);'
new="// A local GLB replaces the static waterfall rocks without covering the moving water.\nif(!tryDrawGLB('spring_cliff',T(-16.8,H(-16.8,11.8),11.8,1,1,1,0),[1,1,1]))draw(cliffFallbackMesh,identity(),[1,1,1],0,0);\nif(waterfallMesh)draw(waterfallMesh,identity(),[1,1,1],0,2);"
assert s.count(old)==1
s=s.replace(old,new)
old=" {name:'wreck',url:'assets/models/wreck.glb',scale:1.0,yOffset:0},"
new=old+"\n {name:'spring_cliff',url:'assets/models/spring_cliff.glb',scale:1.0,yOffset:0},"
assert s.count(old)==1
s=s.replace(old,new)
p.write_text(s)
print('Patched active game_logic.js: visual-only cliff GLB, original fallback, existing waterfall preserved')
