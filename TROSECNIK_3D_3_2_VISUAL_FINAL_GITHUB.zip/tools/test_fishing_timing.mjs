#!/usr/bin/env node
// Regressions for visible-hit detection in the fishing minigame (no WebGL required).
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {dirname,resolve} from 'node:path';
import {FISH_GREEN_START,FISH_GREEN_END,FISH_EDGE_TOLERANCE,fishNeedleHitsGreen,fishNeedlePercent} from '../src/fishing_timing.js';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const logic=readFileSync(resolve(root,'src/game_logic.js'),'utf8');

test('green target and hit detector agree, including painted marker edges',()=>{
  assert.equal(FISH_GREEN_START,40);
  assert.equal(FISH_GREEN_END,61);
  for(let pct=FISH_GREEN_START;pct<=FISH_GREEN_END;pct+=.1){
    assert.equal(fishNeedleHitsGreen(pct),true,`visible green should always count at ${pct.toFixed(2)}%`);
  }
  assert.equal(fishNeedleHitsGreen(40-FISH_EDGE_TOLERANCE),true);
  assert.equal(fishNeedleHitsGreen(61+FISH_EDGE_TOLERANCE),true);
  assert.equal(fishNeedleHitsGreen(37),false);
  assert.equal(fishNeedleHitsGreen(65),false);
  assert.equal(fishNeedleHitsGreen(NaN),false);
});

test('animation starts inside target and stays inside 0..100%',()=>{
  assert.equal(fishNeedlePercent(0),50);
  for(let sec=0;sec<12;sec+=.01){
    const pct=fishNeedlePercent(sec);
    assert.ok(pct>=0 && pct<=100,`out-of-range ${pct}`);
  }
});

test('a hit is evaluated at press time (visible frame), not release time',()=>{
  const downAt=0; // marker is at 50% (inside green)
  const releasedAt=.28; // marker has moved well outside green during a long touch
  const visibleAtPress=fishNeedlePercent(downAt);
  assert.equal(fishNeedleHitsGreen(visibleAtPress),true);
  assert.equal(fishNeedleHitsGreen(fishNeedlePercent(releasedAt)),false);
  assert.match(logic,/addEventListener\('pointerdown',[\s\S]*?panelAction\('miniHit'\)/);
  assert.match(logic,/miniHit'&&e\.detail!==0\)return/); // avoid a second attempt on synthetic click
  assert.match(logic,/miniHit'\)\{if\(!mini\)return;mini\.attempts\+\+;let hit=fishNeedleHitsGreen\(mini\.displayedPercent\)/);
});

test('green visual and frame use same source of truth; no changes to save state schema',()=>{
  assert.match(logic,/FISH_GREEN_START\+'%/);
  assert.match(logic,/FISH_GREEN_END\+'%/);
  assert.match(logic,/mini\.displayedPercent=fishNeedlePercent\(mini\.t\)/);
  assert.match(logic,/const KEY='trosecnik3d_2_0_saves_v1'/);
  assert.match(logic,/if\(mini\.hits>=3\|\|mini\.attempts>=7\)/);
});
