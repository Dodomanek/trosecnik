#!/usr/bin/env python3
"""Offline software-model preview for development, NOT a screenshot of the game."""
from pathlib import Path
import numpy as np, trimesh, math
from PIL import Image, ImageDraw, ImageFont, ImageFilter
ROOT=Path(__file__).resolve().parents[1]
W,H=1300,750
im=Image.new('RGB',(W,H),(29,43,39));d=ImageDraw.Draw(im)
for y in range(H):
 t=y/H
 d.line((0,y,W,y),fill=(int(37+60*t),int(55+30*t),int(60-17*t)))
d.ellipse((25,487,855,725),fill=(50,65,54));d.ellipse((850,500,1285,698),fill=(50,65,54))
LIGHT=np.array([.3,.82,-.5]);LIGHT/=np.linalg.norm(LIGHT)
# View camera looks from (4,3.0,-6) toward the island objects.
CAM=np.array([.44,.29,-.85]);CAM/=np.linalg.norm(CAM)
RIGHT=np.cross([0,1,0],CAM);RIGHT/=np.linalg.norm(RIGHT)
UP=np.cross(CAM,RIGHT);UP/=np.linalg.norm(UP)

def render(path,anchor,scale):
 s=trimesh.load(path,force='scene')
 faces=[]
 for mesh in s.dump():
  vertices=np.asarray(mesh.vertices)
  mfaces=np.asarray(mesh.faces,dtype=int)
  normals=np.asarray(mesh.face_normals)
  material=mesh.visual.material
  color=np.asarray(material.baseColorFactor[:3],dtype=float)
  center=np.mean(vertices[mfaces],axis=1)
  depth=center@CAM
  px=(vertices@RIGHT)*scale+anchor[0]
  py=-(vertices@UP)*scale+anchor[1]
  for i,tri in enumerate(mfaces):
   n=normals[i];brightness=max(0,float(n@LIGHT))
   ambient=.47+brightness*.5
   col=tuple(int(min(255,chan*ambient+8)) for chan in color)
   coords=[(float(px[j]),float(py[j])) for j in tri]
   faces.append((float(depth[i]),coords,col))
 faces.sort(key=lambda f:f[0],reverse=True)
 for _,pts,col in faces:d.polygon(pts,fill=col)

render(ROOT/'assets/models/shelter.glb',(456,580),160)
render(ROOT/'assets/models/campfire.glb',(1062,599),245)
try:
 font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',31)
 small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
except OSError:font=ImageFont.load_default();small=font
d.text((37,26),'TROSECNIK 3D  |  GFX 10',fill=(240,214,168),font=font)
d.text((39,72),'Skutecne modely z GLB  /  offline nahled (nejde o screenshot hry)',fill=(206,216,206),font=small)
d.text((252,680),'PRISTRESEK  /  4 408 trojuhelniku',fill=(244,229,192),font=small)
d.text((918,680),'OHNISTE /  1 940',fill=(244,229,192),font=small)
path=ROOT.parent/'TROSECNIK_GFX_10_MODEL_PREVIEW.png';im.save(path)
print('MODEL_PREVIEW',path,im.size)
