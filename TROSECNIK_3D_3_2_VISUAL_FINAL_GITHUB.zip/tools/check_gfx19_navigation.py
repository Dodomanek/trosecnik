#!/usr/bin/env python3
"""Compare GFX19 with the supplied GFX18 release: only navigation presentation may change."""
from pathlib import Path
from hashlib import sha256
import re
import json

ROOT=Path(__file__).resolve().parents[1]
BASELINE=json.loads((ROOT/'tools/gfx18_baseline.json').read_text())
new=(ROOT/'src/game_logic.js').read_text()

assert new.startswith("import { computeQuestPointer } from './quest_pointer.js';\n"), 'Missing navigation helper import'
new=new.split('\n',1)[1]
new=new.replace('renderer.heroLastTime=elapsed;updateQuestPointer();renderer.endFrame();}',
                'renderer.heroLastTime=elapsed;drawQuestArrow();renderer.endFrame();}')
new=new.replace('function currentQuestTarget(){let q=currentQuest();return q&&OBJ.find(o=>o.id===q.target)||null}',
                'function currentQuestTarget(){let q=currentQuest(),target=q&&OBJ.find(o=>o.id===q.target);return target&&objectAvailable(target)?target:null}')
old_pointer='''function drawQuestArrow(){
 const target=currentQuestTarget();
 if(!target)return;
 const dx=target.x-hero.x,dz=target.z-hero.z,dist=Math.hypot(dx,dz);
 if(!Number.isFinite(dist)||dist<.45)return;
 const yaw=facing(dx,dz),forwardX=-Math.sin(yaw),forwardZ=-Math.cos(yaw),sideX=Math.cos(yaw),sideZ=-Math.sin(yaw);
 const bob=Math.sin(elapsed*2.8+dist*.08)*.04,baseY=H(hero.x,hero.z)+2.85+bob;
 const near=clamp((dist-.9)/2.6,0,1),size=.72+.18*near;
 const body=[.76,.67,.43],tip=[.86,.77,.54],shadow=[.18,.16,.12];
 draw('disc',T(hero.x,baseY-.06,hero.z,.16*size,1,.16*size,0),shadow,3,0);
 shape('box',hero.x-forwardX*.02,baseY,hero.z-forwardZ*.02,.045*size,.045*size,.20*size,body,yaw);
 for(const side of [-1,1]){
  const wingX=hero.x+forwardX*.12*size+sideX*side*.036*size;
  const wingZ=hero.z+forwardZ*.12*size+sideZ*side*.036*size;
  shape('box',wingX,baseY,wingZ,.036*size,.036*size,.12*size,tip,yaw+side*.78);
 }
 shape('sphere',hero.x,baseY,hero.z,.05*size,.018*size,.05*size,shadow);
}
'''
new=re.sub(r'// GFX19: the head marker is a projected HUD element,[\s\S]+?(?=function nearbyObject\()',old_pointer,new,count=1)
assert sha256(new.encode()).hexdigest()==BASELINE['originalLogicHash'], 'Unexpected gameplay or save differences from GFX18'

for file,digest in BASELINE['preservedFileHashes'].items():
 path=ROOT/file
 assert path.is_file(), f'Missing original file: {file}'
 assert sha256(path.read_bytes()).hexdigest()==digest, f'Unexpected modification of {file}'

html=(ROOT/'index.html').read_text()
assert html.count('id="questPointer"')==1
assert 'aria-hidden="true"' in html
assert 'pointer-events:none' in (ROOT/'src/style.css').read_text()
assert 'computeQuestPointer' in (ROOT/'src/game_logic.js').read_text()
assert 'drawQuestArrow()' not in (ROOT/'src/game_logic.js').read_text()
print('PASS: active gameplay and save code unchanged aside from explicitly scoped navigation presentation')
print('PASS: all',len(BASELINE['preservedFileHashes']),'baseline files retained and byte-identical (including models, audio, controls)')
print('PASS: DOM arrow present once, noninteractive; GPU arrow removed')
print('Baseline:',BASELINE['baseline'])
