#!/usr/bin/env python3
"""Deterministic original camp GLB models; offline, no purchased or third-party assets.
Regenerate: python tools/generate_camp_assets.py
World coordinates: Y up, site (x,z) centered, base y=0. Gameplay/physics not touched.
"""
from pathlib import Path
from collections import defaultdict
import math, random
import numpy as np
import trimesh
from trimesh.visual.material import PBRMaterial
from trimesh.visual.texture import TextureVisuals

OUT=Path(__file__).resolve().parents[1]/'assets'/'models'
rng=random.Random(240210)

# Low specular response suits bark, rattan, leaves, weathered rock and canvas.
PALETTE={
 'bark':(81,49,29,255),'wood':(124,80,43,255),'woodlight':(165,116,63,255),
 'wooddark':(53,36,25,255),'rope':(176,136,76,255),'leaf':(51,94,43,255),
 'leaflight':(91,125,58,255),'leafdark':(31,64,34,255),'canvas':(130,115,80,255),
 'stone':(90,91,84,255),'stoneLight':(133,130,109,255),'ember':(218,93,34,255),
 'char':(38,31,28,255), 'linen':(161,143,111,255)
}

class Asset:
 def __init__(self):self.parts=defaultdict(list)
 def add(self,mesh,mat):
  mesh=mesh.copy();self.parts[mat].append(mesh)
 def box(self,extents,center,mat,rotation=0):
  m=trimesh.creation.box(extents=extents)
  if rotation:m.apply_transform(trimesh.transformations.rotation_matrix(rotation,[0,1,0]))
  m.apply_translation(center);self.add(m,mat)
 def beam(self,a,b,r,mat,sections=7):
  a,b=np.array(a,dtype=float),np.array(b,dtype=float);v=b-a;length=np.linalg.norm(v)
  if length<.0001:return
  mesh=trimesh.creation.cone(radius=r,height=length,sections=sections) if False else trimesh.creation.cylinder(radius=r,height=length,sections=sections)
  mesh.apply_transform(trimesh.geometry.align_vectors([0,0,1],v/length));mesh.apply_translation((a+b)*.5)
  self.add(mesh,mat)
 def rock(self,center,radius,mat,seed):
  local=random.Random(seed);m=trimesh.creation.icosphere(subdivisions=1,radius=1)
  p=m.vertices.copy();p*=np.array(radius)[None,:]
  p*=np.array([[local.uniform(.85,1.13) for _ in range(3)] for __ in range(len(p))]);m.vertices=p
  m.apply_translation(center);self.add(m,mat)
 def ribbon(self,points,widths,mat,twist=0):
  p=np.asarray(points,dtype=float);verts=[]
  for i,pt in enumerate(p):
   forward=p[min(i+1,len(p)-1)]-p[max(i-1,0)]
   perpendicular=np.cross(forward,[0,1,0]);perpendicular/=max(1e-8,np.linalg.norm(perpendicular))
   angle=twist*math.sin(math.pi*i/max(1,len(p)-1));c=math.cos(angle);s=math.sin(angle)
   transverse=perpendicular*c+np.array([0.,1.,0.])*s
   verts.extend([pt-transverse*widths[i]*.5,pt+transverse*widths[i]*.5])
  faces=[]
  for j in range(len(p)-1):faces.extend([(2*j,2*j+1,2*j+2),(2*j+1,2*j+3,2*j+2)])
  mesh=trimesh.Trimesh(vertices=verts,faces=faces,process=False)
  # Duplicate for two-sided fronds and canvas: avoid depending on GLTF doubleSided exporter.
  other=mesh.copy();other.faces=np.fliplr(other.faces);self.add(mesh,mat);self.add(other,mat)
 def save(self,name):
  scene=trimesh.Scene();tris=0
  for mat,parts in self.parts.items():
   m=trimesh.util.concatenate(parts)
   m.visual=TextureVisuals(material=PBRMaterial(name=mat,baseColorFactor=PALETTE[mat],metallicFactor=0.0,roughnessFactor=.96,doubleSided=True))
   scene.add_geometry(m,node_name=mat,geom_name=mat)
   tris+=len(m.faces)
  path=OUT/name;path.write_bytes(scene.export(file_type='glb'))
  print(f'{name}: {tris} triangles, {len(self.parts)} meshes, {path.stat().st_size} bytes')
  return path

def shelter():
 a=Asset()
 # This is a new VISUAL at the exact previous campsite and no new collision primitives.
 # 2.45 wide x 2.10 deep, roof height 2.42. Entrance faces negative Z.
 for z in (-.86,-.35,.22,.79):a.box((2.12,.13,.43),(0,.17,z),'woodlight')
 for x in (-1.00,1.00):
  for z in (-.84,.84):
   a.beam((x,.08,z),(x,2.17,z),.095,'bark')
   # Binding wrapped around each post, with a recognizable alternating lash pattern.
   for offset in (.02,.085):
    for side in (-1,1):a.beam((x-.105,2.06+offset,z+side*.08),(x+.105,2.08+offset,z-side*.08),.012,'rope',5)
 # Ridge and sloped rafters. Roof apex height 2.53, edges 2.06.
 for z in (-.93,.93):
  for side in (-1,1):a.beam((0,2.53,z),(side*1.17,2.08,z),.072,'wood')
  a.beam((-1.17,2.08,z),(1.17,2.08,z),.047,'wood')
 a.beam((0,2.54,-1.01),(0,2.54,1.01),.086,'wood')
 for side in (-1,1):a.beam((side*1.12,2.08,-1.01),(side*1.12,2.08,1.01),.056,'wood')
 # Overlapping, curved, tapering palm-frond strips fitted over both roof pitches.
 # Two colors and staggered rows avoid a flat geometric roof.
 for side in (-1,1):
  for row in range(7):
   z=-1.04+row*.33
   for leaf in range(14):
    x=side*(.05+leaf*.083)
    xEnd=side*(min(1.23,abs(x)+.20))
    center=[]
    for j in range(5):
     t=j/4
     xx=x+(xEnd-x)*t
     yy=2.54-(abs(xx)/1.18)*.44+.025*math.sin(math.pi*t)+row*.002
     zz=z+.045*math.sin(math.pi*t)
     center.append((xx,yy,zz+.17*t))
    a.ribbon(center,[.068,.079,.064,.032,.003],('leaf','leaflight','leafdark')[(row+leaf)%3],twist=.12)
 # Back wall: rough woven reed mat, with small gaps for depth.
 for i in range(19):
  x=-.95+i*.105;mat=('leafdark','leaf','canvas')[i%3]
  a.ribbon([(x,.26,.87),(x+.012,.9,.87),(x,1.57,.87),(x+.015,2.02,.87)], [.095]*4,mat)
 for j in range(13):
  h=.3+j*.127
  a.beam((-.96,h,.895),(.96,h+.026,.895),.013,'rope',5)
 # A bed roll and a small folded blanket remain purely decorative.
 a.box((1.04,.10,.56),(-.30,.29,.30),'canvas')
 a.box((.44,.07,.55),(.16,.36,.30),'linen')
 a.beam((-.75,.36,.04),(-.75,.36,.63),.067,'wooddark')
 return a.save('shelter.glb')

def campfire():
 a=Asset()
 # Ring follows original 1.1m campfire radius and existing interaction position.
 for i in range(11):
  angle=i*2*math.pi/11;x=.56*math.cos(angle);z=.56*math.sin(angle)
  a.rock((x,.12,z),(.20+rng.random()*.045,.18,.15), 'stone' if i%3 else 'stoneLight',200+i)
 for i in range(5):
  angle=i*math.pi/5
  a.beam((-.38*math.cos(angle),.15,-.38*math.sin(angle)),(.38*math.cos(angle),.20,.38*math.sin(angle)),.090,'wood' if i%2 else 'bark',9)
  for t in (-.65,-.2,.2,.65):
   p=(t*.38*math.cos(angle),.11,t*.38*math.sin(angle))
   a.box((.10,.028,.035),p,'wooddark',angle)
 a.rock((0,.09,0),(.27,.055,.25),'char',529)
 for i in range(7):
  theta=rng.random()*math.pi*2
  a.rock((rng.uniform(-.24,.24),.13,rng.uniform(-.22,.22)),(.023,.012,.025),'ember',900+i)
 return a.save('campfire.glb')

if __name__=='__main__':
 OUT.mkdir(parents=True,exist_ok=True)
 shelter();campfire()
