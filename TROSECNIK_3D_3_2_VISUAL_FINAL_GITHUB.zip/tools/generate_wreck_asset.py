#!/usr/bin/env python3
"""Original, deterministic Esperanza shipwreck GLB; local centre, ground Y=0.

No third-party mesh, license, image URL, paid generation or gameplay collider.
Run: python tools/generate_wreck_asset.py
"""
from collections import defaultdict
from pathlib import Path
import math
import random
import numpy as np
import trimesh
from trimesh.visual.material import PBRMaterial
from trimesh.visual.texture import TextureVisuals

OUT=Path(__file__).resolve().parents[1]/'assets/models/wreck.glb'
rng=random.Random(24212)
PALETTE={
 'hull': (67,43,28,255), 'planks':(121,82,48,255),
 'sunbleached':(167,131,88,255), 'darkwood':(47,33,25,255),
 'agedrope':(156,131,91,255), 'rustiron':(93,68,56,255),
 'canvas':(172,155,120,255), 'seaweed':(52,74,48,255),
 'tar':(31,30,26,255), 'edge':(191,150,99,255),
}
class Model:
 def __init__(self): self.parts=defaultdict(list)
 def add(self,geom,material):
  if geom is not None and len(geom.faces): self.parts[material].append(geom)
 def box(self,centre,ext,material,rotation=None):
  g=trimesh.creation.box(extents=ext)
  if rotation is not None: g.apply_transform(trimesh.transformations.rotation_matrix(rotation,[0,1,0]))
  g.apply_translation(centre);self.add(g,material)
 def beam(self,a,b,r,material,sides=7):
  a,b=np.asarray(a,dtype=float),np.asarray(b,dtype=float)
  v=b-a;l=np.linalg.norm(v)
  if l<1e-5:return
  g=trimesh.creation.cylinder(radius=r,height=l,sections=sides)
  g.apply_transform(trimesh.geometry.align_vectors([0,0,1],v/l));g.apply_translation((a+b)*.5)
  self.add(g,material)
 def surface(self,points,faces,material,double=False):
  g=trimesh.Trimesh(vertices=np.array(points,dtype=float),faces=faces,process=False)
  if double:g.faces=np.vstack((g.faces,np.fliplr(g.faces)))
  self.add(g,material)
 def save(self):
  scene=trimesh.Scene();triangles=0
  for mat,parts in self.parts.items():
   g=trimesh.util.concatenate(parts)
   colour=PALETTE[mat]
   g.visual=TextureVisuals(material=PBRMaterial(name=mat,baseColorFactor=colour,metallicFactor=.04 if mat=='rustiron' else 0.,roughnessFactor=.93,doubleSided=True))
   scene.add_geometry(g,geom_name=mat,node_name=mat);triangles+=len(g.faces)
  OUT.parent.mkdir(parents=True,exist_ok=True);OUT.write_bytes(scene.export(file_type='glb'))
  print(f'{OUT.name}: {triangles} triangles, {len(self.parts)} material meshes, {OUT.stat().st_size} bytes')
  return OUT

a=Model()
# Original wreck footprint x ~[-4.3,4.3], z ~[-1.45,1.45]. New model is
# entirely cosmetic at the existing position: the original physics still owns its collider.
xstations=[-4.12,-3.35,-2.55,-1.7,-.85,0,.85,1.7,2.55,3.35,4.12]
# Broken hull: narrowing ends, thick chine, exposed internal ribs and upper splintered gunwale.
for side in (-1,1):
 for idx in range(len(xstations)-1):
  x0,x1=xstations[idx:idx+2]
  taper=lambda x: .38+.62*(1.-(abs(x)/4.55)**2)
  width0=1.43*taper(x0);width1=1.43*taper(x1)
  keel_y=.27; sheer0=1.10+.10*abs(x0)/4;sheer1=1.10+.10*abs(x1)/4
  # Bow starboard is broken away; jagged fracture reveals individual ribs.
  if side>0 and idx in (7,8):continue
  pts=[(x0,keel_y,side*.18),(x1,keel_y,side*.18),
       (x0,.42,side*width0*.77),(x1,.42,side*width1*.77),
       (x0,sheer0,side*width0),(x1,sheer1,side*width1)]
  a.surface(pts,[(0,2,1),(1,2,3),(2,4,3),(3,4,5)],'hull',True)
  for level in (.58,.78,.99):
   # Separate coarse strakes, with narrow visible seams instead of a single slab.
   z0=side*(.16+(width0-.16)*min(1.,(level-.20)/.90))
   z1=side*(.16+(width1-.16)*min(1.,(level-.20)/.90))
   a.beam((x0,level,z0),(x1,level,z1),.042, 'sunbleached' if (idx+int(level*10))%5==0 else 'planks',6)
  a.beam((x0,sheer0,side*width0),(x1,sheer1,side*width1),.065,'edge',7)
# Long keel and unevenly spaced interior deck boards, leaving broken openings.
a.beam((-4.22,.19,0),(4.26,.19,0),.135,'darkwood',9)
for j,z in enumerate(np.linspace(-.98,.98,8)):
 for i in range(8):
  if (i,j) in {(2,2),(3,2),(3,3),(5,5),(6,5)}:continue
  x=-3.38+i*.92+.04*(j%2)
  length=.77 if i<7 else .61
  a.box((x,.66+(.025 if (i+j)%5==0 else 0),z),(length,.074,.218),'planks' if (i+j)%4 else 'sunbleached',.015*(j%3-1))
for i,x in enumerate(xstations[1:-1]):
 width=1.43*(.38+.62*(1.-(abs(x)/4.55)**2))
 for side in (-1,1):
  if side>0 and i in (6,7):continue
  a.beam((x,.25,0),(x,.35,side*width*.81),.073,'darkwood',6)
  a.beam((x,.35,side*width*.81),(x,1.25+(.17 if i%4==0 else 0),side*width),.066,'darkwood',6)
# Raised stern cross-frame, jagged snapped bow boards and loose coastal debris.
for z in np.linspace(-1.05,1.05,6):a.box((-3.67,.86,z),(.26,.13,.30),'hull')
for i in range(8):
 x=3.32+rng.uniform(-.10,.9);z=rng.uniform(-1.24,1.24)
 a.beam((x,.38,z),(x+rng.uniform(.16,.47),rng.uniform(.25,.91),z+rng.uniform(-.22,.22)),rng.uniform(.035,.065),'edge',5)
for j in range(6):
 x=rng.choice([-1,1])*rng.uniform(2.8,4.3);z=rng.choice([-1,1])*rng.uniform(1.2,2.0)
 a.box((x,.13,z),(rng.uniform(.55,1.25),.07,.15),'sunbleached',rng.uniform(-.85,.85))
# Main cracked mast, broken angled foremast and torn sail with irregular cutout.
a.beam((-.85,.56,-.08),(-1.75,4.55,-.36),.118,'darkwood',9)
a.beam((-.8,.58,.06),(.75,2.76,-.32),.09,'hull',7)
a.beam((-2.05,3.35,-.38),(-.99,3.56,-.38),.042,'sunbleached',6)
a.beam((-1.62,2.02,-.38),(-.73,2.20,-.38),.037,'sunbleached',6)
a.surface([(-2.04,3.3,-.41),(-1.06,3.46,-.41),(-1.03,2.70,-.50),(-1.42,2.81,-.52),(-1.35,2.09,-.51),(-1.80,2.24,-.44)],[(0,1,3),(0,3,5),(3,4,5)],'canvas',True)
a.beam((-1.75,4.51,-.36),(-2.96,.51,-1.30),.014,'agedrope',5)
a.beam((-1.75,4.51,-.36),(-.26,.47,1.26),.014,'agedrope',5)
# Stern cargo with weathered metal bands; a few ropes and hanging wet seaweed.
a.box((-3.36,.49,.60),(.66,.69,.59),'planks',-.17)
for dx in (-.27,.27):a.box((-3.36+dx,.5,.60),(.035,.72,.63),'rustiron',-.17)
for i in range(11):
 x=-3.5+i*.66;side=-1 if i%2 else 1
 if i in (4,6):continue
 z=side*(.89+.06*math.sin(i))
 a.beam((x,.56,z),(x+.08,.40,z+side*.24),.020,'seaweed',5)

if __name__=='__main__': a.save()
