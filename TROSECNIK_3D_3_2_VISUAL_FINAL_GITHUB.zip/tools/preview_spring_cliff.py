#!/usr/bin/env python3
"""Offline CPU triangle projection from spring_cliff.glb. NOT a WebGL screenshot."""
from pathlib import Path
import math
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import trimesh
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'assets/models/spring_cliff.glb'
DST=ROOT/'graphics/previews/spring-cliff-gfx13-offline.png'
scene=trimesh.load(SRC,force='scene')
w,h=1200,720
im=Image.new('RGB',(w,h));pix=im.load()
for y in range(h):
 t=y/h
 col=(int(36+56*t),int(68+60*t),int(81+53*t)) if y<h*.63 else (int(145-11*t),int(131-16*t),int(101-19*t))
 for x in range(w):pix[x,y]=col

eye=np.array([7.5,5.2,-12.0]);target=np.array([0.,1.85,.55]);forward=target-eye;forward/=np.linalg.norm(forward)
right=np.cross(forward,[0,1,0]);right/=np.linalg.norm(right);up=np.cross(right,forward)
light=np.array([-0.5,0.8,-0.5]);light/=np.linalg.norm(light)
triangles=[]
for g in scene.geometry.values():
 base=getattr(getattr(g.visual,'material',None),'baseColorFactor',[125,91,58,255])
 if base is None:base=[125,91,58,255]
 if max(base[:3])<=1:base=np.array(base[:3])*255
 xyz=np.asarray(g.vertices,dtype=float);rel=xyz-eye
 depth=rel@forward
 xscreen=w*.50+(rel@right)/np.maximum(depth,.01)*1320
 yscreen=h*.57-(rel@up)/np.maximum(depth,.01)*1320
 for i,face in enumerate(g.faces):
  d=depth[face]
  if np.min(d)<=.1:continue
  pts=[(float(xscreen[j]),float(yscreen[j])) for j in face]
  normal=g.face_normals[i]
  shade=.40+.58*max(0,float(np.dot(normal,light)))
  color=tuple(int(np.clip(float(c)*shade,0,255)) for c in base[:3])
  triangles.append((float(np.mean(d)),pts,color))
draw=ImageDraw.Draw(im)
for _,pts,col in sorted(triangles,key=lambda t:-t[0]):draw.polygon(pts,fill=col)
draw.rounded_rectangle((24,22,560,90),radius=10,fill=(18,31,37))
draw.text((39,33),'SPRING CLIFF   /   GFX 13',fill=(242,222,179))
draw.text((39,57),'OFFLINE MODEL PREVIEW  |  NOT IN-GAME',fill=(215,220,217))
DST.parent.mkdir(parents=True,exist_ok=True);im.save(DST,optimize=True)
print('Preview generated from actual GLB triangles:',DST,'size',DST.stat().st_size,'triangle count',len(triangles))
