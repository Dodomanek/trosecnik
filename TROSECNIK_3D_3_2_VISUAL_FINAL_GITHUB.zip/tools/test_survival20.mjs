import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {dirname, resolve} from 'node:path';
import {runInNewContext} from 'node:vm';
import {
  STARTER_NODE_IDS, STARTER_NODE_HARVESTS, starterNode,
  gatherCount, gatherCooldown, resourceAvailable, recordGather
} from '../src/resource_rules.js';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const baseline=JSON.parse(readFileSync(resolve(root,'tools/fixtures/gfx19_quest_object_baseline.json'),'utf8'));
const after=readFileSync(resolve(root,'src/game_logic.js'),'utf8');
function sourceList(source,start,end){
 const a=source.indexOf(start),b=source.indexOf(end,a);
 assert.ok(a>=0&&b>a,`missing ${start}`);
 return runInNewContext(source.slice(a+start.length,b).trim().replace(/;$/,''));
}
const quests=sourceList(after,'const QUESTS=',';\nconst BUILD=');
const oldQuests=baseline.quests;
const objects=sourceList(after,'const OBJ=',';\nconst TUTORIAL_IDS=');
const oldObjects=baseline.objects;

// Near-camp deposits are finite. Do not require a new save-schema version.
test('starter resource is finite after three harvests and does not resurrect after 1 hour',()=>{
 const n={id:'driftwood',type:'wood',repeat:55}; const flags={};
 assert.equal(starterNode(n),true);
 assert.equal(STARTER_NODE_HARVESTS,3);
 for(let k=0;k<3;k++){
  const t=k*181;
  assert.equal(resourceAvailable(n,flags,t),true);
  recordGather(n,flags,t);
  assert.equal(gatherCount(n,flags),k+1);
  assert.equal(resourceAvailable(n,flags,t+179),false);
 }
 assert.equal(resourceAvailable(n,flags,999999),false);
 assert.equal(flags['collected-driftwood'],362);
});
test('old save with collected timestamp counts as first harvest, leaves two further charges',()=>{
 const n={id:'palmFiber',type:'fiber',repeat:48};
 const flags={'collected-palmFiber':0};
 assert.equal(gatherCount(n,flags),1);
 assert.equal(resourceAvailable(n,flags,181),true);
 recordGather(n,flags,181);
 assert.equal(gatherCount(n,flags),2);
 assert.equal(resourceAvailable(n,flags,360),false);
 recordGather(n,flags,362);
 assert.equal(gatherCount(n,flags),3);
 assert.equal(resourceAvailable(n,flags,10000),false);
});
test('outlying materials replenish only after longer active-game cooldown',()=>{
 const n={id:'woodNorth',type:'wood',repeat:90}; const flags={};
 assert.equal(starterNode(n),false);assert.equal(gatherCooldown(n),300);
 recordGather(n,flags,100);
 assert.equal(resourceAvailable(n,flags,399),false);
 assert.equal(resourceAvailable(n,flags,400),true);
 recordGather(n,flags,400);
 assert.equal(resourceAvailable(n,flags,700),true);
});
test('fish are renewable but catches impose cooldown at their actual fishing spot',()=>{
 const n={id:'fish',type:'fish',repeat:35};const flags={};
 assert.equal(gatherCooldown(n),90);
 recordGather(n,flags,12);assert.equal(resourceAvailable(n,flags,101),false);
 assert.equal(resourceAvailable(n,flags,102),true);
 assert.match(after,/fishMini\(o\)/);
 assert.match(after,/recordGather\(fishSource,state\.flags,state\.seconds\)/);
});
test('only ten early resources are limited, distant water and wildlife remain unaffected',()=>{
 assert.equal(STARTER_NODE_IDS.length,10);
 assert.equal(resourceAvailable({id:'spring',type:'spring'},{},10),true);
 assert.equal(resourceAvailable({id:'herbA',type:'herb',repeat:170},{},10),true);
 assert.equal(resourceAvailable({id:'stoneEast',type:'stone',repeat:90},{},10),true);
 assert.ok(objects.some(o=>o.id==='woodNorth'));
 assert.ok(objects.some(o=>o.id==='stoneEast'));
 assert.ok(objects.some(o=>o.id==='fiberWest'));
});
test('four consecutive reconnaissance quests extend chapter III between radio and expedition',()=>{
 const ids=quests.map(q=>q.id),legacy=oldQuests.map(q=>q.id);
 const extra=['coastSurvey','westSurvey','ridgeSurvey','surveyNotes'];
 assert.deepEqual(Array.from(ids.filter(id=>!legacy.includes(id)).filter(id=>extra.includes(id))),extra);
 assert.ok(ids.indexOf('last')<ids.indexOf(extra[0]));
 assert.ok(ids.indexOf(extra[3])<ids.indexOf('expedition'));
 for(const id of extra){
  const q=quests.find(x=>x.id===id),target=objects.find(x=>x.id===q.target);
  assert.ok(target,`missing target for ${id}`);
  assert.equal(target.type, id==='surveyNotes'?'supply':'storySite');
 }
});
test('new quest flags allow advancing through each additional story beat',()=>{
 const extra=['coastSurvey','coastCache','westSurvey','westCache','ridgeSurvey','ridgeCache','surveyNotes'];
 const save={flags:{},story:{fate:'mara',finalSignal:true},built:{},bag:{},skills:{}};
 for(const q of quests){
  if(q.id==='last')break;
  save.flags['quest-'+q.id]=true;
 }
 const current=()=>quests.find(q=>(!q.active||q.active(save))&&!save.flags['quest-'+q.id]&&!q.done(save));
 for(const id of extra){
  assert.equal(current().id,id);
  save.flags[id]=true;save.flags['quest-'+id]=true;
 }
 assert.equal(current().id,'expedition');
});
test('baseline quests and objects unchanged, storage key and save version unchanged',()=>{
 const extra=new Set(['coastSurvey','westSurvey','ridgeSurvey','surveyNotes','coastCache','westCache','ridgeCache','reedsWest','reedsSouth','clayWest','clayNorth','flintNorth','flintEast','berriesWest','berriesNorth','saltSouth','saltCoast','site-storage','site-dryingRack','site-rainCollector','site-workbench']);
 const newOldQuests=quests.filter(q=>!extra.has(q.id));
 const fmt=qs=>Array.from(qs,q=>({id:q.id,name:q.name,desc:q.desc,target:q.target,xp:q.xp,
   chapter:q.chapter, active:q.active?.toString(),done:q.done?.toString()}));
 assert.deepEqual(fmt(newOldQuests),oldQuests.map(q=>({...q,chapter:q.chapter??undefined,active:q.active??undefined,done:q.done??undefined}))); 
 const newOldObjects=objects.filter(o=>!extra.has(o.id));
 assert.deepEqual(JSON.parse(JSON.stringify(newOldObjects)),JSON.parse(JSON.stringify(oldObjects)));
 const oldKey=baseline.storageKey;
 const newKey=after.match(/const KEY='([^']+)'/)[1];
 assert.equal(newKey,oldKey);
 assert.equal(baseline.baseVersion,Number(after.match(/const BASE=\{version:(\d+)/)[1]));
 assert.match(after,/state\.flags\['quest-'\+id\]=true/);
 assert.match(after,/past\.expedition/);
});
