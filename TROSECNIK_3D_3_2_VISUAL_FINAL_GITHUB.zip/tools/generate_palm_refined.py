#!/usr/bin/env python3
"""GFX14: original mobile-conscious curved coastal palm GLB.
Regenerate with: python tools/generate_palm_gfx14.py
Only static visual GLB is modified. No external assets, textures or downloads.
Coordinates: Y up, base y=0; silhouette fits existing palm world positions.
"""
from collections import defaultdict
from pathlib import Path
import math
import numpy as np
import trimesh
from trimesh.visual.material import PBRMaterial
from trimesh.visual.texture import TextureVisuals

OUT = Path(__file__).resolve().parents[1] / 'assets/models/palm-refined.glb'
GROUP = defaultdict(list)
PALETTE = {
    'trunk': (100, 69, 42, 255),
    'bark_detail': (65, 43, 28, 255),
    'fronds_deep': (39, 81, 41, 255),
    'fronds_lit': (84, 116, 48, 255),
    'coconuts': (91, 67, 37, 255),
}

def add(vertices, faces, group):
    mesh=trimesh.Trimesh(vertices=np.asarray(vertices,dtype=float),
                          faces=np.asarray(faces,dtype=int), process=False)
    GROUP[group].append(mesh)

def branch_center(t):
    return np.array([.09*t+.55*t*t, 6.20*t, -.10*t+.22*t*t],dtype=float)

# One continuous curved, tapered trunk: 12 rings x 10 segments, no 12 separate draw calls.
rings, sides = 13, 10
v=[]; f=[]
for r in range(rings):
    t=r/(rings-1); center=branch_center(t)
    radius=.265*(1-t)**.55+.075
    for j in range(sides):
        a=2*math.pi*j/sides
        bulge=1+.033*math.sin(r*3.6+j*1.9)
        v.append(center+[math.cos(a)*radius*bulge,0,math.sin(a)*radius*bulge])
for r in range(rings-1):
    for j in range(sides):
        a=r*sides+j;b=r*sides+(j+1)%sides;c=(r+1)*sides+j;d=(r+1)*sides+(j+1)%sides
        f.extend([(a,b,c),(b,d,c)])
add(v,f,'trunk')
# Short irregular bark plates (subtle transverse rings) merged into just one detail mesh.
v=[];f=[]
for r in range(1,19):
    t=r/20
    center=branch_center(t)
    base_radius=.265*(1-t)**.55+.075
    for j in range(5):
        a=(j+.3*(r%2))*math.pi*2/5
        rad=base_radius*1.01
        h=.033+.012*((r+j)%3)
        half=.18+(.07 if (j+r)%4==0 else 0)
        x,z=math.cos(a),math.sin(a)
        verts=[center+[rad*math.cos(a-half),-.5*h,rad*math.sin(a-half)],
               center+[(rad+.019)*x,-.5*h,(rad+.019)*z],
               center+[rad*math.cos(a+half),.5*h,rad*math.sin(a+half)],
               center+[(rad+.014)*x,.5*h,(rad+.014)*z]]
        offset=len(v);v+=verts;f += [(offset,offset+1,offset+2),(offset+1,offset+3,offset+2)]
add(v,f,'bark_detail')

# Frond center rib, long lanceolate leaf blade, then fine paired leaflets.
# A small number of continuous material groups replaces the prior 19 individual meshes.
TOP=branch_center(1)
for frond in range(10):
    az=math.tau*frond/10+.08*math.sin(frond*2.1)
    direction=np.array([math.cos(az),0,math.sin(az)])
    across=np.array([-math.sin(az),0,math.cos(az)])
    reach=3.15+(.25 if frond%3==0 else -.08 if frond%4==0 else 0)
    lift=.56+(.16 if frond%3==1 else 0)
    droop=1.62+(.24 if frond%2==0 else -.09)
    def spine(u):
        return TOP + direction*(reach*u) + np.array([0,lift*math.sin(math.pi*u)-droop*u*u-.06*u,0])
    leaf_v=[]; leaf_f=[]
    for i in range(10):
        u=i/9; p=spine(u)
        width=.10+ .76*math.sin(math.pi*u)**.85
        width*=max(.02,1-u**8)
        leaf_v.extend([p+across*width/2,p-across*width/2])
    for i in range(9):
        a=2*i;leaf_f.extend([(a,a+1,a+2),(a+1,a+3,a+2)])
    # Leaflet blades, tapered points, staggered upwards and downwards.
    # All geometry is double sided through PBR material, not duplicate faces.
    for i in range(1,9):
        u=.09+i*.091
        core=spine(u)
        leaf_extent=(.24+.75*math.sin(math.pi*u)**.72)*max(.18,1-.42*u)
        for sign in (-1,1):
            root=core + across*sign*.035
            mid=core+across*sign*(leaf_extent*.57)+direction*(.10+.11*u)+[0,.06-.12*u,0]
            tip=core+across*sign*leaf_extent+direction*(.18+.12*u)+[0,-.07-.18*u,0]
            side=direction*(.075+.05*math.sin(math.pi*u))
            off=len(leaf_v)
            leaf_v += [root-side,root+side,mid-side*.70,mid+side*.70,tip]
            leaf_f += [(off,off+1,off+2),(off+1,off+3,off+2),
                       (off+2,off+3,off+4)]
    add(leaf_v,leaf_f,'fronds_lit' if frond%3 in (0,2) else 'fronds_deep')

# Fruit below crown is a single mesh group; no separate materials per coconut.
for j in range(4):
    a=j*math.tau/4+.35
    fruit=trimesh.creation.icosphere(subdivisions=1,radius=1.)
    fruit.vertices*=np.array([.17,.20,.16])
    fruit.apply_translation(TOP+[.23*math.cos(a),-.36-.06*(j%2),.23*math.sin(a)])
    GROUP['coconuts'].append(fruit)

scene=trimesh.Scene()
for name, parts in GROUP.items():
    mesh=trimesh.util.concatenate(parts)
    mesh.visual=TextureVisuals(material=PBRMaterial(
        name=name,baseColorFactor=PALETTE[name],metallicFactor=0,
        roughnessFactor=.92 if name.startswith('fronds') else .98,
        doubleSided=True))
    scene.add_geometry(mesh,node_name=name,geom_name=name)
OUT.write_bytes(scene.export(file_type='glb'))
print('GFX14 PALM',OUT,'bytes',OUT.stat().st_size,
      'meshes',len(scene.geometry),
      'triangles',sum(len(g.faces) for g in scene.geometry.values()),
      'bounds',scene.bounds.tolist())
