#!/usr/bin/env python3
"""Offline orthographic still from the real GLB triangles/materials, NOT a gameplay capture.

Simple painter-style projection is intended only to compare embedded materials;
it is not physically based WebGL and does not evaluate rig animation.
"""
from pathlib import Path
import io
import json
import math
import struct
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import trimesh

ROOT=Path(__file__).resolve().parents[1]
OUTPUT=ROOT/'graphics/previews/robinson-gfx11-offline.png'
W,H=1300,830

def model(path):
    raw=path.read_bytes();ln=struct.unpack_from('<I',raw,12)[0]
    g=json.loads(raw[20:20+ln]);bin_len=struct.unpack_from('<I',raw,20+ln)[0]
    binary=raw[28+ln:28+ln+bin_len]
    images=[]
    for im in g.get('images',[]):
        bv=g['bufferViews'][im['bufferView']];start=bv.get('byteOffset',0)
        images.append(Image.open(io.BytesIO(binary[start:start+bv['byteLength']])).convert('RGB'))
    textures=[]
    for t in g.get('textures',[]):textures.append(np.asarray(images[t['source']]))
    scene=trimesh.load(path,force='scene')
    return g,textures,scene

def render(path,at_x,title):
    g,tex,scene=model(path)
    a=math.radians(22)
    forward=np.array([math.sin(a),.05,math.cos(a)])
    right=np.array([math.cos(a),0,-math.sin(a)])
    colorlight=np.array([.3,.8,.45]);colorlight/=np.linalg.norm(colorlight)
    project=[]
    scale=258
    cx=at_x+330;cy=H-100
    for name in scene.graph.nodes_geometry:
        matrix, geom_name=scene.graph[name]
        geo=scene.geometry[geom_name]
        # Each glTF mesh is imported as GLTF_N, but names may be disambiguated.
        if not geom_name.startswith('GLTF_'):continue
        mesh_index=int(geom_name.split('_')[1])
        prim=g['meshes'][mesh_index]['primitives'][0]
        mat=g['materials'][prim.get('material',0)]
        factor=np.array(mat.get('pbrMetallicRoughness',{}).get('baseColorFactor',[1.,1.,1.,1.])[:3],dtype=float)
        image_index=mat.get('pbrMetallicRoughness',{}).get('baseColorTexture',{}).get('index')
        image=tex[g['textures'][image_index]['source']] if image_index is not None else None
        uv=geo.visual.uv if hasattr(geo.visual,'uv') else None
        vertex_colors=np.asarray(geo.visual.vertex_colors)[:,:3]/255. if geo.visual.kind=='vertex' else None
        verts=trimesh.transform_points(geo.vertices,matrix)
        normals=trimesh.transform_points(geo.vertices+geo.vertex_normals,matrix)-verts
        xy=np.column_stack((cx+verts@right*scale,cy-verts[:,1]*scale))
        depth=verts@forward
        for tri in geo.faces:
            n=normals[tri].mean(axis=0)
            n/=max(np.linalg.norm(n),1e-5)
            # Discard back-facing triangles but preserve two-sided hair strands.
            if float(n@forward)<-.08:continue
            diffuse=.53+.47*max(0,float(n@colorlight))
            col=factor.copy()*diffuse
            if image is not None and uv is not None:
                texcoord=uv[tri].mean(axis=0)%1
                tx=min(image.shape[1]-1,int(texcoord[0]*(image.shape[1]-1)))
                ty=min(image.shape[0]-1,int((1-texcoord[1])*(image.shape[0]-1)))
                col*=image[ty,tx,:3]/255.
            if vertex_colors is not None:col*=vertex_colors[tri].mean(axis=0)
            col=tuple(np.uint8(np.clip(col*255,0,255)).tolist())
            project.append((float(depth[tri].mean()),tuple(map(tuple,xy[tri])),col))
    project.sort(key=lambda entry:entry[0])
    for _,pts,col in project:
        dr.polygon(pts,fill=col)
    dr.text((at_x+20,40),title,fill=(237,222,182),font=font)
    dr.text((at_x+20,H-65),'Skutečná GLB geometrie · offline náhled',fill=(177,191,193),font=small)

img=Image.new('RGB',(W,H),(18,27,29));dr=ImageDraw.Draw(img)
for y in range(H):
    k=y/H;dr.line([(0,y),(W,y)],fill=(int(14+17*k),int(23+17*k),int(28+9*k)))
try:
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',24)
    small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',14)
except OSError:
    font=ImageFont.load_default();small=font
render(ROOT/'assets/models/robinson_base.glb',0,'GFX 10 · původní materiály')
render(ROOT/'assets/models/robinson.glb',650,'GFX 11 · textury materiálů')
dr.line([(649,20),(649,H-20)],fill=(153,120,77),width=2)
OUTPUT.parent.mkdir(parents=True,exist_ok=True)
img.save(OUTPUT,optimize=True)
print('Offline model preview:',OUTPUT)
