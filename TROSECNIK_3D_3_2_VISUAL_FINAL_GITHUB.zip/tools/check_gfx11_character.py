#!/usr/bin/env python3
"""Offline structural tests for actual GFX11 asset, not a WebGL visual test."""
from pathlib import Path
import importlib.util
import io
import json
import struct
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'assets/models/robinson_base.glb'
NEW=ROOT/'assets/models/robinson.glb'


def unpack(path):
    b=path.read_bytes();assert b[:4]==b'glTF' and struct.unpack_from('<II',b,4)==(2,len(b))
    off=12; data={}; raw=None
    while off<len(b):
        length,kind=struct.unpack_from('<II',b,off);off+=8
        chunk=b[off:off+length];off+=length
        assert len(chunk)==length
        if kind==0x4E4F534A:data=json.loads(chunk)
        if kind==0x004E4942:raw=chunk
    assert off==len(b)
    assert data['buffers'][0]['byteLength']<=len(raw)
    return data,raw

old,old_bin=unpack(BASE); new,new_bin=unpack(NEW)
assert new_bin[:len(old_bin)]==old_bin,'original mesh + animations binary must remain identical'
for k in ('nodes','accessors','animations','skins','scenes','scene'):
    assert old.get(k)==new.get(k),k
assert len(old['meshes'])==len(new['meshes'])==54
expected=['Idle','Walk','Run','Gather','Chop','Build','Drink','Rest']
assert [a['name'] for a in old['animations']]==[a['name'] for a in new['animations']]==expected
textures=0
for previous,current in zip(old['meshes'],new['meshes']):
    for p,q in zip(previous['primitives'],current['primitives']):
        assert p['attributes']==q['attributes']
        assert p.get('indices')==q.get('indices')
        assert p.get('mode')==q.get('mode')
        if p['material'] != q['material']:
            assert 'TEXCOORD_0' in p['attributes']
            mat=new['materials'][q['material']]
            tid=mat['pbrMetallicRoughness']['baseColorTexture']['index']
            assert tid<len(new['textures'])
            textures+=1
for im in new['images']:
    if 'bufferView' not in im: continue
    view=new['bufferViews'][im['bufferView']]
    start=view.get('byteOffset',0);length=view['byteLength']
    assert start>=0 and start+length<=len(new_bin)
    with Image.open(io.BytesIO(new_bin[start:start+length])) as image:
        assert image.width>0 and image.height>0
for texture in new['textures']:
    assert texture['source']<len(new['images'])
    if 'sampler' in texture:assert texture['sampler']<len(new['samplers'])
assert textures>=15
code=(ROOT/'src/renderer.js').read_text()
assert "return this.loadHero('assets/models/robinson_base.glb')" in code
assert (ROOT/'src/game_logic.js').read_bytes() == (Path('/mnt/data/trosecnik_gfx10_work/src/game_logic.js')).read_bytes()
print('PASS: original GLB binary unchanged, 8 animation clips and all 54 meshes preserved')
print(f'PASS: {textures} existing UV-mapped mesh primitives now use embedded material detail')
print('PASS: all embedded images, bufferViews and texture references decode and fit the GLB')
print('PASS: renderer original GLB fallback present; game logic matches GFX10 byte-for-byte')
