import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInNewContext} from 'node:vm';
import {fileURLToPath} from 'node:url';
import {resolve,dirname} from 'node:path';
import {STORABLE, inventoryLoad, carryCapacity, movementLoadFactor, STORAGE_CAPACITY,transfer} from '../src/camp_logistics.js';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const source=readFileSync(resolve(root,'src/game_logic.js'),'utf8');
const old=readFileSync(resolve(root,'tools/fixtures/survival21_game_logic.js'),'utf8');
const readValue=(code,begin,end)=>{let i=code.indexOf(begin),j=code.indexOf(end,i);assert.ok(i>=0&&j>i,begin);return runInNewContext('('+code.slice(i+begin.length,j).trim().replace(/;$/,'')+')');};
const base=readValue(source,'const BASE=',';\nconst ITEM=');
const builds=readValue(source,'const BUILD=',';\nconst OBJ=');
const objects=readValue(source,'const OBJ=',';\nconst TUTORIAL_IDS=');
const recipes=readValue(source,'const RECIPES=',';\nfunction makeRecipe');

test('new 3.0 storage and backpack have a real world site, three-stage materials and crafting recipe',()=>{
  const chest=objects.filter(o=>o.id==='site-storage');
  assert.equal(chest.length,1);
  assert.equal(chest[0].site,'storage');
  assert.equal(chest[0].type,'site');
  assert.ok(Math.hypot(chest[0].x+4,chest[0].z+2)<8);
  assert.deepEqual(JSON.parse(JSON.stringify(builds.storage.needs)),{wood:5,fiber:3,stone:2});
  assert.equal(base.built.storage,0);
  assert.deepEqual(JSON.parse(JSON.stringify(base.storage)),{});
  const pack=recipes.find(r=>r.id==='fieldPack');
  assert.equal(pack.once,true);
  assert.equal(pack.flag,'craftedFieldPack');
  assert.equal(pack.visible({flags:{craftedCord:true}}),true);
  assert.ok(Object.keys(pack.cost).length>=3);
  assert.match(source,/else if\(site==='storage'\)\{openPanel\('storage'\)\}/);
  assert.match(source,/if\(o\.site==='storage'\)\{shape\('box'/);
});

test('old save key, version, objectives and authored core build costs remain intact',()=>{
  assert.equal(source.match(/const KEY='([^']+)'/)[1],old.match(/const KEY='([^']+)'/)[1]);
  assert.equal(base.version,2);
  assert.match(source,/storage:\{\.\.\.\(a\?\.storage\|\|\{\}\)\}/);
  const originalBuild=readValue(old,'const BUILD=',';\nconst OBJ=');
  for(const [id,def] of Object.entries(originalBuild))assert.deepEqual(JSON.parse(JSON.stringify(builds[id])),JSON.parse(JSON.stringify(def)),id);
  assert.ok(!STORABLE.includes('core')&&!STORABLE.includes('chart')&&!STORABLE.includes('fieldPack'));
  assert.match(source,/if\(pane!=='storage'\|\|state\.built\.storage!==3\|\|d2\(hero,\{x:-5\.9,z:3\.1\}\)>3\.0\)return/);
});

test('storing and collecting ordinary resources conserves quantity and cannot create items',()=>{
 const bag={wood:10,stone:2},storage={wood:1};
 assert.equal(transfer(bag,storage,'wood',4,'deposit'),4);
 assert.equal(bag.wood,6);assert.equal(storage.wood,5);
 assert.equal(transfer(bag,storage,'wood',2,'withdraw'),2);
 assert.equal(bag.wood,8);assert.equal(storage.wood,3);
 assert.equal(transfer(bag,storage,'wood',20,'withdraw'),3);
 assert.equal(bag.wood,11);assert.equal(storage.wood,0);
 assert.equal(transfer(bag,storage,'wood',1,'withdraw'),0);
 assert.equal(bag.wood,11);
});

test('storage capacity clamps partial deposits without destroying untransferred stock',()=>{
 const bag={stone:10},storage={wood:58}; // load 116 / 120
 assert.equal(inventoryLoad(storage),116);
 assert.equal(transfer(bag,storage,'stone',10,'deposit'),2);
 assert.equal(inventoryLoad(storage),STORAGE_CAPACITY);
 assert.equal(bag.stone,8);assert.equal(storage.stone,2);
 assert.equal(transfer(bag,storage,'stone',1,'deposit'),0);
 assert.equal(bag.stone,8);
});

test('quest items, weapons, completed pack and invalid requests never enter storage',()=>{
 const bag={core:1,chart:1,axe:1,fieldPack:1,wood:1},storage={};
 for(const id of ['core','chart','axe','fieldPack','constructor','__proto__'])assert.equal(transfer(bag,storage,id,1,'deposit'),0,id);
 for(const amount of [0,-1,1.5,Infinity,NaN])assert.equal(transfer(bag,storage,'wood',amount,'deposit'),0,String(amount));
 assert.equal(transfer(bag,storage,'wood',1,'drop'),0);
 assert.equal(bag.wood,1);assert.deepEqual(storage,{});
});

test('backpack modifies comfortable load, excess slows down without blocking gathering',()=>{
 const bag={wood:15};assert.equal(inventoryLoad(bag),30);
 assert.equal(carryCapacity(bag),28);
 const overloaded=movementLoadFactor(bag);assert.ok(overloaded<1&&overloaded>=.55);
 bag.fieldPack=1;assert.equal(carryCapacity(bag),46);
 assert.equal(movementLoadFactor(bag),1);
 bag.wood=200;assert.equal(movementLoadFactor(bag),.55);
 assert.match(source,/movementLoadFactor\(state\.bag\)/);
});

test('storage action requires being beside built chest; transfer persists in save',()=>{
 const start=source.indexOf('function panelAction(action){');
 const stop=source.indexOf("if(action.startsWith('cipher-'))",start);
 assert.ok(start>0&&stop>start);
 const section=source.slice(start+'function panelAction(action){'.length,stop);
 const state={bag:{wood:4},storage:{},built:{storage:3}};
 let pane='storage',distance=0,saved=0,updated=0;
 const sandbox={state,transfer,STORABLE,ITEM:{wood:['🪵','Dřevo']},pane,d2:()=>distance,hero:{},save:()=>{saved++;},renderPane:()=>{},updateUI:()=>{updated++;},flash:()=>{},changed:false};
 const action=runInNewContext('(function panelAction(action){'+section+'})',sandbox);
 action('store-put-wood-1');assert.equal(state.bag.wood,3);assert.equal(state.storage.wood,1);assert.equal(saved,1);
 distance=20;action('store-put-wood-1');assert.equal(state.storage.wood,1);assert.equal(saved,1);
 distance=0;state.built.storage=2;action('store-put-wood-1');assert.equal(state.storage.wood,1);assert.equal(saved,1);
 state.built.storage=3;action('store-get-wood-all');assert.equal(state.storage.wood,0);assert.equal(state.bag.wood,4);
 assert.equal(saved,2);assert.equal(updated,2);
});

test('storage inventory is per save position and exported with existing full-state backup',()=>{
 assert.match(source,/storage:\{\.\.\.\(a\?\.storage\|\|\{\}\)\}/);
 assert.match(source,/slots\[slot\]=copy\(state\)/);
 assert.match(source,/JSON\.stringify\(\{game:'TROSECNIK_3D_2_0',slot,state\}/);
 assert.match(source,/function makeRecipe\(id\)/);
});
