import test from 'node:test';
import assert from 'node:assert/strict';
import {computeQuestPointer} from '../src/quest_pointer.js';

const hero={x:0,y:0,z:0};
const focus={eye:[0,4,8],right:[1,0,0],up:[0,.9363291776,-.3511234416],forward:[0,-.3511234416,-.9363291776],fov:68};
const portrait={width:390,height:844};
const landscape={width:844,height:390};
const target=(x,z)=>({x,z,r:.85});

for(const viewport of [portrait,landscape]){
 test(`above-head marker remains on-screen at ${viewport.width}×${viewport.height}`,()=>{
  const pose=computeQuestPointer(hero,target(10,0),focus,viewport);
  assert.ok(pose);
  assert.ok(pose.left>0&&pose.left<viewport.width);
  assert.ok(pose.top>0&&pose.top<viewport.height);
  assert.ok(Math.abs(pose.angle-90)<.01);
 });
 test(`north/south/west objective directions match visible arrows at ${viewport.width}×${viewport.height}`,()=>{
  assert.ok(Math.abs(computeQuestPointer(hero,target(0,-10),focus,viewport).angle)<.01);
  assert.ok(Math.abs(Math.abs(computeQuestPointer(hero,target(0,10),focus,viewport).angle)-180)<.01);
  assert.ok(Math.abs(computeQuestPointer(hero,target(-10,0),focus,viewport).angle+90)<.01);
 });
}
test('turning the camera changes the screen arrow angle, not the world target',()=>{
 const side={eye:[8,4,0],right:[0,0,-1],up:[-.3511234416,.9363291776,0],forward:[-.9363291776,-.3511234416,0],fov:68};
 const before=computeQuestPointer(hero,target(0,-10),focus,portrait);
 const after=computeQuestPointer(hero,target(0,-10),side,portrait);
 assert.ok(before&&after);
 assert.ok(Math.abs(before.angle)<.01);
 assert.ok(Math.abs(after.angle-90)<.01);
});
test('hide only in action range or when target is missing; behind-camera target remains directional',()=>{
 assert.equal(computeQuestPointer(hero,target(.8,0),focus,portrait),null);
 assert.equal(computeQuestPointer(hero,null,focus,portrait),null);
 assert.ok(computeQuestPointer(hero,target(5,0),{...focus,eye:[0,4,-8],forward:[0,-.3511234416,-.9363291776]},portrait));
 assert.ok(computeQuestPointer({x:0,y:500,z:0},target(5,0),focus,portrait));
});
test('does not mutate position, target, camera or viewport',()=>{
 const h={...hero},t=target(10,1),cam=structuredClone(focus),screen={...portrait};
 computeQuestPointer(h,t,cam,screen);
 assert.deepEqual(h,hero);assert.deepEqual(t,target(10,1));assert.deepEqual(cam,focus);assert.deepEqual(screen,portrait);
});
