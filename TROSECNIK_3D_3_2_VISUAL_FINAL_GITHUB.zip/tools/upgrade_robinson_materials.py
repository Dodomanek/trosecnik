#!/usr/bin/env python3
"""GFX11: make original, royalty-free, embedded microdetail PBR textures for animated Robinson.

Preserves the original mesh geometry, hierarchy, object names and all animation channels.
Textures only apply to primitives that already have TEXCOORD_0. The base GLB remains
available as a renderer fallback. The character is still segmented, NOT skinned.
"""
from __future__ import annotations
import copy
import io
import json
import math
from pathlib import Path
import random
import struct

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'assets/models/robinson_base.glb'
OUT = ROOT / 'assets/models/robinson.glb'
SIZE = 256
PROFILES = {
    0: ('sun-worn skin', 'skin', 1001, .89),
    1: ('weathered linen', 'linen', 1002, .82),
    2: ('salt-stained trousers', 'pants', 1003, .80),
    3: ('sun-bleached hair', 'hair', 1004, .86),
    4: ('worn hide satchel', 'leather', 1005, .80),
    6: ('hemp rope', 'rope', 1006, .79),
}


def parse_glb(path):
    raw = path.read_bytes()
    if len(raw) < 20 or raw[:4] != b'glTF' or struct.unpack_from('<II', raw, 4) != (2, len(raw)):
        raise ValueError('Incorrect GLB header')
    offset = 12; chunks = []
    while offset + 8 <= len(raw):
        length, kind = struct.unpack_from('<II', raw, offset); offset += 8
        if offset + length > len(raw): raise ValueError('GLB chunk overrun')
        chunks.append((kind, raw[offset:offset + length])); offset += length
    if offset != len(raw) or len(chunks) != 2 or chunks[0][0] != 0x4E4F534A or chunks[1][0] != 0x004E4942:
        raise ValueError('Expected JSON and BIN chunks')
    gltf = json.loads(chunks[0][1].decode('utf-8').strip())
    return gltf, bytearray(chunks[1][1])


def texture(kind, seed, floor):
    """Small deterministic grayscale modulation atlas, no third-party photos or licenses."""
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[:SIZE, :SIZE]
    coarse = rng.uniform(-1, 1, size=(32, 32))
    medium = rng.uniform(-1, 1, size=(64, 64))
    coarse = np.repeat(np.repeat(coarse, 8, axis=0), 8, axis=1)
    medium = np.repeat(np.repeat(medium, 4, axis=0), 4, axis=1)
    fine = rng.normal(0, .26, size=(SIZE, SIZE))
    value = .94 + .042 * coarse + .023 * medium + .037 * fine
    if kind == 'linen':
        # Visible only close to the camera; threads are not a painted 2D silhouette.
        weave = (np.sin(xx * 2.25) * np.sin(yy * 2.1) + .5 * np.sin(xx * .64))
        value -= .028 * (weave + 1.) / 2.
        value -= .075 * ((np.sin(xx*.025 + yy*.043) > .976).astype(float))
    elif kind == 'pants':
        value -= .028 * (np.sin(yy * 1.45) + 1.) / 2.
        value -= .07 * np.maximum(0, np.sin(xx * .074 + yy * .12)) ** 12
    elif kind == 'leather':
        pores = rng.random((SIZE, SIZE))
        value -= .08 * (pores > .955)
        value -= .06 * (np.sin(xx*.14+yy*.08) > .991)
    elif kind == 'hair':
        value -= .065 * (np.sin(xx * .85 + yy*.03) + 1.) / 2.
    elif kind == 'skin':
        value = .967 + .018 * coarse + .012 * medium + .018 * fine
        value -= .023 * (rng.random((SIZE, SIZE)) > .98)
    elif kind == 'rope':
        value -= .075 * (np.sin((xx + yy*.60) * .60) + 1.) / 2.
        value -= .035 * (np.sin(yy * 1.55) + 1.) / 2.
    value = np.clip(value, floor, 1.0)
    # Neutral variations retain original material color and baked vertex colors.
    gray = np.uint8(np.rint(value * 255))
    image = Image.fromarray(np.stack((gray, gray, gray), axis=2), 'RGB')
    stream = io.BytesIO(); image.save(stream, format='PNG', optimize=True)
    return stream.getvalue()


def pad4(buf):
    while len(buf) % 4: buf.append(0)


def build():
    gltf, binary = parse_glb(BASE)
    before = {
        'nodes': copy.deepcopy(gltf.get('nodes')),
        'meshes': copy.deepcopy(gltf.get('meshes')),
        'animations': copy.deepcopy(gltf.get('animations')),
        'accessors': copy.deepcopy(gltf.get('accessors')),
    }
    gltf.setdefault('images', [])
    gltf.setdefault('textures', [])
    gltf.setdefault('samplers', [])
    gltf.setdefault('bufferViews', [])
    sampler_id = len(gltf['samplers'])
    gltf['samplers'].append({'magFilter': 9729, 'minFilter': 9987, 'wrapS': 10497, 'wrapT': 10497})
    new_mats = {}
    material_primitives = {}
    for material_id, (label, kind, seed, floor) in PROFILES.items():
        png = texture(kind, seed, floor)
        pad4(binary)
        view_id = len(gltf['bufferViews'])
        gltf['bufferViews'].append({'buffer': 0, 'byteOffset': len(binary), 'byteLength': len(png)})
        binary.extend(png); pad4(binary)
        image_id = len(gltf['images'])
        gltf['images'].append({'name': 'Original procedural material: ' + label, 'bufferView': view_id, 'mimeType': 'image/png'})
        tex_id = len(gltf['textures'])
        gltf['textures'].append({'name': label + ' microtexture', 'sampler': sampler_id, 'source': image_id})
        original = gltf['materials'][material_id]
        updated = copy.deepcopy(original)
        updated['name'] = (original.get('name', label) + ' | GFX11 fabric detail')
        pbr = updated.setdefault('pbrMetallicRoughness', {})
        pbr['baseColorTexture'] = {'index': tex_id, 'texCoord': 0}
        # Rough surfaces, no additional normal/metal maps (mobile GPU memory).
        pbr['roughnessFactor'] = {
            'skin': .91, 'linen': .97, 'pants': .96, 'hair': .91,
            'leather': .86, 'rope': .98,
        }[kind]
        pbr['metallicFactor'] = 0.0
        new_id = len(gltf['materials'])
        gltf['materials'].append(updated)
        new_mats[material_id] = new_id
        material_primitives[material_id] = 0

    for mesh in gltf['meshes']:
        for prim in mesh['primitives']:
            material = prim.get('material')
            if material in new_mats and 'TEXCOORD_0' in prim.get('attributes', {}):
                prim['material'] = new_mats[material]
                material_primitives[material] += 1

    if not all(material_primitives.values()):
        raise AssertionError('Expected materials must occur on at least one UV-mapped primitive: ' + str(material_primitives))
    gltf['buffers'][0]['byteLength'] = len(binary)
    json_chunk = json.dumps(gltf, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    json_chunk += b' ' * ((-len(json_chunk)) % 4)
    binary_chunk = bytes(binary)
    size = 12 + 8 + len(json_chunk) + 8 + len(binary_chunk)
    out = bytearray(struct.pack('<4sII', b'glTF', 2, size))
    out += struct.pack('<II', len(json_chunk), 0x4E4F534A) + json_chunk
    out += struct.pack('<II', len(binary_chunk), 0x004E4942) + binary_chunk
    OUT.write_bytes(out)

    reread, _ = parse_glb(OUT)
    # Change permitted only for material references; animation tracks, nodes and
    # original vertex data must be unchanged. A changed material per primitive is intended.
    for key in ('nodes', 'animations', 'accessors'):
        assert reread[key] == before[key], key
    original_prims = [p for m in before['meshes'] for p in m['primitives']]
    updated_prims = [p for m in reread['meshes'] for p in m['primitives']]
    assert len(original_prims) == len(updated_prims)
    for old, new in zip(original_prims, updated_prims):
        for key in set(old) | set(new):
            if key != 'material': assert old.get(key) == new.get(key), key
    assert reread['animations'] and len(reread['animations']) == 8
    assert reread['buffers'][0]['byteLength'] == len(binary_chunk)
    print(f'Generated: {OUT.name}: {OUT.stat().st_size:,} bytes')
    print('UV-mapped primitives upgraded:', material_primitives)
    print('Original animation clips, hierarchy, geometry and existing face texture: unchanged')


if __name__ == '__main__': build()
