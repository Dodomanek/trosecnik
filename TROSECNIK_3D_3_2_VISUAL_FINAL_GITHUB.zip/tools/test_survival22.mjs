import {recipeCost, missingIngredients} from '../src/survival32.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {runInNewContext} from 'node:vm';
import {resourceAvailable,recordGather,gatherCooldown} from '../src/resource_rules.js';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const src=readFileSync(resolve(root,'src/game_logic.js'),'utf8');
const old=readFileSync(resolve(root,'tools/fixtures/survival21_game_logic.js'),'utf8');
const data=(source,start,end)=>{let i=source.indexOf(start),j=source.indexOf(end,i);assert.ok(i>=0&&j>i,`missing ${start}`);return runInNewContext('('+source.slice(i+start.length,j).trim().replace(/;$/,'')+')');};
const objects=data(src,'const OBJ=',';\nconst TUTORIAL_IDS=');
const originalObjects=data(old,'const OBJ=',';\nconst TUTORIAL_IDS=');
const recipes=data(src,'const RECIPES=',';\nfunction makeRecipe');
const oldQuests=data(old,'const QUESTS=',';\nconst BUILD=');
const quests=data(src,'const QUESTS=',';\nconst BUILD=');
const newMaterials=['reeds','clay','flint','berries','salt'];
const newRecipes=['trailSnack','fishJerky','herbalPoultice','clayFlask','reedMat','flintBlade'];
const nodes=objects.filter(o=>newMaterials.includes(o.type));
const json=x=>JSON.parse(JSON.stringify(x));

test('five new harvestable materials have two remote nodes each, not near the starter camp',()=>{
 assert.equal(nodes.length,10);
 for(const k of newMaterials){
  const group=nodes.filter(n=>n.type===k);
  assert.equal(group.length,2,k);
  for(const n of group){assert.ok(Math.hypot(n.x+4,n.z+2)>24,n.id);assert.ok(n.repeat>=300);}
 }
 const same=objects.filter(o=>!newMaterials.includes(o.type)&&!['site-storage','site-dryingRack','site-rainCollector','site-workbench'].includes(o.id));
 assert.deepEqual(json(same),json(originalObjects));
 assert.deepEqual(json(quests.map(q=>({id:q.id,name:q.name,desc:q.desc,target:q.target,xp:q.xp}))),json(oldQuests.map(q=>({id:q.id,name:q.name,desc:q.desc,target:q.target,xp:q.xp}))));
});
test('new harvestables do not respawn immediately and starter restrictions still apply',()=>{
 for(const node of nodes){
  const flags={};
  assert.equal(resourceAvailable(node,flags,200),true);
  recordGather(node,flags,200);
  assert.equal(resourceAvailable(node,flags,201),false,node.id);
  assert.equal(resourceAvailable(node,flags,200+gatherCooldown(node)-1),false,node.id);
  assert.equal(resourceAvailable(node,flags,200+gatherCooldown(node)),true,node.id);
 }
 assert.equal(resourceAvailable({id:'driftwood',type:'wood',repeat:55},{'campHarvest-driftwood':3},1e7),false);
});
test('six new recipes have real costs, new craft IDs and save schema remains compatible',()=>{
 assert.deepEqual(Array.from(recipes.filter(r=>newRecipes.includes(r.id)).map(r=>r.id)),newRecipes);
 for(const item of newRecipes){const r=recipes.find(x=>x.id===item);assert.ok(r&&Object.keys(r.cost).length>=2);assert.ok(Object.values(r.cost).every(Number.isInteger));}
 assert.equal(src.match(/const KEY='([^']+)'/)[1],old.match(/const KEY='([^']+)'/)[1]);
 assert.equal(src.match(/const BASE=\{version:(\d+)/)[1],old.match(/const BASE=\{version:(\d+)/)[1]);
 const baseBag=data(src,'const BASE=',';\nconst ITEM=').bag;
 const oldBag=data(old,'const BASE=',';\nconst ITEM=').bag;
 assert.deepEqual(Object.keys(oldBag).filter(k=>!(k in baseBag)),[]);
 for(const id of [...newMaterials,...newRecipes])assert.ok(id in baseBag,id);
});
test('new gather callback grants correct material then applies saved cooldown',()=>{
 const a=src.indexOf("else if(['reeds','clay','flint','berries','salt'].includes(type))");
 const b=src.indexOf("else if(type==='wood'||type==='stone'",a);
 assert.ok(a>0&&b>a);
 const code=src.slice(a,b).replace(/^else /,'').trim().replace(/;$/,'');
 for(const item of newMaterials){
  const obj=nodes.find(o=>o.type===item);
  const state={bag:{flintBlade:0},flags:{},seconds:1000};
  const awarded=[];let saves=0;
  const env={type:item,o:obj,state,objectAvailable:()=>resourceAvailable(obj,state.flags,state.seconds),finishAction:(o,k,fn)=>fn(),add:(k,n)=>{awarded.push([k,n]);state.bag[k]=(state.bag[k]||0)+n;},recordGather,checkWorkshopGoals:()=>{},checkQuest:()=>{},save:()=>{saves++;}};
  runInNewContext(code,env);
  assert.deepEqual(awarded,[[item,1]]);
  assert.equal(state.flags['found-'+item],true);
  assert.equal(resourceAvailable(obj,state.flags,1001),false);
  assert.equal(saves,1);
  runInNewContext(code,env);
  assert.equal(awarded.length,1,'cannot double collect before cooldown');
 }
});
test('crafting once-only flask spends materials once and cannot duplicate item',()=>{
 const a=src.indexOf('function makeRecipe(id)'),b=src.indexOf('function checkWorkshopGoals()',a);
 const code=src.slice(a,b);
 assert.ok(a>0&&b>a);
 const state={bag:{clay:4,reeds:4,cord:2},flags:{craftedCord:true},built:{fire:0},journal:[]};
 const context={recipeCost,missingIngredients,RECIPES:recipes,state,has:items=>Object.entries(items).every(([k,n])=>(state.bag[k]||0)>=n),spend:items=>{if(!Object.entries(items).every(([k,n])=>(state.bag[k]||0)>=n))return false;for(const [k,n] of Object.entries(items))state.bag[k]-=n;return true;},add:(k,n=1)=>{state.bag[k]=(state.bag[k]||0)+n;},writeStory:()=>{},checkWorkshopGoals:()=>{},checkQuest:()=>{},save:()=>{},renderPane:()=>{},flash:()=>{},costs:()=>''};
 const craft=runInNewContext(code+'\nmakeRecipe',context);
 craft('clayFlask');assert.equal(state.bag.clayFlask,1);assert.equal(state.flags.craftedClayFlask,true);
 assert.equal(state.bag.clay,2);
 craft('clayFlask');assert.equal(state.bag.clayFlask,1);assert.equal(state.bag.clay,2);
});
test('all five consumable effects are defined and empty flask cannot refill from thin air',()=>{
 const a=src.indexOf("if(action.startsWith('use-')){",src.indexOf('function panelAction('));
 const b=src.indexOf("if(action==='useHerb')",a);
 assert.ok(a>0&&b>a);
 const chunk=src.slice(a,b);
 const state={bag:{trailSnack:1,fishJerky:1,herbalPoultice:1,reedMat:1,clayFlask:1},flags:{flaskFilled:false},food:20,energy:20,hp:25,exposure:75,water:20};
 let saves=0;
 const ctx={state,clamp:(n,a,b)=>Math.min(b,Math.max(a,n)),changed:false,flash:()=>{},ITEM:{trailSnack:['','snack'],fishJerky:['','jerky'],herbalPoultice:['','poultice'],reedMat:['','mat'],clayFlask:['','flask']},checkQuest:()=>{},save:()=>{saves++;},renderPane:()=>{},updateUI:()=>{}};
 const action=runInNewContext('(function(action){'+chunk+'})',ctx);
 action('use-clayFlask');assert.equal(state.water,20);assert.equal(saves,0);
 state.flags.flaskFilled=true;action('use-clayFlask');assert.equal(state.water,58);assert.equal(state.bag.clayFlask,1);assert.equal(state.flags.flaskFilled,false);
 action('use-trailSnack');assert.equal(state.food,47);assert.equal(state.energy,36);assert.equal(state.bag.trailSnack,0);
 action('use-fishJerky');assert.equal(state.food,86);assert.equal(state.energy,45);
 action('use-herbalPoultice');assert.equal(state.hp,57);assert.equal(state.exposure,40);
 action('use-reedMat');assert.equal(state.energy,63);assert.equal(state.exposure,10);
 assert.equal(saves,5);
});
test('optional exploration awards are each saved once and cannot farm XP',()=>{
 const a=src.indexOf('function checkWorkshopGoals()'),b=src.indexOf('function consumeFood()',a);
 const state={flags:{},journal:[],day:3};let xp=0;
 const f=runInNewContext(src.slice(a,b)+'\ncheckWorkshopGoals',{state,awardXP:(n)=>{xp+=n;},changed:false});
 f();assert.equal(xp,0);
 for(const id of newMaterials)state.flags['found-'+id]=true;
 f();assert.equal(xp,45);
 state.flags.craftedClayFlask=true;
 for(const item of ['trailSnack','fishJerky','herbalPoultice'])state.flags['crafted-'+item]=true;
 f();assert.equal(xp,175);f();assert.equal(xp,175);
 assert.equal(state.journal.length,3);
});
