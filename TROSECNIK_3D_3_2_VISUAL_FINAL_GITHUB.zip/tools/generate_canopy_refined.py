"""Render-only refinement of supplied GFX20 canopy: same approximate footprint,
branched trunk and individual convex leaves. Original GFX20 is kept as fallback.
Run with Python, numpy and trimesh.
"""
from pathlib import Path
import numpy as np
import trimesh
from trimesh.visual.material import PBRMaterial
from trimesh.visual.texture import TextureVisuals
rng=np.random.default_rng(32026)
parts={'bark':[], 'leaf_dark':[], 'leaf_mid':[], 'leaf_sun':[]}
def branch(a,b,r1,r2):
 a,b=np.array(a),np.array(b);d=b-a;l=np.linalg.norm(d)
 m=trimesh.creation.conical_frustum(r1,r2,l,sections=9) if hasattr(trimesh.creation,'conical_frustum') else trimesh.creation.cylinder(radius=r1,height=l,sections=9)
 mat=trimesh.geometry.align_vectors([0,0,1],d/l);m.apply_transform(mat);m.apply_translation((a+b)/2);parts['bark'].append(m)
branch([0,0,0],[.08,3.5,.12],.25,.12)
for j in range(9):
 a=j*2.399;x,z=np.cos(a),np.sin(a);h=2.2+j*.15
 branch([.04,h,.06],[x*1.2,h+.8,z*1.2],.095,.027)
 branch([x*.8,h+.5,z*.8],[x*1.65,h+.75,z*1.65],.035,.014)
# Leaves fill overlapping, uneven ellipsoidal crowns; no solid spherical shells.
for i in range(640):
 a=rng.uniform(0,2*np.pi);rr=np.sqrt(rng.uniform())*2.15
 x,z=np.cos(a)*rr,np.sin(a)*rr;y=3.65+rng.uniform(-.7,.95)*(1-.2*rr)+.32*np.sin(a*3)
 length=rng.uniform(.30,.68);width=length*rng.uniform(.34,.55)
 ang=a+rng.uniform(-1.1,1.1);d=np.array([np.cos(ang),rng.uniform(-.32,.18),np.sin(ang)]);side=np.array([-np.sin(ang),0,np.cos(ang)])
 root=np.array([x,y,z]);mid=root+d*length*.48;tip=root+d*length
 verts=np.array([root,mid-side*width*.5,mid+np.array([0,.045,0]),mid+side*width*.5,tip]);faces=[[0,1,2],[0,2,3],[1,4,2],[2,4,3]]
 m=trimesh.Trimesh(vertices=verts,faces=faces,process=False);parts[['leaf_dark','leaf_mid','leaf_sun'][i%3]].append(m)
scene=trimesh.Scene();palette={'bark':[86,66,43,255],'leaf_dark':[36,71,33,255],'leaf_mid':[57,94,39,255],'leaf_sun':[88,116,51,255]}
for name,items in parts.items():
 m=trimesh.util.concatenate(items);m.visual=TextureVisuals(material=PBRMaterial(name=name,baseColorFactor=palette[name],metallicFactor=0,roughnessFactor=.9,doubleSided=name!='bark'));scene.add_geometry(m,node_name=name)
out=Path(__file__).resolve().parents[1]/'assets/models/canopy-refined.glb';out.write_bytes(scene.export(file_type='glb'));print(out,len(out.read_bytes()),sum(len(g.faces) for g in scene.geometry.values()))
