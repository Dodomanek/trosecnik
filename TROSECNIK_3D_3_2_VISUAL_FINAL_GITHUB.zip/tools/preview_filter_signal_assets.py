#!/usr/bin/env python3
"""Offline software-model preview for GFX15 site assets; NOT a screenshot of the game."""
from pathlib import Path
import numpy as np, trimesh
from PIL import Image, ImageDraw, ImageFont
ROOT=Path(__file__).resolve().parents[1]
W,H=1360,760
im=Image.new('RGB',(W,H),(26,39,37));d=ImageDraw.Draw(im)
for y in range(H):
 t=y/H
 d.line((0,y,W,y),fill=(int(32+62*t),int(52+38*t),int(56-14*t)))
d.ellipse((35,502,902,740),fill=(48,63,53));d.ellipse((910,474,1325,736),fill=(48,63,53))
LIGHT=np.array([.36,.82,-.45]);LIGHT/=np.linalg.norm(LIGHT)
CAM=np.array([.44,.30,-.85]);CAM/=np.linalg.norm(CAM)
RIGHT=np.cross([0,1,0],CAM);RIGHT/=np.linalg.norm(RIGHT)
UP=np.cross(CAM,RIGHT);UP/=np.linalg.norm(UP)

def render(path,anchor,scale):
 s=trimesh.load(path,force='scene')
 faces=[]
 for mesh in s.dump():
  vertices=np.asarray(mesh.vertices)
  mfaces=np.asarray(mesh.faces,dtype=int)
  normals=np.asarray(mesh.face_normals)
  material=mesh.visual.material
  color=np.asarray(material.baseColorFactor[:3],dtype=float)
  center=np.mean(vertices[mfaces],axis=1)
  depth=center@CAM
  px=(vertices@RIGHT)*scale+anchor[0]
  py=-(vertices@UP)*scale+anchor[1]
  for i,tri in enumerate(mfaces):
   n=normals[i];brightness=max(0,float(n@LIGHT))
   ambient=.46+brightness*.52
   col=tuple(int(min(255,chan*ambient+8)) for chan in color)
   coords=[(float(px[j]),float(py[j])) for j in tri]
   faces.append((float(depth[i]),coords,col))
 faces.sort(key=lambda f:f[0],reverse=True)
 for _,pts,col in faces:d.polygon(pts,fill=col)

render(ROOT/'assets/models/filter.glb',(385,610),170)
render(ROOT/'assets/models/signal.glb',(1035,630),145)
try:
 font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',31)
 small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
except OSError:
 font=ImageFont.load_default();small=font

d.text((38,28),'TROSECNIK 3D  |  GFX 15',fill=(240,214,168),font=font)
d.text((40,74),'Skutecne modely z GLB  /  offline nahled (nejde o screenshot hry)',fill=(206,216,206),font=small)
d.text((175,687),'FILTR VODY  /  lokalni GLB',fill=(244,229,192),font=small)
d.text((915,687),'SIGNALNI STANOVISTE  /  lokalni GLB',fill=(244,229,192),font=small)
path=ROOT/'graphics'/'previews'/'sites-gfx15-offline.png'
path.parent.mkdir(parents=True,exist_ok=True)
im.save(path)
print('MODEL_PREVIEW',path,im.size)
