"""Build the runtime atlas from the retained AI-generated source. Requires Pillow.
This performs format conversion only; the original generation prompt is preserved
in assets/textures/PROVENANCE.md. Run from any working directory.
"""
from pathlib import Path
from PIL import Image
root = Path(__file__).resolve().parents[1]
with Image.open(root / "assets/textures/terrain-atlas-source.png") as source:
    source.convert("RGB").resize((1024, 1024), Image.Resampling.LANCZOS).save(
        root / "assets/textures/terrain-atlas.webp", "WEBP", quality=88, method=6)
