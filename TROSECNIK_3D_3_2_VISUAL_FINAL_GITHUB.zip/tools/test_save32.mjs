import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInNewContext} from 'node:vm';
const src=readFileSync(new URL('../src/game_logic.js',import.meta.url),'utf8');
const between=(a,b)=>src.slice(src.indexOf(a)+a.length,src.indexOf(b,src.indexOf(a)));
const BASE=runInNewContext('('+between('const BASE=',';\nconst ITEM=')+')');
test('actual load merge upgrades version-2 slots without losing story, inventory or storage',()=>{
 const old={version:2,x:12,z:24,hp:63,bag:{wood:7,core:1},built:{shelter:3},flags:{'quest-crate':true},storage:{fiber:8},story:{fate:'ivo'},journal:['Původní záznam']};
 const code='let state;const slot=1;const KEY="test";const n=1;'+between('function load(n=slot){','migrateOldSave(a);')+';state';
 const loaded=runInNewContext(code,{BASE,copy:v=>JSON.parse(JSON.stringify(v)),getStorage:()=>({1:old}),clamp:(n,a,b)=>Math.max(a,Math.min(b,n))});
 assert.equal(loaded.built.dryingRack,0);assert.equal(loaded.built.rainCollector,0);assert.equal(loaded.built.workbench,0);
 assert.equal(loaded.hp,63);assert.equal(loaded.bag.core,1);assert.equal(loaded.bag.wood,7);assert.equal(loaded.story.fate,'ivo');assert.equal(loaded.storage.fiber,8);assert.equal(loaded.journal[0],'Původní záznam');assert.equal(old.built.dryingRack,undefined);
});
test('load retains pinned recipe, drying progress and rain reserve independently per slot',()=>{
 const code='let state;const slot=1;const KEY="test";const n=1;'+between('function load(n=slot){','migrateOldSave(a);')+';state';
 const input={...BASE,flags:{pinnedRecipe:'leafArmor',dryingUntil:125,rainWater:44},seconds:100};
 const loaded=runInNewContext(code,{BASE,copy:v=>JSON.parse(JSON.stringify(v)),getStorage:()=>({1:input}),clamp:(n,a,b)=>Math.max(a,Math.min(b,n))});
 assert.equal(loaded.flags.pinnedRecipe,'leafArmor');assert.equal(loaded.flags.dryingUntil,125);assert.equal(loaded.flags.rainWater,44);assert.notEqual(loaded.flags,input.flags);
});
