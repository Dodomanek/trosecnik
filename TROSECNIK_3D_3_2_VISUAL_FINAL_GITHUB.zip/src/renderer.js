import { NatureVisuals } from './nature_visuals.js';
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { SSAOPass } from 'three/addons/postprocessing/SSAOPass.js';

// GPU-only layer. Never mutates inventory, quests, collisions, save data or NPC logic.
// Geometry is the ORIGINAL triangle data, converted to reusable Three.js BufferGeometry.
export class Renderer {
  constructor() {
    this.models = new Map();
    this.geometryPool = [];
    this.modelPool = [];
    this.materials = new Map();
    this.geometryIndex = 0;
    this.modelIndex = 0;
    this.lastWidth = 0;
    this.lastHeight = 0;
    this.lastRatio = 0;
    this.clock = 0;
    this.engine = null;
    this.heroReady = false; this.heroFailed = false;
    this.heroActor = null; this.heroMixer = null; this.heroActions = {};
    this.heroMode = null; this.heroTool = null; this.heroDisplayYaw = null;
    this.skyDome = null; this.skyUniforms = null; this.waterMaterials = [];
    this.terrainMaterials = []; this.terrainTexture = null; this.viewModel=null; this.viewParts={}; this.composer=null; this.ssaoPass=null; this.bloomPass=null;
  }

  init(canvas) {
    if (!canvas) throw new Error('Chybí původní herní canvas #world.');
    this.canvas = canvas;
    this.engine = new THREE.WebGLRenderer({canvas,alpha:false,antialias:true,powerPreference:'high-performance'});
    this.engine.outputColorSpace = THREE.SRGBColorSpace;
    this.engine.toneMapping = THREE.ACESFilmicToneMapping;
    this.engine.toneMappingExposure = 1.28;
    this.engine.shadowMap.enabled = true;
    this.engine.shadowMap.type = THREE.PCFSoftShadowMap;
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(68,1,.09,190);
    this.scene.fog = new THREE.Fog(0x89ab9f,22,110);
    this.ambient = new THREE.HemisphereLight(0xaedaf0,0x5d633e,1.15);
    this.scene.add(this.ambient);
    this.fill = new THREE.AmbientLight(0x7383a7,.24);
    this.scene.add(this.fill);
    this.sun = new THREE.DirectionalLight(0xffdfab,2.2);
    this.sun.position.set(40,80,-28);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048,2048);
    this.sun.shadow.camera.left=-28;
    this.sun.shadow.camera.right=28;
    this.sun.shadow.camera.top=28;
    this.sun.shadow.camera.bottom=-28;
    this.sun.shadow.camera.near=.5;
    this.sun.shadow.camera.far=140;
    this.sun.shadow.bias=-.00012;this.sun.shadow.normalBias=.025;
    this.scene.add(this.sun,this.sun.target);
    this.fire = new THREE.PointLight(0xff9237,0,13,2);
    this.fire.position.set(-4,1,-2);
    this.scene.add(this.fire);

    // GFX 9: lightweight procedural sky dome. It is camera-centred, so it adds no gameplay geometry.
    this.skyUniforms={
      topColor:{value:new THREE.Color(0x377a96)},
      horizonColor:{value:new THREE.Color(0xe2aa76)},
      nightColor:{value:new THREE.Color(0x071321)},
      sunColor:{value:new THREE.Color(0xffb36b)},
      sunDirection:{value:new THREE.Vector3(.5,.45,-.5).normalize()},
      daylight:{value:1},golden:{value:0},weather:{value:0}
    };
    const skyMaterial=new THREE.ShaderMaterial({
      side:THREE.BackSide,depthWrite:false,depthTest:false,fog:false,toneMapped:true,
      uniforms:this.skyUniforms,
      vertexShader:`varying vec3 vDir; void main(){vDir=normalize(position);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`,
      fragmentShader:`precision highp float; varying vec3 vDir; uniform vec3 topColor,horizonColor,nightColor,sunColor,sunDirection; uniform float daylight,golden,weather;
      void main(){vec3 d=normalize(vDir);float h=clamp(d.y*.5+.5,0.,1.);float band=smoothstep(.38,.86,h);vec3 day=mix(horizonColor,topColor,band);vec3 night=mix(vec3(.07,.10,.16),nightColor,band);vec3 sky=mix(night,day,daylight);float sd=max(dot(d,normalize(sunDirection)),0.);float halo=pow(sd,26.);float disc=smoothstep(.99915,.99982,sd);sky+=sunColor*(halo*.42+disc*1.8)*(daylight+.12)*(.55+golden*.65);sky=mix(sky,vec3(.29,.35,.37),weather*.62);float haze=pow(max(0.,1.-abs(d.y)),5.);sky=mix(sky,horizonColor,haze*(.08+.22*golden)*(1.-weather*.5));gl_FragColor=vec4(sky,1.);}`
    });
    this.skyDome=new THREE.Mesh(new THREE.SphereGeometry(145,28,14),skyMaterial);
    this.skyDome.renderOrder=-1000;
    this.scene.add(this.skyDome);
    // GFX 17: local, deterministic neutral-grain texture. Applied only to the original
    // terrain mesh, never to objects, collision mesh, or the sea. No external assets.
    this.terrainTexture=this.makeTerrainGrain();
    this.nature=new NatureVisuals(this);
    this.loader = new GLTFLoader();
    this.createFirstPersonBody();
    this.composer=new EffectComposer(this.engine);
    this.composer.addPass(new RenderPass(this.scene,this.camera));
    this.ssaoPass=new SSAOPass(this.scene,this.camera,1,1);this.ssaoPass.kernelRadius=7;this.ssaoPass.minDistance=.002;this.ssaoPass.maxDistance=.13;this.composer.addPass(this.ssaoPass);
    this.bloomPass=new UnrealBloomPass(new THREE.Vector2(1,1),.16,.34,.88);this.composer.addPass(this.bloomPass);
    // Keep the proven SSAO/bloom output path. Extra output/FXAA passes caused
    // black screen regions on this renderer; antialias the render targets instead.
    const samples=canvas.clientWidth>760?Math.min(2,this.engine.capabilities.maxSamples):0;
    this.composer.renderTarget1.samples=samples;this.composer.renderTarget2.samples=samples;
    return this;
  }

  createFirstPersonBody() {
    const g=new THREE.Group();g.name='FirstPersonBody';this.camera.add(g);this.scene.add(this.camera);g.position.set(0,-.57,-.72);g.renderOrder=999;
    const skin=new THREE.MeshStandardMaterial({color:0xa96f50,roughness:.72,metalness:0,depthTest:false,depthWrite:false});
    const cloth=new THREE.MeshStandardMaterial({color:0x6c6b55,roughness:.93,depthTest:false,depthWrite:false});
    const dark=new THREE.MeshStandardMaterial({color:0x352f25,roughness:.9,depthTest:false,depthWrite:false});
    const wood=new THREE.MeshStandardMaterial({color:0x6d492c,roughness:.9,depthTest:false,depthWrite:false});
    const stone=new THREE.MeshStandardMaterial({color:0x6c7169,roughness:.96,depthTest:false,depthWrite:false});
    const armGeo=new THREE.CapsuleGeometry(.07,.32,5,10),legGeo=new THREE.CapsuleGeometry(.105,.58,5,8);
    for(const side of [-1,1]){const arm=new THREE.Mesh(armGeo,skin);arm.position.set(side*.34,-.18,-.36);arm.rotation.x=-.90;arm.rotation.z=side*.08;g.add(arm);const fist=new THREE.Mesh(new THREE.SphereGeometry(.075,10,7),skin);fist.scale.set(1,.8,1.2);fist.position.set(side*.34,-.10,-.55);g.add(fist);this.viewParts['arm'+side]=arm;const leg=new THREE.Mesh(legGeo,cloth);leg.position.set(side*.16,-.62,.10);leg.rotation.x=.10;g.add(leg);this.viewParts['leg'+side]=leg;}
    const hand=new THREE.Group();hand.position.set(.30,-.10,-.58);g.add(hand);this.viewParts.weaponHand=hand;
    const make=(id,obj)=>{obj.visible=false;hand.add(obj);this.viewParts[id]=obj};
    const club=new THREE.Mesh(new THREE.CylinderGeometry(.055,.075,.92,8),wood);club.rotation.x=Math.PI/2;club.position.set(0,-.03,-.35);make('club',club);
    const spear=new THREE.Group();let shaft=new THREE.Mesh(new THREE.CylinderGeometry(.027,.035,1.42,8),wood);shaft.rotation.x=Math.PI/2;shaft.position.z=-.55;spear.add(shaft);let tip=new THREE.Mesh(new THREE.ConeGeometry(.07,.28,6),stone);tip.rotation.x=-Math.PI/2;tip.position.z=-1.30;spear.add(tip);make('spear',spear);
    const hs=spear.clone(true);make('hardenedSpear',hs);
    const axe=new THREE.Group();let ah=new THREE.Mesh(new THREE.CylinderGeometry(.03,.04,.72,8),wood);ah.rotation.x=Math.PI/2;ah.position.z=-.28;axe.add(ah);let ab=new THREE.Mesh(new THREE.BoxGeometry(.25,.11,.055),stone);ab.position.set(.08,.0,-.66);axe.add(ab);make('axe',axe);
    const knife=new THREE.Mesh(new THREE.BoxGeometry(.055,.045,.48),stone);knife.position.z=-.30;make('flintBlade',knife);
    const hammer=new THREE.Group();let hh=new THREE.Mesh(new THREE.CylinderGeometry(.035,.045,.76,8),wood);hh.rotation.x=Math.PI/2;hh.position.z=-.29;hammer.add(hh);let hb=new THREE.Mesh(new THREE.BoxGeometry(.28,.17,.17),stone);hb.position.z=-.70;hammer.add(hb);make('stoneHammer',hammer);
    g.traverse(o=>{if(o.isMesh){o.frustumCulled=false;o.renderOrder=999;}});this.viewModel=g;
  }

  drawFirstPersonBody({walk=0,working=0,kind='gather',weapon='fists',running=false,time=0}={}) {
    if(!this.viewModel)return;this.viewModel.visible=true;const bob=Math.sin(time*(running?12:8))*Math.min(.028,walk*.018);this.viewModel.position.y=-.57+bob;this.viewModel.position.x=Math.sin(time*4)*Math.min(.009,walk*.006);
    const step=Math.sin(time*(running?12:8))*Math.min(.16,walk*.12);this.viewParts['leg-1'].rotation.x=.10+step;this.viewParts['leg1'].rotation.x=.10-step;
    this.viewParts['arm-1'].rotation.x=-.90-step*.22;this.viewParts['arm1'].rotation.x=-.90+step*.22;
    const attack=working>0?Math.sin(Math.min(1,working)*Math.PI):0;this.viewParts.weaponHand.position.z=-.58-attack*(kind==='thrust'?.42:.16);this.viewParts.weaponHand.rotation.x=attack*(kind==='fight'?-1.0:-.48);this.viewParts['arm1'].rotation.x+=attack*.75;
    for(const id of ['club','spear','hardenedSpear','axe','flintBlade','stoneHammer'])if(this.viewParts[id])this.viewParts[id].visible=weapon===id;
  }

  makeTerrainGrain() {
    const size=256, pixels=new Uint8Array(size*size*4);
    const smooth=t=>t*t*(3-2*t);
    // Seamless, very low-contrast multiscale noise, repeated in world metres.
    const hash=(x,y,seed)=>{
      x=(x%size+size)%size;y=(y%size+size)%size;
      let v=Math.imul(x+seed,374761393)^Math.imul(y+seed,668265263);
      v=Math.imul(v^(v>>>13),1274126177);
      return ((v^(v>>>16))>>>0)/4294967295;
    };
    const sample=(x,y,cell,seed)=>{
      const gx=x/cell,gy=y/cell,xi=Math.floor(gx),yi=Math.floor(gy);
      const sx=smooth(gx-xi),sy=smooth(gy-yi);
      const at=(a,b)=>hash((a*cell)%size,(b*cell)%size,seed);
      const a=at(xi,yi)*(1-sx)+at(xi+1,yi)*sx;
      const b=at(xi,yi+1)*(1-sx)+at(xi+1,yi+1)*sx;
      return a*(1-sy)+b*sy;
    };
    for(let y=0;y<size;y++)for(let x=0;x<size;x++){
      const detail=sample(x,y,4,11)*.24+sample(x,y,16,23)*.30+sample(x,y,32,37)*.46;
      const value=Math.max(213,Math.min(255,Math.round(226+detail*28)));
      const i=(y*size+x)*4;pixels[i]=pixels[i+1]=pixels[i+2]=value;pixels[i+3]=255;
    }
    const texture=new THREE.DataTexture(pixels,size,size,THREE.RGBAFormat);
    texture.wrapS=texture.wrapT=THREE.RepeatWrapping;
    texture.minFilter=THREE.LinearMipmapLinearFilter;
    texture.magFilter=THREE.LinearFilter;
    texture.generateMipmaps=true;
    texture.anisotropy=Math.min(8,this.engine.capabilities.getMaxAnisotropy());
    texture.needsUpdate=true;
    return texture;
  }

  upload(data) {
    if (!data || !Array.isArray(data.p) || !data.p.length) {
      return {geometry:null,count:0};
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position',new THREE.Float32BufferAttribute(data.p,3));
    if(data.n?.length===data.p.length) geometry.setAttribute('normal',new THREE.Float32BufferAttribute(data.n,3));
    else geometry.computeVertexNormals();
    if(data.c?.length===data.p.length) geometry.setAttribute('color',new THREE.Float32BufferAttribute(data.c,3));
    else {
      const colors=new Float32Array(data.p.length).fill(1);
      geometry.setAttribute('color',new THREE.BufferAttribute(colors,3));
    }
    geometry.computeBoundingSphere();
    return {geometry,count:data.p.length/3};
  }

  material(tint=[1,1,1],kind=0,water=0) {
    const key=[...tint].map(v=>Math.round(v*255)).join(',')+`:${kind}:${water}`;
    if(!this.materials.has(key)){
      const rgb=new THREE.Color().setRGB(...tint);
      let material;
      if(water>0){
        const uniforms={
          tintColor:{value:rgb.clone()},time:{value:0},daylight:{value:1},golden:{value:0},weather:{value:0},
          sunDirection:{value:new THREE.Vector3(.4,.7,-.3).normalize()},eye:{value:new THREE.Vector3()},
          terrainHeight:{value:this.nature.heightMap},fogColor:{value:new THREE.Color(0x89ab9f)},fogNear:{value:20},fogFar:{value:110},mode:{value:water}
        };
        material=new THREE.ShaderMaterial({
          transparent:true,depthWrite:false,side:THREE.DoubleSide,vertexColors:true,toneMapped:true,uniforms,
          vertexShader:`varying vec3 vWorld,vNormal,vColor; void main(){vColor=color;vec4 wp=modelMatrix*vec4(position,1.);vWorld=wp.xyz;vNormal=normalize(mat3(modelMatrix)*normal);gl_Position=projectionMatrix*viewMatrix*wp;}`,
          fragmentShader:`precision highp float;varying vec3 vWorld,vNormal,vColor;uniform sampler2D terrainHeight;uniform vec3 tintColor,sunDirection,eye,fogColor;uniform float time,daylight,golden,weather,fogNear,fogFar,mode;
          void main(){
            float horizontal=step(mode,1.5);vec2 p=vWorld.xz;
            float w1=sin(p.x*.7+p.y*.32+time*1.1),w2=sin(p.x*1.21-p.y*.84-time*.7),w3=sin(p.x*3.8+p.y*2.6+time*1.8);
            float wave=w1*.45+w2*.35+w3*.2;
            vec3 n=normalize(vNormal+vec3((w1+w3)*.045,0.,w2*.06)*horizontal);
            vec3 view=normalize(eye-vWorld);
            float ground=texture2D(terrainHeight,clamp((p+85.)/170.,0.,1.)).r*12.-4.;
            float depth=max(0.,-.62-ground);
            vec3 deep=vec3(.018,.13,.19),shallow=vec3(.13,.48,.43);
            vec3 base=mix(shallow,deep,smoothstep(.1,2.6,depth));
            base+=vec3(.06,.13,.11)*wave*.18;
            float fres=pow(clamp(1.-dot(n,view),0.,1.),4.);
            base=mix(base,mix(fogColor,vec3(.35,.63,.72),.4),fres*.65);
            float spec=pow(max(dot(reflect(-normalize(sunDirection),n),view),0.),110.);
            base+=vec3(1.,.87,.61)*spec*.55*daylight;
            float foam=(1.-smoothstep(.08,.45,depth))*(.4+.6*smoothstep(-.1,.65,wave));
            base=mix(base,vec3(.76,.85,.78),foam*.65);
            if(horizontal<.5){float stream=sin(vWorld.y*8.-time*7.+vWorld.x*3.);base=mix(vec3(.1,.42,.47),vec3(.65,.84,.82),smoothstep(.1,.85,stream));}
            base*=.3+.7*daylight;base=mix(base,vec3(.19,.28,.3),weather*.28);
            float fog=smoothstep(fogNear,fogFar,length(eye-vWorld));base=mix(base,fogColor,fog*.84);
            gl_FragColor=vec4(base,mix(.75,.88,horizontal));
          }`
        });
        material.userData.waterUniforms=uniforms;
        this.waterMaterials.push(material);
      }else if(kind===3){
        material=new THREE.MeshBasicMaterial({color:rgb,transparent:true,opacity:.24,depthWrite:false,side:THREE.DoubleSide,toneMapped:true});
        material.polygonOffset=true;material.polygonOffsetFactor=-1;material.polygonOffsetUnits=-1;
      }else{
        material=new THREE.MeshStandardMaterial({
          color:rgb,vertexColors:true,
          roughness:kind===1?.97:.84,metalness:kind===0?.035:0,
          side:THREE.DoubleSide,
          ...(kind===1?{map:this.terrainTexture}:{}),
        });
        if(kind===1){this.nature.terrain(material);this.terrainMaterials.push(material);}
      }
      this.materials.set(key,material);
    }
    return this.materials.get(key);
  }

  applyMatrix(node, matrix) {
    node.matrixAutoUpdate=false;
    node.matrix.fromArray(matrix);
    node.matrixWorldNeedsUpdate=true;
  }

  draw(mesh, matrix, tint,kind=0,water=0) {
    if(!mesh?.geometry || !mesh.count) return;
    const i=this.geometryIndex++;
    let node=this.geometryPool[i];
    if(!node){node=new THREE.Mesh(mesh.geometry,this.material(tint,kind,water));
      node.frustumCulled = true;
      this.geometryPool.push(node);
      this.scene.add(node);
    }
    if(kind===1 && !mesh.geometry.getAttribute('uv')) {
      // Build visual UVs from unchanged world-space vertex positions. Game physics
      // and mesh geometry stay untouched; the terrain needs no extra draw call.
      NatureVisuals.smoothNormals(mesh.geometry);
      const position=mesh.geometry.getAttribute('position');
      const uv=new Float32Array(position.count*2);
      for(let j=0;j<position.count;j++){
        uv[j*2]=position.getX(j)*.22;
        uv[j*2+1]=position.getZ(j)*.22;
      }
      mesh.geometry.setAttribute('uv',new THREE.BufferAttribute(uv,2));
    }
    if(node.geometry!==mesh.geometry)node.geometry=mesh.geometry;
    node.material=this.material(tint,kind,water);
    node.visible=true;
    node.castShadow=kind===0&&water===0&&mesh.count<9000;
    node.receiveShadow=water===0&&kind!==3;
    node.userData.water=water;
    this.applyMatrix(node,matrix);
  }

  hasModel(name) {return this.models.has(name);}
  drawModel(name,matrix,tint=[1,1,1]) {
    const model=this.models.get(name);
    if(!model)return false;
    const i=this.modelIndex++;
    let entry=this.modelPool[i];
    if(!entry || entry.name!==name) {
      if(entry)this.scene.remove(entry.group);
      const group=new THREE.Group();
      const clone=model.scene.clone(true);
      clone.scale.multiplyScalar(model.scale);
      clone.position.y+=model.yOffset;
      clone.traverse(o=>{if(o.isMesh){o.castShadow=!['rock','spring_cliff'].includes(name);o.receiveShadow=true;const mats=Array.isArray(o.material)?o.material:[o.material];for(const m of mats){if(!m)continue;if('flatShading' in m)m.flatShading=false;if(m.map){m.map.minFilter=THREE.LinearMipmapLinearFilter;m.map.magFilter=THREE.LinearFilter;m.map.anisotropy=Math.min(8,this.engine.capabilities.getMaxAnisotropy());m.map.generateMipmaps=true;m.map.needsUpdate=true;}m.needsUpdate=true;}}});
      group.add(clone);
      entry={name,group};this.modelPool[i]=entry;this.scene.add(group);
    }
    entry.group.visible=true;
    this.applyMatrix(entry.group,matrix);
    return true;
  }

  async loadModels(list) {
    let count=0;
    await Promise.all(list.map(async entry=>{
      try{
        const gltf=await this.loader.loadAsync(entry.url);
        if(!gltf?.scene)throw new Error('Soubor neobsahuje scénu');
        let meshes=0;
        gltf.scene.traverse(n=>{if(n.isMesh){meshes++;const mats=Array.isArray(n.material)?n.material:[n.material];for(const m of mats){if(!m)continue;if((entry.name==='canopy-refined'&&/leaf/.test(m.name))||(entry.name==='palm-refined'&&/fronds/.test(m.name)))this.nature.foliage(m);else if(entry.name==='rock'||/stone/i.test(m.name))this.nature.surface(m,'rock');else if(/bark|wood|trunk/i.test(m.name)&&!m.map)this.nature.surface(m,'wood');}}});
        if(!meshes)throw new Error('Scéna neobsahuje geometrii');
        this.models.set(entry.name,{scene:gltf.scene,scale:entry.scale??1,yOffset:entry.yOffset??0});
        count++;
      }catch(error){
        // Missing models are normal: the original trees/crate remain visible.
        console.info('Volitelný GLB model není dostupný:',entry.name,error.message||error);
      }
    }));
    return count;
  }

  // Persistent glTF character. The root is driven by game physics, never by clip translation.
  async loadHero(url='assets/models/robinson.glb') {
    try {
      const asset = await this.loader.loadAsync(url);
      if (!asset.scene || !asset.animations?.length) throw new Error('Chybí geometrie nebo klipy animací');
      const required=['Idle','Walk','Run','Gather','Chop','Build'];
      for (const name of required) if (!asset.animations.some(clip=>clip.name===name)) throw new Error('Chybí animace '+name);
      // No global model-space bob. Physics owns the world-space x/y/z of this group.
      const actor=new THREE.Group();
      actor.name='RobinsonPhysicsRoot';actor.visible=false;
      actor.add(asset.scene);
      asset.scene.traverse(n=>{if(n.isMesh){n.castShadow=true;n.receiveShadow=true;n.frustumCulled=false;if(n.material){n.material=n.material.clone();if('roughness' in n.material)n.material.roughness=Math.max(.68,n.material.roughness??.8);if('metalness' in n.material)n.material.metalness=Math.min(.12,n.material.metalness??0);if(n.material.map)n.material.map.colorSpace=THREE.SRGBColorSpace;}}});
      this.scene.add(actor);
      this.heroActor=actor;
      this.heroTool=asset.scene.getObjectByName('ToolAxe');
      if(this.heroTool)this.heroTool.visible=false;
      this.heroMixer=new THREE.AnimationMixer(asset.scene);
      for(const clip of asset.animations) {
        const action=this.heroMixer.clipAction(clip);
        action.enabled=true;
        action.clampWhenFinished=true;
        action.setLoop(['Idle','Walk','Run'].includes(clip.name)?THREE.LoopRepeat:THREE.LoopOnce);
        this.heroActions[clip.name]=action;
      }
      this.heroActions.Idle.play();
      this.heroMode='Idle';
      this.heroReady=true;
      return true;
    }catch(error){
      if(url==='assets/models/robinson.glb'){
        // GFX 11: a corrupt optional material upgrade must not hide the original actor.
        console.warn('Texturovaný Robinson se nepodařil načíst; používám původní animovaný GLB.',error);
        return this.loadHero('assets/models/robinson_base.glb');
      }
      this.heroFailed=true;
      console.warn('Ani původní model Robinsona se nepodařilo načíst; zůstane procedurální postava.',error);
      return false;
    }
  }

  drawHero({x,y,z,yaw,walk=0,working=0,kind='gather'},dt=0.016) {
    if(!this.heroReady)return false;
    const actor=this.heroActor;actor.visible=true;
    // Smooth yaw without oscillation at the -π/+π crossing; follow a stable ground anchor.
    if(this.heroDisplayYaw===null)this.heroDisplayYaw=yaw;
    let delta=((yaw-this.heroDisplayYaw+Math.PI)%(2*Math.PI)+2*Math.PI)%(2*Math.PI)-Math.PI;
    this.heroDisplayYaw+=delta*Math.min(1,Math.max(0,dt)*16);
    actor.position.set(x,y,z); actor.rotation.y=this.heroDisplayYaw;
    const doing=working>.005;
    const modes={gather:'Gather',chop:'Chop',build:'Build',drink:'Drink',rest:'Rest'};
    const target=doing?(modes[kind]||'Gather'):(walk>.19?(walk>1.13?'Run':'Walk'):'Idle');
    if(this.heroTool)this.heroTool.visible=doing&&kind==='chop';
    if(target!==this.heroMode){
      const prev=this.heroActions[this.heroMode],next=this.heroActions[target];
      if(next){next.reset();next.enabled=true;next.setEffectiveWeight(1);next.setEffectiveTimeScale(1);next.play();
        if(prev){next.crossFadeFrom(prev,doing?.12:.18,false);}
        this.heroMode=target;
      }
    }
    const a=this.heroActions[this.heroMode];
    if(doing&&a){
      // Timeline follows the actual game interaction; inventory updates only after it finishes.
      a.paused=false;
      a.time=Math.min(a.getClip().duration-.001,Math.max(0,working)*a.getClip().duration);
      a.paused=true;
    }else if(a){
      a.paused=false;
      a.timeScale=this.heroMode==='Walk'?Math.max(.7,Math.min(1.55,walk)):
                  this.heroMode==='Run'?Math.max(.85,Math.min(1.6,walk/1.25)):1;
    }
    this.heroMixer.update(Math.min(.05,Math.max(0,dt)));
    return true;
  }

  beginFrame({width,height,dpr,daylight=1,clock=12,weather='clear',time=0,
    eye=[0,3,7],focus=[0,1,0],fov=68,fireOn=0,fireY=1,zone='normal',quality='auto',built={}}) {
    this.nature?.update({time,quality,built});
    const w=Math.max(1,Math.floor(width||1)),h=Math.max(1,Math.floor(height||1));
    const ratio=Math.min(2.0,Math.max(.65,dpr||1));
    if(w!==this.lastWidth||h!==this.lastHeight||Math.abs(ratio-this.lastRatio)>.01) {
      this.engine.setPixelRatio(ratio);
      this.engine.setSize(w,h,false);if(this.composer){this.composer.setPixelRatio(ratio);this.composer.setSize(w,h);}
      this.lastWidth=w;this.lastHeight=h;this.lastRatio=ratio;
      this.camera.aspect=w/h;
      this.camera.updateProjectionMatrix();
    }
    this.camera.fov=fov;
    this.camera.position.set(...eye);
    this.camera.lookAt(...focus);
    this.camera.updateProjectionMatrix();
    this.camera.updateMatrixWorld(true);
    const day=Math.max(0,Math.min(1,daylight));if(this.ssaoPass)this.ssaoPass.enabled=quality!=='low'&&w>760&&h>500;if(this.bloomPass){this.bloomPass.enabled=quality!=='low';this.bloomPass.strength=.055+(1-day)*.075;this.bloomPass.threshold=.86;}
    const badWeather=weather==='storm'?.53:weather==='rain'?.25:0;
    const hour=((clock%24)+24)%24;
    const dawn=Math.exp(-Math.pow((hour-7.15)/1.65,2));
    const dusk=Math.exp(-Math.pow((hour-18.0)/1.65,2));
    const golden=Math.max(dawn,dusk)*day*(1-badWeather*.7);
    const solar=Math.PI*(hour-6)/12;
    const altitude=Math.max(.08,Math.sin(solar));
    const azimuth=(hour/24)*Math.PI*2+.42;
    const horizontal=Math.sqrt(Math.max(.001,1-altitude*altitude));
    const sunDir=new THREE.Vector3(Math.cos(azimuth)*horizontal,altitude,Math.sin(azimuth)*horizontal).normalize();
    const skyNight=new THREE.Color(0x071423);
    const skyDay=new THREE.Color(0x79aebc);
    const horizon=new THREE.Color(0xbdd9d5).lerp(new THREE.Color(0xe89458),golden*.72);
    const sky=skyNight.clone().lerp(skyDay,day*(1-badWeather));
    sky.lerp(horizon,golden*.24);
    this.scene.background=sky;
    this.scene.fog.color.copy(sky).lerp(horizon,.18+.17*golden);
    this.scene.fog.near=16+day*10;
    this.scene.fog.far=(weather==='storm'?54:weather==='rain'?72:118);if(zone==='fogForest'){this.scene.fog.near=7;this.scene.fog.far=39;this.scene.fog.color.lerp(new THREE.Color(0x71837a),.45)}else if(zone==='blackBeach'){this.scene.fog.near=12;this.scene.fog.far=Math.min(this.scene.fog.far,70);this.scene.fog.color.lerp(new THREE.Color(0x3d4650),.35)}else if(zone==='ravine'){this.scene.fog.far=Math.min(this.scene.fog.far,86);}
    // Rain/storm wets the ground visually, without modifying traction, speed,
    // survival values or saved weather. The subtle grain stays visible in sun.
    for(const material of this.terrainMaterials){
      material.roughness=.97-badWeather*.30;
      material.color.setRGB(1-badWeather*.16,1-badWeather*.13,1-badWeather*.10);
    }
    this.ambient.intensity=.28+day*.92;
    this.ambient.color.set(0xb9d7dd).lerp(new THREE.Color(0xffc98c),golden*.36);
    this.ambient.groundColor.set(0x494737);
    this.fill.intensity=.10+(1-day)*.32;
    this.sun.intensity=.10+day*(1.92+golden*.55)*(1-badWeather*.6);
    this.sun.color.set(0xffefcf).lerp(new THREE.Color(0xff9d5c),golden*.86);
    this.sun.target.position.set(focus[0],0,focus[2]);
    const sunDistance=72;
    this.sun.position.set(focus[0]+sunDir.x*sunDistance,Math.max(7,focus[1]+sunDir.y*sunDistance),focus[2]+sunDir.z*sunDistance);
    this.sun.target.updateMatrixWorld();
    this.sun.castShadow=quality!=='low'&&this.lastWidth>700&&this.lastHeight>540&&weather!=='storm';
    this.fire.intensity=fireOn*2.5;
    this.fire.position.y=fireY;
    this.clock=time;
    if(this.skyDome){
      this.skyDome.position.copy(this.camera.position);
      this.skyUniforms.topColor.value.set(0x428baa).lerp(new THREE.Color(0x243d58),1-day);
      this.skyUniforms.horizonColor.value.copy(horizon);
      this.skyUniforms.nightColor.value.set(0x06111f);
      this.skyUniforms.sunColor.value.set(0xffb06a);
      this.skyUniforms.sunDirection.value.copy(sunDir);
      this.skyUniforms.daylight.value=day;
      this.skyUniforms.golden.value=golden;
      this.skyUniforms.weather.value=badWeather;
    }
    for(const material of this.waterMaterials){
      const u=material.userData.waterUniforms;if(!u)continue;
      u.time.value=time;u.daylight.value=day;u.golden.value=golden;u.weather.value=badWeather;
      u.sunDirection.value.copy(sunDir);u.eye.value.set(...eye);u.fogColor.value.copy(this.scene.fog.color);
      u.fogNear.value=this.scene.fog.near;u.fogFar.value=this.scene.fog.far;
    }
    this.geometryIndex=0;
    this.modelIndex=0;
    if(this.viewModel)this.viewModel.visible=false;
    if(this.heroActor)this.heroActor.visible=false;
  }

  endFrame() {
    for(let i=this.geometryIndex;i<this.geometryPool.length;i++)this.geometryPool[i].visible=false;
    for(let i=this.modelIndex;i<this.modelPool.length;i++)if(this.modelPool[i])this.modelPool[i].group.visible=false;
    for(let i=0;i<this.geometryIndex;i++){
      const node=this.geometryPool[i];
      if(node.userData.water===1){
        // Preserve the original sea plane's mean height; only add a small surface wave.
        node.matrix.elements[13]+=.022*Math.sin(this.clock*.9);
        node.matrixWorldNeedsUpdate=true;
      }
    }
    if(this.composer)this.composer.render();else this.engine.render(this.scene,this.camera);
  }
  render(){this.endFrame();}
  getCanvas(){return this.canvas;}
}
