/** Supply-node rules: no infinite harvesting in the starting camp.
 * Kept outside the renderer so saved positions and world geometry are unchanged.
 */
export const STARTER_NODE_IDS = Object.freeze([
  'driftwood','woodSouth','woodPoint','stonePile','stoneShore',
  'palmFiber','fiberShore','coconut','woodJungle','fiberJungle'
]);
export const STARTER_NODE_HARVESTS = 3;
const STARTER = new Set(STARTER_NODE_IDS);
const eligible = new Set(['wood','stone','fiber','coconut','herb','resin','fish','reeds','clay','flint','berries','salt']);
export function starterNode(node){return Boolean(node&&STARTER.has(node.id));}
export function gatherCount(node,flags={}){
  if(!starterNode(node))return 0;
  const current=flags['campHarvest-'+node.id];
  if(Number.isFinite(current)&&current>=0)return Math.floor(current);
  // On older saves a timestamp means the first harvest was already performed.
  return flags['collected-'+node.id]===undefined?0:1;
}
export function gatherCooldown(node){
  if(!node||node.repeat===undefined)return 0;
  if(node.type==='fish')return Math.max(90,node.repeat);
  return Math.max(starterNode(node)?180:300,node.repeat);
}
export function resourceAvailable(node,flags={},seconds=0){
  if(!node||node.repeat===undefined||!eligible.has(node.type))return true;
  if(starterNode(node)&&gatherCount(node,flags)>=STARTER_NODE_HARVESTS)return false;
  const last=flags['collected-'+node.id];
  return last===undefined || seconds-last>=gatherCooldown(node);
}
export function recordGather(node,flags,seconds){
  if(starterNode(node))flags['campHarvest-'+node.id]=gatherCount(node,flags)+1;
  flags['collected-'+node.id]=seconds;
}
