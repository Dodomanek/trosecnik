// TROSECNIK 3.0 alpha 1: persistent camp storage and soft expedition load.
// This module is pure and deliberately does not alter the legacy save key or quest state.
export const STORABLE = Object.freeze([
 'wood','stone','fiber','coconut','fish','bandage','herb','ration',
 'cord','tinder','handle','reeds','clay','flint','berries','salt',
 'trailSnack','fishJerky','herbalPoultice','reedMat','resin'
]);
const ALLOWED = new Set(STORABLE);
export const ITEM_WEIGHTS = Object.freeze({
 wood:2,stone:2,clay:1.5,flint:1.2,coconut:1.4,fish:1.3,
 ration:2,axe:2.5,spear:2.5,scrap:1.6,core:2,lens:1.1,
 brace:3,kit:2.5,herbalPoultice:.7,reedMat:1.4,trailSnack:.6,fishJerky:.5,
 bandage:.3,herb:.2,fiber:.3,cord:.5,tinder:.2,reeds:.55,berries:.25,
 salt:.5,resin:.7,handle:1,clayFlask:1.7,flintBlade:.7,torch:1.3,
 compass:.6,chart:.2,flare:.6,seal:.5,pouch:.6
});
export const BASE_LOAD = 28;
export const PACK_BONUS = 18;
export const STORAGE_CAPACITY = 120;
export function weightOf(item){return ITEM_WEIGHTS[item]??1;}
export function inventoryLoad(bag){return Object.entries(bag||{}).reduce((sum,[id,n])=>sum+(Number.isFinite(n)&&n>0?weightOf(id)*n:0),0);}
export function carryCapacity(bag){return BASE_LOAD+((bag?.fieldPack||0)>0?PACK_BONUS:0);}
export function movementLoadFactor(bag){const excess=Math.max(0,inventoryLoad(bag)-carryCapacity(bag));return Math.max(.55,1-excess*.016);}
export function canStore(id){return ALLOWED.has(id);}
// Atomic, clamped transfer. The caller must establish access to the built storage in-world.
export function transfer(bag,storage,id,count,direction){
 if(!canStore(id)||!Number.isInteger(count)||count<1||!['deposit','withdraw'].includes(direction))return 0;
 const src=direction==='deposit'?bag:storage,dst=direction==='deposit'?storage:bag;
 const available=Math.max(0,Math.floor(src[id]||0));
 let actual=Math.min(count,available);
 if(direction==='deposit')actual=Math.min(actual,Math.max(0,Math.floor((STORAGE_CAPACITY-inventoryLoad(storage)+1e-7)/weightOf(id))));
 if(actual<1)return 0;
 src[id]=available-actual;dst[id]=(dst[id]||0)+actual;
 return actual;
}
