/** Quest direction pointer. It always points toward the active objective,
 * including targets behind the camera. Coordinates are CSS pixels.
 */
export function computeQuestPointer(hero,target,camera,viewport){
 if(!hero||!target||!camera||!viewport)return null;
 const vals=[hero.x,hero.z,target.x,target.z,viewport.width,viewport.height,...(camera.right||[]),...(camera.forward||[])];
 if(!vals.every(Number.isFinite)||viewport.width<1||viewport.height<1)return null;
 const dx=target.x-hero.x,dz=target.z-hero.z,distance=Math.hypot(dx,dz);
 if(distance<=Math.max(1.4,(Number(target.r)||0)+.65))return null;
 const right=camera.right,forward=camera.forward;
 let sx=dx*right[0]+dz*right[2], sy=dx*forward[0]+dz*forward[2];
 if(Math.hypot(sx,sy)<1e-5){sx=0;sy=1}
 const angle=Math.atan2(sx,sy)*180/Math.PI;
 const rad=angle*Math.PI/180;
 const maxX=Math.min(viewport.width*.34,360),maxY=Math.min(viewport.height*.28,235);
 let left=viewport.width*.5+Math.sin(rad)*maxX;
 let top=viewport.height*.5-Math.cos(rad)*maxY;
 left=Math.max(72,Math.min(viewport.width-72,left));top=Math.max(86,Math.min(viewport.height-128,top));
 // Leave the quest card in the upper-left corner unobstructed.
 if(left<305&&top<205)top=220;
 return {left,top,angle,distance,edge:true};
}
