// Pure gameplay rules shared by the active game and deterministic tests.
export function stepBoar(b, hero, dt, passable = () => true) {
  b._phase ||= 'stalk';
  const dx = hero.x - b._wx, dz = hero.z - b._wz;
  const distance = Math.hypot(dx, dz);
  if (b._phase === 'stalk') {
    if (distance < 4.2) {
      b._phase = 'windup'; b._timer = .95;
      b._dirX = dx / (distance || 1); b._dirZ = dz / (distance || 1);
      if (!distance) b._dirZ = 1;
      return 'warn';
    }
    if (distance < 10.5) {
      const x = b._wx + dx / distance * 2.4 * dt;
      const z = b._wz + dz / distance * 2.4 * dt;
      if (passable(x,z)) { b._wx=x; b._wz=z; }
    }
    return;
  }
  b._timer -= dt;
  if (b._phase === 'windup') {
    if (b._timer <= 0) { b._phase='charge'; b._timer=.65; b._hit=false; }
    return;
  }
  if (b._phase === 'recover') {
    if (b._timer <= 0) b._phase='stalk';
    return;
  }
  const oldX=b._wx, oldZ=b._wz;
  const x=oldX+b._dirX*9*dt, z=oldZ+b._dirZ*9*dt;
  const blocked=!passable(x,z);
  if (!blocked) { b._wx=x; b._wz=z; }
  // Swept segment prevents a charge from tunnelling through the player.
  const sx=b._wx-oldX, sz=b._wz-oldZ, length=sx*sx+sz*sz;
  const t=length?Math.max(0,Math.min(1,((hero.x-oldX)*sx+(hero.z-oldZ)*sz)/length)):0;
  const hit=!b._hit && Math.hypot(hero.x-oldX-t*sx,hero.z-oldZ-t*sz)<1.35;
  if (hit) b._hit=true;
  if (blocked || b._timer<=0) { b._phase='recover'; b._timer=1.8; }
  return hit?'hit':undefined;
}
export function recipeCost(recipe, state) {
  const cost={...recipe.cost};
  if (state.built.workbench===3 && cost.fiber>1) cost.fiber--;
  return cost;
}
export function missingIngredients(cost, bag) {
  return Object.fromEntries(Object.entries(cost).map(([k,n])=>[k,Math.max(0,n-(bag[k]||0))]).filter(([,n])=>n));
}
export function updateRain(state, dt) {
  if(state.built.rainCollector===3 && ['rain','storm'].includes(state.weather))
    state.flags.rainWater=Math.min(70,(state.flags.rainWater||0)+dt*(state.weather==='storm'?1.2:.6));
}
