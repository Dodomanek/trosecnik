/* Trosečník 3D 2.4.2: local, branch-aware Czech dialogue. No remote TTS or tracker. */
const FILES={R:'robinson',M:'mara',I:'ivo'};
const FIRST_MARA=['M001','R021','M002','M003','R022','M004','R023','M005'];
const FIRST_IVO=['R025','I001','R026','I002','I003','R027','I004','R028','I005'];
const FATE=['M010','R033','M011','I010','R034','I011','M012','I012','R035','M013','R036'];
const AFTER_MARA=['R037','I013','R038','I014','R039'];
const AFTER_IVO=['R040','M014','R041','M015','R042'];
const END_IVO=['R049','I017','R050','I018','R051'];
const END_MARA=['R052','M020','R053','M021','R054'];
const QUEST={
 crate:['R005'], firstwood:['R006'], surveypoint:['R008'], spring:['R007'],
 firsttinder:['R009'], fire:['R010'], shelter:['R011'], blueprintaxe:['R012'],
 axe:['R013'], firstfilter:['R014'], wreck:['R015','R016'], wrecklog:['R017'],
 signal:['R018','R019','R020'], evidence:['R031','R032'], repairShelter:['R043'],
 restore:['R048'], repairIvo:['R044','I015','I016','R045'],
 repairMara:['M018','M019'], firstfish:['R062'], firstcook:['R061']
};
const STORE='trosecnik_voice_v1';
export class VoiceDirector {
 constructor(){
  this.queue=[];this.current=null;this.token=0;this.audio=new Audio();this.audio.preload='none';
  this.audio.addEventListener('ended',()=>this.advance());
  this.audio.addEventListener('error',()=>{console.warn('Chybí nahrávka:',this.current);this.advance()});
  this.lines={};this.lastBark={};this.lastNpc={};this.lastQuest={};this.started=false;this.blocked=false;
  let saved={};try{saved=JSON.parse(localStorage.getItem(STORE)||'{}')||{}}catch{}
  this.enabled=saved.enabled!==false;this.volume=Number.isFinite(saved.volume)?Math.max(0,Math.min(1,saved.volume)):.86;
  this.audio.volume=this.volume;
  this.makeUI();this.bind();
  fetch('assets/audio/dialogue/captions.json').then(r=>r.ok?r.json():{}).then(data=>{this.lines=data;if(this.current)this.caption.textContent=data[this.current]||'Replika '+this.current;}).catch(()=>{});
 }
 makeUI(){
  const host=document.createElement('div');host.id='voiceStage';host.hidden=true;
  host.innerHTML='<div class="voiceBody"><span id="voiceWho"></span><span id="voiceText"></span></div><div class="voiceActions"><button id="voiceReplay" type="button" title="Přehrát aktuální repliku">▶</button><button id="voiceNext" type="button" title="Další replika">Přeskočit ›</button></div>';
  document.body.append(host);this.host=host;this.who=host.querySelector('#voiceWho');this.caption=host.querySelector('#voiceText');
  host.querySelector('#voiceNext').addEventListener('click',()=>this.advance());
  host.querySelector('#voiceReplay').addEventListener('click',()=>this.replay());
  const controls=document.createElement('section');controls.id='voiceSettings';controls.innerHTML='<label><input type="checkbox" id="voiceEnabled"> 🎙️ Dabing dialogů</label><label>Hlasitost dabingu <input id="voiceVolume" type="range" min="0" max="100" step="5" value="86" aria-label="Hlasitost dabingu"></label><p>Nahrávky jsou součástí hry. Přeskočení dialogu nemění příběh.</p>';
  document.querySelector('#panel .sheet').append(controls);this.controls=controls;
  let cb=controls.querySelector('#voiceEnabled'),slider=controls.querySelector('#voiceVolume');cb.checked=this.enabled;slider.value=Math.round(this.volume*100);
  cb.addEventListener('change',()=>{this.enabled=cb.checked;this.persist();if(!this.enabled)this.stop();});
  slider.addEventListener('input',()=>{this.volume=Number(slider.value)/100;this.audio.volume=this.volume;this.persist();});
  this.refreshControls();
 }
 persist(){try{localStorage.setItem(STORE,JSON.stringify({enabled:this.enabled,volume:this.volume}))}catch{}}
 refreshControls(){this.controls.hidden=document.getElementById('paneTitle')?.textContent!=='Hra a nastavení'}
 bind(){
  window.addEventListener('trosecnik:voice',e=>this.onGame(e.detail||{}));
  const panel=document.getElementById('panel');if(panel){new MutationObserver(()=>this.refreshControls()).observe(document.getElementById('paneTitle'),{childList:true,characterData:true,subtree:true});}
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&this.current)this.audio.pause();else if(this.current)this.audio.play().catch(()=>{});});
 }
 getState(){try{return window.__trosecnikVoiceState?.()||{}}catch{return {}}}
 allowed(id){let s=this.getState();if(id?.startsWith('M')&&s.fate==='mara')return false;if(id?.startsWith('I')&&s.fate==='ivo')return false;return true}
 start(ids,{priority=false,remember=null}={}){
  if(!this.enabled||!ids?.length||this.getState().sound===false)return;
  if(priority)this.stop();
  const list=ids.filter(id=>FILES[id?.[0]]&&this.allowed(id));
  if(!list.length)return;
  if(!priority&&(this.current||this.queue.length)&&!remember)return;
  if(this.queue.length+list.length>26)return;
  if(remember){if(this.lastQuest[remember])return;this.lastQuest[remember]=true}
  const alreadyPlaying=Boolean(this.current);this.queue.push(...list);if(!alreadyPlaying)this.advance();
 }
 stop(){this.token++;this.audio.pause();this.audio.removeAttribute('src');this.audio.load();this.current=null;this.queue.length=0;this.host.hidden=true;this.duck(false)}
 duck(active){window.dispatchEvent(new CustomEvent('trosecnik:voice-duck',{detail:{active}}));}
 advance(){
  this.audio.pause();this.current=null;let next;
  while((next=this.queue.shift())&&!this.allowed(next)){}
  if(!next){this.host.hidden=true;this.duck(false);return}
  this.current=next;this.host.hidden=false;this.blocked=false;this.who.textContent={R:'ROBINSON',M:'MÁRA',I:'IVO'}[next[0]];
  this.caption.textContent=this.lines[next]||'Replika '+next;
  const pane=document.getElementById('panel');if(pane?.classList.contains('open')&&document.getElementById('paneTitle')?.textContent==='Rozhovor'){const story=pane.querySelector('.storyText');if(story)story.textContent=this.caption.textContent;}
  this.audio.src='assets/audio/dialogue/'+FILES[next[0]]+'/'+next.toLowerCase()+'.mp3';
  this.audio.volume=this.volume;this.duck(true);this.replay();
 }
 replay(){if(!this.current)return;this.audio.currentTime=0;let p=this.audio.play();p?.catch?.(()=>{this.blocked=true;this.host.querySelector('#voiceReplay').textContent='▶ Přehrát';this.caption.textContent=(this.lines[this.current]||this.current)+' · Klepni na ▶';});}
 bark(id,delay=60){let now=performance.now();if(this.lastBark[id]&&now-this.lastBark[id]<delay*1000)return;this.lastBark[id]=now;this.start([id])}
 onGame(e){
  if(e.type==='started') {this.started=true;if(e.fresh)this.start(['R001','R002','R003'],{priority:true});return}
  if(!this.started)return;
  if(e.type==='master-sound'){if(!e.on)this.stop();return}
  if(e.type==='new-game'){this.stop();this.lastQuest={};this.start(['R001','R002','R003'],{priority:true});return}
  if(e.type==='close-dialogue'){this.stop();return}
  if(e.type==='quest') {if(QUEST[e.id])this.start(QUEST[e.id],{remember:'quest-'+e.id});return}
  if(e.type==='crate-approach'){this.bark('R004',180);return}
  if(e.type==='interaction'){
   if(e.id==='mara'){
    if(!e.metBefore)this.start(FIRST_MARA,{priority:true});
    else {const seq=e.stolen?[['M007','M008','R024'],['M009','M024','R024'],['M025','M007']]:[['M006','M022','M023'],['M024','M025'],['M009','M006']];let index=(this.lastNpc.mara||0)%seq.length;this.lastNpc.mara=(this.lastNpc.mara||0)+1;this.start(seq[index],{priority:true});}
   }else if(e.id==='ivo'){
    if(!e.metBefore)this.start(FIRST_IVO,{priority:true});
    else {const seq=e.fate==='mara'?[['I006','I008','I019'],['I020','I021','I022','I023']]:[['I006','I007','I009'],['I019','I020','I021','I022','I023']];let index=(this.lastNpc.ivo||0)%seq.length;this.lastNpc.ivo=(this.lastNpc.ivo||0)+1;this.start(seq[index],{priority:true});}
   }else if(e.id==='stash')this.start(['R029','R030','R031','R032'],{priority:true});
   else if(e.id==='restored')this.start(['R046','M016','R047','M017','R048'],{priority:true});
   return;
  }
  if(e.type==='fate'){this.start(FATE,{priority:true});return}
  if(e.type==='fate-choice'){this.start(e.killed==='mara'?AFTER_MARA:AFTER_IVO,{priority:true});return}
  if(e.type==='ending'){this.start(e.fate==='mara'?END_IVO:END_MARA,{priority:true});return}
  if(e.type==='unstuck'){this.bark('R063',3);return}
  if(e.type==='gather'){this.bark('R061',95);return}
  if(e.type==='built'){this.bark('R060',80);return}
  if(e.type==='injury'){this.bark('R058',2.1);return}
  if(e.type==='missing'){this.bark('R059',45);return}
 }
 tick(){if(!this.started||!this.enabled||this.getState().sound===false||this.current||this.queue.length)return;let s=this.getState();if(s.water<21)this.bark('R056',240);else if(s.food<21)this.bark('R055',240);else if(s.energy<17)this.bark('R057',240);else if(s.clock>=19.5&&s.clock<=20.5)this.bark('R064',700);}
}
