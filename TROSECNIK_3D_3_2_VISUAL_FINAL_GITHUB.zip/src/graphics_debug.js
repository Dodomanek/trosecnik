import { Vector2 } from 'three';
// Optional graphics diagnostics. Add ?gfxdebug=1 to the game URL.
// Read-only measurements: never touches player state, scenes, inventory or controls.
export class GraphicsDebug {
  constructor(renderer) {
    this.renderer=renderer;
    this.enabled = new URLSearchParams(window.location.search).get('gfxdebug') === '1';
    if (!this.enabled) return;
    this.samples=[];
    this.lastUpdate=0;
    this.element=document.createElement('aside');
    this.element.id='graphicsDebug';
    this.element.setAttribute('aria-label','Vývojová diagnostika grafiky');
    Object.assign(this.element.style,{
      position:'fixed',right:'max(8px, env(safe-area-inset-right))',
      top:'calc(max(8px, env(safe-area-inset-top)) + 85px)',
      zIndex:'950',pointerEvents:'none',width:'fit-content',maxWidth:'min(260px, 50vw)',
      background:'rgba(7,21,23,.82)',color:'#e4f6e1',border:'1px solid #67866f',
      borderRadius:'8px',padding:'8px 10px',font:'12px/1.45 ui-monospace, Menlo, monospace',
      whiteSpace:'pre-wrap',boxShadow:'0 4px 18px rgba(0,0,0,.28)'
    });
    this.element.textContent='GPU diagnostika: spouštění…';
    document.body.appendChild(this.element);
  }
  tick(dt, time) {
    if (!this.enabled||!Number.isFinite(dt)||dt<=0) return;
    this.samples.push(dt);
    if(this.samples.length>90)this.samples.shift();
    if(time-this.lastUpdate<500) return;
    this.lastUpdate=time;
    const info=this.renderer?.engine?.info?.render;
    const size=this.renderer?.engine?.getDrawingBufferSize?.(new Vector2());
    const avg=this.samples.reduce((a,b)=>a+b,0)/Math.max(1,this.samples.length);
    const fps=Math.round(1/Math.max(.001,avg));
    const hero=this.renderer?.heroReady?'GLB načten':(this.renderer?.heroFailed?'záložní model':'načítání');
    this.element.textContent=`GRAFICKÝ AGENT · TEST\nFPS ~${fps}\nDraw calls ${info?.calls??'?'}\nTriangles ${info?.triangles??'?'}\nRozlišení ${size?.x??'?'} × ${size?.y??'?'}\nRobinson ${hero}\n(Pouze orientační měření)`;
  }
}
