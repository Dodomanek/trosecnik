// Trosečník 3D 2.1: small dependency-free loader for static, untextured glTF 2.0 GLB meshes.
// Supports the FIRST mesh / FIRST triangle primitive, embedded BIN chunk, FLOAT VEC3
// positions/normals and optional unsigned integer indices. Unsupported files fail safely.
const GLB_MAGIC = 0x46546c67;
const CHUNK_JSON = 0x4e4f534a;
const CHUNK_BIN  = 0x004e4942;
const MAX_TRIANGLES = 160000;

function readGLBGeometry(arrayBuffer, modelScale, modelYOffset) {
  const data = new DataView(arrayBuffer);
  if (data.byteLength < 20) throw Error('GLB je příliš krátký');
  if (data.getUint32(0, true) !== GLB_MAGIC) throw Error('neplatná GLB hlavička');
  if (data.getUint32(4, true) !== 2) throw Error('podporováno je pouze glTF 2.0');
  if (data.getUint32(8, true) !== data.byteLength) throw Error('neplatná délka GLB');

  let cursor = 12;
  let jsonBytes = null;
  let bin = null;
  let chunkCount = 0;
  while (cursor < data.byteLength) {
    if (cursor + 8 > data.byteLength) throw Error('useknutá hlavička GLB chunku');
    const size = data.getUint32(cursor, true);
    const type = data.getUint32(cursor + 4, true);
    cursor += 8;
    if (size % 4 || size > data.byteLength - cursor) throw Error('neplatná délka GLB chunku');
    if (chunkCount === 0 && type !== CHUNK_JSON) throw Error('první chunk musí být JSON');
    if (type === CHUNK_JSON && jsonBytes === null)
      jsonBytes = new Uint8Array(arrayBuffer, cursor, size);
    else if (type === CHUNK_BIN && bin === null)
      bin = { offset: cursor, length: size };
    cursor += size;
    chunkCount++;
  }
  if (!jsonBytes || !bin) throw Error('GLB neobsahuje JSON a vložený BIN chunk');

  const json = JSON.parse(new TextDecoder().decode(jsonBytes).replace(/\u0000+$/g, '').trim());
  if (!String(json.asset?.version || '').startsWith('2.')) throw Error('očekávána glTF 2.0');
  if (json.extensionsRequired?.length) throw Error('GLB vyžaduje nepodporované rozšíření: ' + json.extensionsRequired.join(', '));
  const primitive = json.meshes?.[0]?.primitives?.[0];
  if (!primitive || primitive.mode !== undefined && primitive.mode !== 4)
    throw Error('první mesh musí obsahovat trojúhelníky (TRIANGLES)');
  if (!Number.isInteger(primitive.attributes?.POSITION)) throw Error('mesh nemá POSITION accessor');

  function accessor(index, componentType, kind) {
    const item = json.accessors?.[index];
    if (!item || item.sparse || !Number.isInteger(item.bufferView))
      throw Error(`nepodporovaný nebo chybějící ${kind} accessor`);
    if (item.type !== kind || !componentType.includes(item.componentType) ||
        !Number.isInteger(item.count) || item.count < 1)
      throw Error(`neplatný typ / počet prvků ${kind} accessoru`);
    const view = json.bufferViews?.[item.bufferView];
    if (!view || (view.buffer ?? 0) !== 0) throw Error('podporován je pouze vložený BIN buffer');
    if (!Number.isInteger(view.byteOffset ?? 0) || !Number.isInteger(item.byteOffset ?? 0) ||
        !Number.isInteger(view.byteLength) || view.byteLength < 1)
      throw Error('neplatný offset / délka bufferView');
    const bytesPerComponent = item.componentType === 5126 || item.componentType === 5125 ? 4 :
      item.componentType === 5123 ? 2 : 1;
    const components = kind === 'VEC3' ? 3 : 1;
    const elementBytes = components * bytesPerComponent;
    const stride = view.byteStride ?? elementBytes;
    if (!Number.isInteger(stride) || stride < elementBytes || stride > 252 ||
        (view.byteOffset ?? 0) % bytesPerComponent ||
        (item.byteOffset ?? 0) % bytesPerComponent || stride % bytesPerComponent)
      throw Error('neplatný stride nebo zarovnání');
    const relative = (item.byteOffset ?? 0);
    const last = relative + (item.count - 1) * stride + elementBytes;
    if (last > view.byteLength || (view.byteOffset ?? 0) + view.byteLength > bin.length)
      throw Error('accessor přesahuje GLB BIN chunk');
    const base = bin.offset + (view.byteOffset ?? 0) + relative;
    return { item, base, stride };
  }

  const pos = accessor(primitive.attributes.POSITION, [5126], 'VEC3');
  let nor = null;
  if (primitive.attributes.NORMAL !== undefined)
    nor = accessor(primitive.attributes.NORMAL, [5126], 'VEC3');
  if (nor && nor.item.count !== pos.item.count) throw Error('POSITION a NORMAL nemají stejnou délku');

  let indexAccessor = null;
  if (primitive.indices !== undefined)
    indexAccessor = accessor(primitive.indices, [5121, 5123, 5125], 'SCALAR');
  const vertexCount = indexAccessor ? indexAccessor.item.count : pos.item.count;
  if (vertexCount % 3 || vertexCount > MAX_TRIANGLES * 3)
    throw Error('nesprávný nebo příliš velký počet vrcholů');

  const scale = Number(modelScale ?? 1);
  const yOffset = Number(modelYOffset ?? 0);
  if (!Number.isFinite(scale) || scale === 0 || !Number.isFinite(yOffset))
    throw Error('neplatné měřítko nebo yOffset');
  const positions = new Float32Array(vertexCount * 3);
  const normals = new Float32Array(vertexCount * 3);
  const colors = new Float32Array(vertexCount * 3);
  colors.fill(1);

  function sourceIndex(n) {
    if (!indexAccessor) return n;
    const at = indexAccessor.base + n * indexAccessor.stride;
    const type = indexAccessor.item.componentType;
    return type === 5125 ? data.getUint32(at, true) :
      type === 5123 ? data.getUint16(at, true) : data.getUint8(at);
  }
  for (let n = 0; n < vertexCount; n++) {
    const original = sourceIndex(n);
    if (original >= pos.item.count) throw Error('index ukazuje mimo POSITION accessor');
    const at = pos.base + original * pos.stride;
    for (let k = 0; k < 3; k++) {
      const coord = data.getFloat32(at + k * 4, true);
      if (!Number.isFinite(coord)) throw Error('neplatná pozice vrcholu');
      positions[n * 3 + k] = coord * scale + (k === 1 ? yOffset : 0);
    }
    if (nor) {
      const atNormal = nor.base + original * nor.stride;
      const x = data.getFloat32(atNormal, true),
            y = data.getFloat32(atNormal + 4, true),
            z = data.getFloat32(atNormal + 8, true);
      const length = Math.hypot(x, y, z);
      if (!Number.isFinite(length) || length < 1e-8) throw Error('neplatná normála');
      const sign = scale < 0 ? -1 : 1;
      normals.set([sign * x / length, sign * y / length, sign * z / length], n * 3);
    }
  }
  if (!nor) {
    for (let n = 0; n < vertexCount; n += 3) {
      const i = n * 3;
      const ax = positions[i+3]-positions[i], ay = positions[i+4]-positions[i+1], az = positions[i+5]-positions[i+2];
      const bx = positions[i+6]-positions[i], by = positions[i+7]-positions[i+1], bz = positions[i+8]-positions[i+2];
      let nx = ay*bz-az*by, ny = az*bx-ax*bz, nz = ax*by-ay*bx;
      const length = Math.hypot(nx,ny,nz) || 1;
      nx/=length; ny/=length; nz/=length;
      for(let p = 0; p < 3; p++) normals.set([nx,ny,nz], i + p*3);
    }
  }
  return { positions, normals, colors, count: vertexCount };
}

function uploadGLB(gl, geometry) {
  const vao = gl.createVertexArray();
  if (!vao) throw Error('nelze vytvořit VAO');
  const buffers = [];
  try {
    gl.bindVertexArray(vao);
    for (const [location, values] of [geometry.positions, geometry.normals, geometry.colors].entries()) {
      const vbo = gl.createBuffer();
      if (!vbo) throw Error('nelze vytvořit VBO');
      buffers.push(vbo);
      gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
      gl.bufferData(gl.ARRAY_BUFFER, values, gl.STATIC_DRAW);
      gl.enableVertexAttribArray(location);
      gl.vertexAttribPointer(location, 3, gl.FLOAT, false, 0, 0);
    }
    return { vao, count: geometry.count, buffers };
  } catch(error) {
    for (const buffer of buffers) gl.deleteBuffer(buffer);
    gl.deleteVertexArray(vao);
    throw error;
  } finally {
    gl.bindVertexArray(null);
    gl.bindBuffer(gl.ARRAY_BUFFER, null);
  }
}

export async function loadGLBModels(gl, list) {
  const registry = Object.create(null);
  if (!gl || !Array.isArray(list)) return registry;
  for (const item of list) {
    if (!item || typeof item.name !== 'string' || !item.name || typeof item.url !== 'string') {
      console.warn('GLB: neplatný záznam v seznamu modelů');
      continue;
    }
    try {
      const response = await fetch(item.url);
      if (!response.ok) throw Error(`HTTP ${response.status}`);
      const geometry = readGLBGeometry(await response.arrayBuffer(), item.scale, item.yOffset);
      // Hot-swapping a loaded model releases its previous GPU buffers.
      const old = registry[item.name];
      const uploaded = uploadGLB(gl, geometry);
      if (old) {
        for(const buffer of old.buffers) gl.deleteBuffer(buffer);
        gl.deleteVertexArray(old.vao);
      }
      registry[item.name] = uploaded;
    } catch (error) {
      console.warn(`GLB ${item.name} (${item.url}): ${error.message}; použit procedurální model`, error);
    }
  }
  return registry;
}
