// One source of truth for the rendered fishing target and its hit detection.
// Percentages refer to the track's internal width, not a delayed click timestamp.
export const FISH_GREEN_START = 40;
export const FISH_GREEN_END = 61;
export const FISH_EDGE_TOLERANCE = 1.5; // ~3 px on a 200 px track for visible marker overlap.
export function fishNeedlePercent(seconds) {
  return (Math.sin(seconds * 3.25) * .5 + .5) * 100;
}
export function fishNeedleHitsGreen(visiblePercent) {
  return Number.isFinite(visiblePercent)
    && visiblePercent >= FISH_GREEN_START - FISH_EDGE_TOLERANCE
    && visiblePercent <= FISH_GREEN_END + FISH_EDGE_TOLERANCE;
}
