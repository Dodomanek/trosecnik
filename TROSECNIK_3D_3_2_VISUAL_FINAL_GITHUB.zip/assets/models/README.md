# 3D assety

`robinson.glb` je součástí tohoto projektu. Má interní animace Idle, Walk, Run, Gather, Chop, Build, Drink a Rest.

Volitelně lze přidat palm.glb a crate.glb; hra jinak použije procedurální variantu.

GFX 11: `robinson.glb` nyní obsahuje šest malých originálních procedurálních
materiálových mikrotextur navíc. `robinson_base.glb` je identický původní
animovaný model (bez texturovacího upgradu) pro bezpečný fallback při chybě.
Regenerace: `python tools/upgrade_robinson_materials.py`. Původní zjednodušené
segmentované tělo a animační klipy nebyly přepracovány do skinned humanoida.

GFX 13: `spring_cliff.glb` je originální neprůhledný PBR 3D model skalní stěny za pramenem (8 820 trojúhelníků, osm meshů). V aktivní Three.js scéně nahrazuje výhradně statické skály, nikoli animovanou vodu. Původní procedurální skalní model je načítací fallback. Zdroj: `python tools/generate_spring_cliff.py`.

GFX 20: `canopy.glb` (originální fasetovaný listnatý strom, 680 trojúhelníků, 3 mesh) a `rock.glb` (originální fasetovaný shluk balvanů se mchem, 392 trojúhelníků, 3 mesh) nahrazují dosavadní placeholder geometrii (koule) u listnatých stromů a polních kamenů podél hlavní stezky — položka P1 v `graphics/BACKLOG.md`. Obě volitelné, s procedurálním fallbackem beze změny kolizí, `sceneObstacles` či save dat. Zdroj: `python tools/generate_canopy.py` a `python tools/generate_rock.py`.
