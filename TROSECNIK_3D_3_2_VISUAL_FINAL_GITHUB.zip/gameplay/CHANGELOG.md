# Trosečník 3D 2.4.2 · SURVIVAL 20 (vývojový Vercel balíček)

## Omezování surovin v okolí tábora

- Deset startovních nalezišť v okolí prvního tábora má nyní každý maximálně **3 sběry v jedné uložené pozici**. Mezi sběry stejného blízkého naleziště musí uplynout nejméně **180 sekund aktivní hry**. Po třetím sběru se místo trvale vyčerpá. Není to změna kolizí ani přesun stávajících objektů.
- Vzdálenější dřevo, kámen, vlákna, kokosy, byliny a pryskyřice jsou obnovitelné; prodleva je nejméně **300 sekund aktivní hry**. Ryby mají mezi úspěšnými úlovky na stejné rybářské lokalitě prodlevu **90 sekund**. Neúspěšná minihra ryby nespotřebuje.
- Doplňující materiál lze hledat v mangrovech, horském lese, u jeskyně a jižní laguny. Pitné prameny a postavený vodní filtr zůstávají dostupné podle původních pravidel. Výrobu, cenu receptů, boj ani survival potřeby tato iterace nemění.
- Stav vyčerpání je uložen v `state.flags.campHarvest-*` a stávajících časových značkách `collected-*`. Ve starých pozicích, kde už je časová značka, se pro účely omezení započítá jeden předchozí sběr, nikoliv celý neznámý počet historických sběrů.

## Další průzkumná etapa

- Čtyři další navazující hlavní úkoly po posledním rádiovém signálu a před výpravou do neznáma: **Pobřežní průzkum**, **Stezka přes mangrovy**, **Pozorovatelna na hřebeni**, **Mapa ostrova**. Jsou to tři nová interakční místa na existujícím ostrově a finální sestavení zápisků u původního expedičního stolu v táboře.
- Cíle se zpřístupňují postupně; malé mapové značky existují pouze v aktuálně aktivním úkolu. K průzkumu je zapotřebí minimálně 18 vody a 14 energie, nikoliv zvláštní nový předmět. Zápisky mají vlastní deníkové texty a XP. Počet nových úkolů není zárukou konkrétní doby dohrání.
- Při načtení staré pozice, ve které již hráč dokončil přípravu expedice, se nová průzkumná etapa označí za splněnou **bez opětovného udělení XP**. Dříve uložené postavy, suroviny, příběhové volby, savy, dabing, minihry a grafika se neresetují.

## Ověření a omezení

- `node --test tools/test_survival20.mjs tools/test_fishing_timing.mjs tools/test_quest_pointer.mjs`
- `node --check src/main.js && node --check src/renderer.js && node --check src/game_logic.js && node --check src/resource_rules.js`
- `node tools/graphics_agent.mjs audit`

Jde o statické a izolované testy. Skutečný WebGL průchod všemi novými cestami, plná dohratelnost po celkové změně ekonomiky a výkon na iPhonu nejsou tímto testem prokázány. Nenahrazujte bez zálohy produkční uloženou hru.

## SURVIVAL 21 · Tři jednorázové zásobovací úkryty (2026-09-22)

- V existujících třech průzkumných regionech přibyly tři skutečně interaktivní úkryty: pobřežní bedna (`coastCache`), vak v mangrovech (`westCache`) a horská schránka (`ridgeCache`). Při průzkumné cestě následují po příslušných zeměpisných orientačních bodech; automatická šipka ukazuje vždy pouze na aktivní cíl.
- Jednorázové vyzvednutí poskytne omezený balíček: pobřeží 2 dřeva + 2 kameny, mangrovy 3 vlákna + 2 kokosy, hřeben 2 dřeva + 1 kámen + 1 obvaz. Úkryt po prvním vyzvednutí trvale zmizí a již nepřidává XP ani suroviny. Nejde o nový respawn zdrojů u tábora.
- Tři nové úkoly a malé lokální 3D značky běží v původní aktivní renderovací cestě; nejsou přidány mapové kolize, nový systém inventáře, další materiály ani nové klíče ukládání. Beze změny zůstávají dabing, původní questy a ceny receptů.
- Stávající pozice za vyprávěnou oblastí při načtení nové úkryty přeskočí bez dodatečného XP či zdvojených zásob. Pozice, které teprve dokončují průzkum, mohou nové kroky projít. Před aktualizací produkčního webu je vhodné exportovat zálohu pozic.
- Ověřeno izolovanými JS testy a statickým grafickým auditem. Délka skutečného dohrání, nepřerušený průchod od úvodu do konce, WebGL vzhled a výkon na iPhonu dosud nejsou ověřeny.

## SURVIVAL 22 · Výpravy za surovinami a průzkumnická dílna (2026-09-23)

- Přidáno pět typů sbíratelných materiálů: rákos, jíl, pazourek, lesní bobule a mořská sůl. Každý má dvě samostatná vzdálená naleziště na stávajících cestách ostrova, daleko od úvodního tábora. Naleziště nemění kolize; používají dostupný procedurální 3D renderer. Mezi sběry na stejném místě je nejméně 320–360 sekund **aktivní herní doby**. Omezení původních deseti táborových zdrojů zůstalo.
- Šest nových receptů: cestovní svačina, sušená ryba (dostupná po dokončení ohniště), bylinný obklad, opakovaně plnitelná hliněná čutora, jednorázová rákosová rohož a trvalý pazourkový nůž. Každý má konkrétní použití. Nůž přidá jeden kus při sběru rákosu/bobulí; čutoru lze naplnit u obou přírodních pramenů i u fungujícího vodního filtru a později vypít v batohu.
- Přidány tři **volitelné** průzkumnické milníky do deníku pro hledání nových surovin, výrobu čutory a přípravu zásob/ošetření. XP se připíše pouze jednou pro danou uloženou pozici. Tyto úkoly nezastavují ani nemění původní hlavní příběh.
- Mapa i nabídka Výroba obsahují základní orientační rady, kde nové suroviny hledat; samostatné cíle nejsou přidány do automatické navigace hlavních úkolů.
- Stávající klíč úložiště a `version:2` zůstávají; staré `bag` se rozšíří standardní existující migrací pomocí `BASE.bag`. Žádný původní quest, jeho odměna, konstrukce, naleziště ani save slot nebyl přepsán. Nové interakce nezvyšují četnost respawnu poblíž tábora.
- Nové izolované testy kontrolují sběr, cooldown, materiálové náklady, neduplikovatelnou čutoru, účinky použitého vybavení, jednorázové XP, původní questy a neměnný save klíč. Stávající testy používají samostatně přibalené předchozí baseline; již nevyžadují sousední rozbalený projekt.
- **Omezení:** Reálný end-to-end průchod úkolů, vizuální vykreslení nové geometrie ve WebGL a výkon/FPS na skutečném iPhonu dosud nejsou ověřeny. Změna sama o sobě negarantuje určitou délku dohrání.
